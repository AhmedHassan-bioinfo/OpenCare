const $ = s => document.querySelector(s);
const app = $('#app');
const sheetRoot = $('#sheetRoot');
const toastEl = $('#toast');
const audioEl = $('#ayahAudio');

const LAYOUT_BASE = 'https://raw.githubusercontent.com/zonetecde/mushaf-layout/refs/heads/main/mushaf';
const FONT_V2 = p => `https://verses.quran.foundation/fonts/quran/hafs/v2/woff2/p${p}.woff2`;
const FONT_V4 = p => `https://verses.quran.foundation/fonts/quran/hafs/v4/colrv1/woff2/p${p}.woff2`;
const PAGE_IMAGE = p => `https://raw.githubusercontent.com/QuranHub/quran-pages-images/main/ayat/hafs/${p}.png`;
const PAGE_IMAGE_FALLBACK = p => `https://raw.githubusercontent.com/QuranHub/quran-pages-images/main/ayat/hafs/${p}.png`;
const TAJWEED_BG_IMAGE = p => ''; // CSS-rendered template in Android build
const PAGE_SPREAD_BG = 'assets/page-spread-bg.png';
const PAGE_SPREAD_BG_LEFT = 'assets/page-spread-bg-left.png';
const MUTASH_URL = 'https://raw.githubusercontent.com/Waqar144/Quran_Mutashabihat_Data/master/mutashabiha_data.json';
const QURAN_API = 'https://api.quran.com/api/v4';
// QuranHub quran-images-utils output: ayah-end marker coordinates generated
// by template matching on KFGQPC Hafs pages. We use these markers to build
// accurate ayah-sized hit regions over the photographed Madinah Mushaf.
const QURANHUB_AYA_LOCATOR_URL = 'https://raw.githubusercontent.com/QuranHub/quran-pages-images/main/kfgqpc/hafs-wasat/data/data.csv';
const QURANHUB_LOCATOR_SOURCE = { width:807, height:1205, textLeft:82, textRight:724, lineStep:70.5, markerWidth:34, lineHeight:54 };
let ayaLocatorMap = null;
let ayaLocatorPromise = null;
const PICKTHALL_URL = 'https://cdn.jsdelivr.net/gh/druvx13/Quran-data@main/data/en.pickthall.tanzil.txt';
let pickthallMap = null;


const QURANENC_API = 'https://quranenc.com/api/v1/translation/aya';
const LANGUAGES = {
  en: { native:'English', label:'English', dir:'ltr' },
  ar: { native:'العربية', label:'Arabic', dir:'rtl' },
  ur: { native:'اردو', label:'Urdu (Pakistan)', dir:'rtl' },
  id: { native:'Bahasa Indonesia', label:'Indonesian', dir:'ltr' },
  ms: { native:'Bahasa Melayu', label:'Malay (Malaysia)', dir:'ltr' },
  bn: { native:'বাংলা', label:'Bengali (Bangladesh)', dir:'ltr' },
  tr: { native:'Türkçe', label:'Turkish', dir:'ltr' },
  fr: { native:'Français', label:'French', dir:'ltr' },
  'pt-BR': { native:'Português (Brasil)', label:'Portuguese (Brazil)', dir:'ltr' },
};
const TRANSLATIONS = {
  en: { key:'english_rwwad', title:'English', author:'Rowwad Translation Center', source:'QuranEnc.com', version:'V1.0.19', dir:'ltr' },
  ur: { key:'urdu_junagarhi', title:'اردو', author:'Muhammad Junagarhi', source:'QuranEnc.com', version:'V1.1.3', dir:'rtl' },
  id: { key:'indonesian_affairs', title:'Bahasa Indonesia', author:'Ministry of Religious Affairs, Indonesia', source:'QuranEnc.com', version:'Current QuranEnc edition', dir:'ltr' },
  ms: { key:'malay_basumayyah', title:'Bahasa Melayu', author:'Abdullah Basumayyah', source:'QuranEnc.com', version:'V1.0.0', dir:'ltr' },
  bn: { key:'bengali_zakaria', title:'বাংলা', author:'Abu Bakr Zakaria', source:'QuranEnc.com', version:'Current QuranEnc edition', dir:'ltr' },
  tr: { key:'turkish_rwwad', title:'Türkçe', author:'Rowwad Translation Center', source:'QuranEnc.com', version:'V1.0.4', dir:'ltr' },
  fr: { key:'french_hameedullah', title:'Français', author:'Muhammad Hamidullah', source:'QuranEnc.com', version:'V1.0.2', dir:'ltr' },
  'pt-BR': { key:'portuguese_nasr', title:'Português', author:'Dr. Helmi Nasr', source:'QuranEnc.com', version:'V1.4.1', dir:'ltr' },
};

const UI_TEXT = {
  en:{home:'Home',mushaf:'Mushaf',review:'Review',practice:'Practice',progress:'Progress',settings:'Settings',continueJourney:'Continue your Hifz journey',todayPlan:"Today's Plan",newMem:'New Memorization',revisionDue:'Revision Due',start:'Start',overall:'Overall Progress',juzCompleted:'Juz completed',pagesMemorized:'Pages memorized',ayahsReview:'Ayahs to review',quick:'Quick Actions',resume:'Resume Hifz',weak:'Weakly memorized Ayahs',mutash:'Mutashābihāt',listen:'Listen & Repeat',audio:'Audio',hide:'Hide',translation:'Translation',bookmark:'Bookmark',evaluate:'Evaluate',hint:'Hint',reveal:'Reveal Next Word',showAyah:'Show Ayah',nextAyah:'Next Ayah →',language:'UI language',translationLang:'Translation language',theme:'Theme',app:'App',audioTitle:'Ayah Audio',loadingTranslation:'Loading translation…',tapAyah:'Tap an ayah to view its translation.',unavailable:'Translation unavailable.'},
  ur:{home:'ہوم',mushaf:'مصحف',review:'دہرائی',practice:'مشق',progress:'پیش رفت',settings:'ترتیبات',continueJourney:'اپنا حفظ جاری رکھیں',todayPlan:'آج کا منصوبہ',newMem:'نیا حفظ',revisionDue:'دہرائی واجب',start:'شروع',overall:'مجموعی پیش رفت',juzCompleted:'مکمل اجزاء',pagesMemorized:'یاد شدہ صفحات',ayahsReview:'دہرائی کی آیات',quick:'فوری اختیارات',resume:'حفظ جاری رکھیں',weak:'کمزور یاد شدہ آیات',mutash:'متشابہات',listen:'سنیں اور دہرائیں',audio:'آڈیو',hide:'چھپائیں',translation:'ترجمہ',bookmark:'نشان',evaluate:'جائزہ',hint:'اشارہ',reveal:'اگلا لفظ دکھائیں',showAyah:'آیت دکھائیں',nextAyah:'اگلی آیت ←',language:'ایپ کی زبان',translationLang:'ترجمے کی زبان',theme:'تھیم',app:'ایپ',audioTitle:'آیت کی آڈیو',loadingTranslation:'ترجمہ لوڈ ہو رہا ہے…',tapAyah:'ترجمہ دیکھنے کے لیے آیت منتخب کریں۔',unavailable:'ترجمہ دستیاب نہیں۔'},
  id:{home:'Beranda',mushaf:'Mushaf',review:'Murajaah',practice:'Latihan',progress:'Progres',settings:'Pengaturan',continueJourney:'Lanjutkan perjalanan Hifz Anda',todayPlan:'Rencana Hari Ini',newMem:'Hafalan Baru',revisionDue:'Murajaah Jatuh Tempo',start:'Mulai',overall:'Progres Keseluruhan',juzCompleted:'Juz selesai',pagesMemorized:'Halaman dihafal',ayahsReview:'Ayat untuk diulang',quick:'Aksi Cepat',resume:'Lanjutkan Hifz',weak:'Ayat yang hafalannya lemah',mutash:'Mutasyabihat',listen:'Dengar & Ulangi',audio:'Audio',hide:'Sembunyikan',translation:'Terjemahan',bookmark:'Penanda',evaluate:'Evaluasi',hint:'Petunjuk',reveal:'Tampilkan Kata Berikutnya',showAyah:'Tampilkan Ayat',nextAyah:'Ayat Berikutnya →',language:'Bahasa antarmuka',translationLang:'Bahasa terjemahan',theme:'Tema',app:'Aplikasi',audioTitle:'Audio Ayat',loadingTranslation:'Memuat terjemahan…',tapAyah:'Ketuk ayat untuk melihat terjemahan.',unavailable:'Terjemahan tidak tersedia.'},
  ms:{home:'Utama',mushaf:'Mushaf',review:'Ulang Kaji',practice:'Latihan',progress:'Kemajuan',settings:'Tetapan',continueJourney:'Teruskan perjalanan Hifz anda',todayPlan:'Pelan Hari Ini',newMem:'Hafazan Baharu',revisionDue:'Ulang Kaji Perlu',start:'Mula',overall:'Kemajuan Keseluruhan',juzCompleted:'Juz selesai',pagesMemorized:'Halaman dihafaz',ayahsReview:'Ayat untuk diulang kaji',quick:'Tindakan Pantas',resume:'Sambung Hifz',weak:'Ayat yang dihafaz lemah',mutash:'Mutasyabihat',listen:'Dengar & Ulang',audio:'Audio',hide:'Sembunyi',translation:'Terjemahan',bookmark:'Penanda',evaluate:'Nilai',hint:'Petunjuk',reveal:'Dedah Perkataan Seterusnya',showAyah:'Tunjuk Ayat',nextAyah:'Ayat Seterusnya →',language:'Bahasa UI',translationLang:'Bahasa terjemahan',theme:'Tema',app:'Aplikasi',audioTitle:'Audio Ayat',loadingTranslation:'Memuatkan terjemahan…',tapAyah:'Tekan ayat untuk melihat terjemahan.',unavailable:'Terjemahan tidak tersedia.'},
  bn:{home:'হোম',mushaf:'মুসহাফ',review:'পুনরাবৃত্তি',practice:'অনুশীলন',progress:'অগ্রগতি',settings:'সেটিংস',continueJourney:'আপনার হিফজ যাত্রা চালিয়ে যান',todayPlan:'আজকের পরিকল্পনা',newMem:'নতুন মুখস্থ',revisionDue:'পুনরাবৃত্তি বাকি',start:'শুরু',overall:'সামগ্রিক অগ্রগতি',juzCompleted:'সম্পন্ন জুয',pagesMemorized:'মুখস্থ পৃষ্ঠা',ayahsReview:'পুনরাবৃত্তির আয়াত',quick:'দ্রুত কার্যক্রম',resume:'হিফজ চালিয়ে যান',weak:'দুর্বলভাবে মুখস্থ আয়াত',mutash:'মুতাশাবিহাত',listen:'শুনুন ও পুনরাবৃত্তি করুন',audio:'অডিও',hide:'লুকান',translation:'অনুবাদ',bookmark:'বুকমার্ক',evaluate:'মূল্যায়ন',hint:'ইঙ্গিত',reveal:'পরবর্তী শব্দ দেখান',showAyah:'আয়াত দেখান',nextAyah:'পরবর্তী আয়াত →',language:'ইউআই ভাষা',translationLang:'অনুবাদের ভাষা',theme:'থিম',app:'অ্যাপ',audioTitle:'আয়াত অডিও',loadingTranslation:'অনুবাদ লোড হচ্ছে…',tapAyah:'অনুবাদ দেখতে একটি আয়াত চাপুন।',unavailable:'অনুবাদ পাওয়া যায়নি।'},
  tr:{home:'Ana Sayfa',mushaf:'Mushaf',review:'Tekrar',practice:'Alıştırma',progress:'İlerleme',settings:'Ayarlar',continueJourney:'Hıfz yolculuğuna devam et',todayPlan:'Bugünün Planı',newMem:'Yeni Ezber',revisionDue:'Tekrar Zamanı',start:'Başla',overall:'Genel İlerleme',juzCompleted:'Tamamlanan cüz',pagesMemorized:'Ezberlenen sayfa',ayahsReview:'Tekrar edilecek ayet',quick:'Hızlı İşlemler',resume:'Hıfza Devam Et',weak:'Zayıf ezberlenen ayetler',mutash:'Müteşabihât',listen:'Dinle ve Tekrarla',audio:'Ses',hide:'Gizle',translation:'Meal',bookmark:'Yer İmi',evaluate:'Değerlendir',hint:'İpucu',reveal:'Sonraki Kelimeyi Aç',showAyah:'Ayeti Göster',nextAyah:'Sonraki Ayet →',language:'Arayüz dili',translationLang:'Meal dili',theme:'Tema',app:'Uygulama',audioTitle:'Ayet Sesi',loadingTranslation:'Meal yükleniyor…',tapAyah:'Meali görmek için bir ayete dokunun.',unavailable:'Meal kullanılamıyor.'},
  fr:{home:'Accueil',mushaf:'Mushaf',review:'Révision',practice:'Pratique',progress:'Progrès',settings:'Réglages',continueJourney:'Continuez votre parcours de Hifz',todayPlan:"Plan d’aujourd’hui",newMem:'Nouvelle mémorisation',revisionDue:'Révision due',start:'Commencer',overall:'Progression globale',juzCompleted:'Juz terminés',pagesMemorized:'Pages mémorisées',ayahsReview:'Versets à réviser',quick:'Actions rapides',resume:'Reprendre le Hifz',weak:'Versets faiblement mémorisés',mutash:'Mutashābihāt',listen:'Écouter & Répéter',audio:'Audio',hide:'Masquer',translation:'Traduction',bookmark:'Signet',evaluate:'Évaluer',hint:'Indice',reveal:'Révéler le mot suivant',showAyah:'Afficher le verset',nextAyah:'Verset suivant →',language:"Langue de l’interface",translationLang:'Langue de traduction',theme:'Thème',app:'Application',audioTitle:'Audio du verset',loadingTranslation:'Chargement de la traduction…',tapAyah:'Touchez un verset pour voir sa traduction.',unavailable:'Traduction indisponible.'},
  'pt-BR':{home:'Início',mushaf:'Mushaf',review:'Revisão',practice:'Prática',progress:'Progresso',settings:'Configurações',continueJourney:'Continue sua jornada de Hifz',todayPlan:'Plano de Hoje',newMem:'Nova Memorização',revisionDue:'Revisão Pendente',start:'Começar',overall:'Progresso Geral',juzCompleted:'Juz concluídos',pagesMemorized:'Páginas memorizadas',ayahsReview:'Ayahs para revisar',quick:'Ações Rápidas',resume:'Continuar Hifz',weak:'Ayahs memorizadas com dificuldade',mutash:'Mutashābihāt',listen:'Ouvir & Repetir',audio:'Áudio',hide:'Ocultar',translation:'Tradução',bookmark:'Favorito',evaluate:'Avaliar',hint:'Dica',reveal:'Revelar Próxima Palavra',showAyah:'Mostrar Ayah',nextAyah:'Próxima Ayah →',language:'Idioma da interface',translationLang:'Idioma da tradução',theme:'Tema',app:'Aplicativo',audioTitle:'Áudio da Ayah',loadingTranslation:'Carregando tradução…',tapAyah:'Toque em uma ayah para ver a tradução.',unavailable:'Tradução indisponível.'}
};
const UI_EXTRA={
  en:{standard:'Standard',tajweedColors:'Tajweed Colors',single:'Single',scroll:'Scroll',twoPage:'Two page',jumpTitle:'Go to Surah / Ayah',current:'Current',surah:'Surah',ayah:'Ayah',goAyah:'Go to Ayah',mushafDisplay:'Mushaf Display',readingStyle:'Reading style',fontSize:'Arabic font size',twoPageView:'Two-page view',showPageNumbers:'Show page numbers',defaultReciter:'Default reciter',autoPlay:'Auto play next ayah',pauseAfter:'Pause after each ayah',offlineAudio:'Offline audio',offlineVoice:'Voice to download',downloadAll:'Download all ayahs',deleteAudio:'Delete downloaded audio',downloaded:'Downloaded',notDownloaded:'Not downloaded',downloading:'Downloading',resetProgress:'Reset Hifz progress',offlineData:'Offline data',cachedPages:'Page data cached as you read',audioSettings:'Audio'},
  ar:{home:'الرئيسية',mushaf:'المصحف',review:'المراجعة',practice:'التدريب',progress:'التقدم',settings:'الإعدادات',continueJourney:'واصل رحلة الحفظ',todayPlan:'خطة اليوم',newMem:'حفظ جديد',revisionDue:'مراجعة مستحقة',start:'ابدأ',overall:'التقدم العام',juzCompleted:'أجزاء مكتملة',pagesMemorized:'صفحات محفوظة',ayahsReview:'آيات للمراجعة',quick:'اختصارات',resume:'متابعة الحفظ',weak:'آيات ضعيفة الحفظ',mutash:'المتشابهات',listen:'استماع وتكرار',audio:'الصوت',hide:'إخفاء',translation:'الترجمة',bookmark:'علامة',evaluate:'تقييم',hint:'تلميح',reveal:'إظهار الكلمة التالية',showAyah:'إظهار الآية',nextAyah:'الآية التالية ←',language:'لغة الواجهة',translationLang:'لغة الترجمة',theme:'المظهر',app:'التطبيق',audioTitle:'صوت الآية',loadingTranslation:'جارٍ تحميل الترجمة…',tapAyah:'اختر آية لعرض ترجمتها.',unavailable:'الترجمة غير متاحة.',standard:'عادي',tajweedColors:'ألوان التجويد',single:'صفحة',scroll:'تمرير',twoPage:'صفحتان',jumpTitle:'الانتقال إلى سورة / آية',current:'الحالي',surah:'السورة',ayah:'الآية',goAyah:'انتقال إلى الآية',mushafDisplay:'عرض المصحف',readingStyle:'نمط العرض',fontSize:'حجم الخط العربي',twoPageView:'عرض صفحتين',showPageNumbers:'إظهار أرقام الصفحات',defaultReciter:'القارئ الافتراضي',autoPlay:'تشغيل الآية التالية تلقائيًا',pauseAfter:'توقف بعد كل آية',offlineAudio:'الصوت دون إنترنت',offlineVoice:'القارئ المراد تنزيله',downloadAll:'تنزيل جميع الآيات',deleteAudio:'حذف الصوت المنزّل',downloaded:'تم التنزيل',notDownloaded:'غير منزّل',downloading:'جارٍ التنزيل',resetProgress:'إعادة ضبط تقدم الحفظ',offlineData:'بيانات دون إنترنت',cachedPages:'تُحفظ بيانات الصفحات أثناء القراءة',audioSettings:'الصوت'}
};
const UI_MORE={"en":{"greeting":"Assalamu Alaikum","page":"Page","juz":"Juz","rightPage":"Right page","leftPage":"Left page","displayOptions":"Mushaf display options","selfEvaluation":"Self Evaluation","tapAyahFirst":"Tap an ayah first","selectedAyah":"Selected ayah","wholePage":"Whole page","applyOneRating":"Apply one rating to all {count} ayahs on Page {page}.","strongShort":"Strong","reviewShort":"Review","weakShort":"Weak","addNote":"Add note","optionalNote":"Optional note about this ayah…","save":"Save","chooseRating":"Choose a rating.","pageEvaluationSaved":"Page evaluation saved","ayahEvaluationSaved":"Ayah evaluation saved","pageBookmarked":"Page bookmarked","bookmarkRemoved":"Bookmark removed","pageN":"Page {page}","ayahPageCount":"{ayahs} ayahs · {pages} pages","similarAyahPractice":"Similar-ayah practice","currentAyahAudio":"Current ayah audio","ayahAudio":"Ayah Audio","repeat":"Repeat","revisionTitle":"Revision","basedSelfEvaluations":"Based on your self-evaluations","reviseFirst":"Weak · revise first","needsReview":"Needs review","emptyRevision":"Evaluate ayahs from the Mushaf to build your revision queue.","openInMushaf":"Open in Mushaf","practiceTitle":"Practice","practiceSubtitle":"Recall, visual memory and listening","coreRecall":"Core Recall","hifzPractice":"Hifz Practice","listening":"Listening","continueAyah":"Continue the Ayah","continueDesc":"See the opening words, then continue from memory","randomAyah":"Random Ayah","randomDesc":"Recall a hidden ayah from a random test page","whatBefore":"What Comes Before?","beforeDesc":"Recall the previous ayah","whatAfter":"What Comes After?","afterDesc":"Recall the next ayah","pageTest":"Page Test","pageTestDesc":"Hide the page, recite it, then reveal and rate","surahTest":"Surah Test","surahTestDesc":"Test one Surah or range","mutashPractice":"Mutashābihāt","mutashDesc":"Practice similar ayahs","visualMemory":"Visual Memory","visualDesc":"Recall content from its fixed position on the page","audioHifz":"Audio Hifz","audioHifzDesc":"Listen, repeat and shadow recitation","fromAyah":"From ayah","toAyah":"To ayah","startTest":"Start test","noPracticeSession":"No practice session.","testPageReading":"Test page {testPage} · reading progress stays on Page {page}","loadingCue":"Loading cue…","loadingRandomPage":"Loading random Mushaf page…","loadingAnswer":"Loading answer…","howRecall":"How was your recall?","playAyah":"Play ayah","hideAnswer":"Hide answer","revealAnswer":"Reveal answer","anotherTest":"Another test","promptContinue":"Read the opening words, then continue the ayah from memory.","promptRandom":"Recite the blurred ayah without opening your normal reading page.","promptBefore":"Read the cue, then recall the ayah immediately before it.","promptAfter":"Read the cue, then recall the ayah immediately after it.","promptPage":"Use the first 3 words of the page as your cue, then recite the rest from memory.","promptSurah":"Recite the randomly selected ayah from the chosen Surah.","promptVisual":"Read the full ayah, then choose which third of the page contains it.","promptAudio":"Listen once, then recite the ayah yourself before revealing it.","practiceFromMemory":"Practice from memory.","cue":"Cue","continueNoReveal":"Continue without revealing the rest.","ayahLabel":"Ayah","reciteBeforeReveal":"Recite before revealing the answer.","pressPlay":"Press Play once, then recite from memory.","findAyah":"Find this ayah on the page","choosePageThird":"Choose the top, middle, or bottom section of Page {page}.","useFirstWords":"Use the first 3 words to recall the rest of the page.","blurredTarget":"The blurred passage is your target.","compareRevealed":"Compare your recitation with the revealed page above.","correctLocation":"Correct location","tryAnotherPosition":"Try another position","practiceStartError":"Could not start a practice test.","audioStartError":"Audio could not start.","mutashTitle":"Mutashābihāt Practice","chooseSimilarPair":"Choose a similar pair to study","compareSharedWording":"Compare the shared wording","loadingMutash":"Loading verified Mutashābihāt data…","similarPairs":"Similar pairs","verifiedPairings":"{count} verified pairings · tap a shared phrase to practice it","loadingSimilarPhrase":"Loading similar phrase…","allPairs":"All pairs","similarPhrase":"Similar phrase","sourcePassage":"Source passage","similarPassage":"Similar passage","backToList":"Back to list","openSourceMushaf":"Open source in Mushaf","hifzProgress":"Hifz Progress","yourMushafMap":"Your Mushaf map","memorized":"Memorized","reviewSoon":"Review soon","notEvaluated":"Not evaluated","ayahs":"Ayahs","notes":"Notes","loading":"Loading…","loadingPageDetails":"Loading page details…","noNotes":"No notes on this page yet.","pageMeta":"Juz {juz} · {side} · {count} ayah(s)","tapNumberOpen":"{count} ayahs · tap a number to open it","analytics":"Analytics","day":"Day","month":"Month","year":"Year","all":"All","sessions":"Sessions","strongMarks":"Strong marks","reviewMarks":"Review marks","weakMarks":"Weak marks","weakestSurahs":"Weakest Surahs","evaluateMore":"Evaluate more ayahs to build a ranking.","chooseJuz":"Choose Juz","chooseSurah":"Choose Surah","themeLight":"Light","themeDark":"Dark","themeSystem":"System","reset":"Reset","offlineAyahsAvailable":"{count} ayahs available offline","tapDownloadContinue":"Tap Download all ayahs to continue.","failed":"failed","offlineDownloadComplete":"Offline audio download complete.","offlineDownloadIncomplete":"Download finished with some missing files.","deleteAudioConfirm":"Delete all downloaded recitation audio?","downloadedAudioDeleted":"Downloaded audio deleted.","deleteOfflineError":"Could not delete offline audio.","selectAyahFirst":"Select an ayah first.","audioInternetError":"Audio could not start. Check internet access or offline download.","revealedWord":"Revealed: {word}","ayahFullyRevealed":"Ayah fully revealed.","couldNotLocateAyah":"Could not locate this ayah page.","resetConfirm":"Reset all Hifz ratings and notes?","howWellKnown":"How well did you know {surah} ({ref})?","knewWell":"I knew it well","hesitated":"I hesitated","couldntRecall":"I couldn’t recall","applyTo":"Apply to","thisAyahOnly":"This ayah only","addNoteOptional":"Add a note (optional)","noteExample":"e.g. Similar to another ayah, revise the ending…","evaluationSaved":"Evaluation saved","similarPassageFallback":"Similar passage","standard":"Standard","tajweedColors":"Tajweed Colors","single":"Page","scroll":"Scroll","twoPage":"Two page","jumpTitle":"Go to Surah / Ayah","current":"Current","surah":"Surah","ayah":"Ayah","goAyah":"Go to Ayah","mushafDisplay":"Mushaf Display","readingStyle":"Reading style","fontSize":"Arabic font size","twoPageView":"Two-page view","showPageNumbers":"Show page numbers","defaultReciter":"Default reciter","autoPlay":"Auto play next ayah","pauseAfter":"Pause after each ayah","offlineAudio":"Offline audio","offlineVoice":"Voice to download","downloadAll":"Download all ayahs","deleteAudio":"Delete downloaded audio","downloaded":"Downloaded","notDownloaded":"Not downloaded","downloading":"Downloading","resetProgress":"Reset Hifz progress","offlineData":"Offline data","cachedPages":"Page data cached as you read","audioSettings":"Audio","loadingMushafPage":"Loading Mushaf page…","loadingReadingView":"Loading reading view…","couldNotLoadMutashData":"Could not load Mutashābihāt data.","couldNotLoadPracticePage":"Could not load practice page.","couldNotRenderScreen":"Memorize Quran could not render this screen.","reload":"Reload","couldNotLoadMushafView":"Could not load this Mushaf view.","hafsPageLoadError":"Hafs Mushaf page image could not load.","selectAyahAria":"Select ayah {ref}","pageImageAlt":"Hafs Mushaf page {page}"},"ar":{"greeting":"السلام عليكم","page":"صفحة","juz":"الجزء","rightPage":"الصفحة اليمنى","leftPage":"الصفحة اليسرى","displayOptions":"خيارات عرض المصحف","selfEvaluation":"التقييم الذاتي","tapAyahFirst":"اختر آية أولاً","selectedAyah":"الآية المحددة","wholePage":"الصفحة كاملة","applyOneRating":"طبّق تقييماً واحداً على جميع آيات الصفحة {page} وعددها {count}.","strongShort":"قوي","reviewShort":"مراجعة","weakShort":"ضعيف","addNote":"إضافة ملاحظة","optionalNote":"ملاحظة اختيارية عن هذه الآية…","save":"حفظ","chooseRating":"اختر تقييماً.","pageEvaluationSaved":"تم حفظ تقييم الصفحة","ayahEvaluationSaved":"تم حفظ تقييم الآية","pageBookmarked":"تمت إضافة الصفحة إلى العلامات","bookmarkRemoved":"تمت إزالة العلامة","pageN":"صفحة {page}","ayahPageCount":"{ayahs} آية · {pages} صفحة","similarAyahPractice":"تدريب الآيات المتشابهة","currentAyahAudio":"صوت الآية الحالية","ayahAudio":"صوت الآية","repeat":"التكرار","revisionTitle":"المراجعة","basedSelfEvaluations":"بناءً على تقييماتك الذاتية","reviseFirst":"ضعيف · راجعه أولاً","needsReview":"يحتاج إلى مراجعة","emptyRevision":"قيّم الآيات من المصحف لإنشاء قائمة المراجعة.","openInMushaf":"فتح في المصحف","practiceTitle":"التدريب","practiceSubtitle":"استرجاع وذاكرة بصرية واستماع","coreRecall":"الاسترجاع الأساسي","hifzPractice":"تدريب الحفظ","listening":"الاستماع","continueAyah":"أكمل الآية","continueDesc":"شاهد الكلمات الأولى ثم أكمل الآية من الذاكرة","randomAyah":"آية عشوائية","randomDesc":"استرجع آية مخفية من صفحة اختبار عشوائية","whatBefore":"ماذا قبلها؟","beforeDesc":"استرجع الآية السابقة","whatAfter":"ماذا بعدها؟","afterDesc":"استرجع الآية التالية","pageTest":"اختبار الصفحة","pageTestDesc":"أخفِ الصفحة واقرأها من الحفظ ثم اكشفها وقيّم نفسك","surahTest":"اختبار السورة","surahTestDesc":"اختبر سورة واحدة أو نطاقاً منها","mutashPractice":"المتشابهات","mutashDesc":"تدرّب على الآيات المتشابهة","visualMemory":"الذاكرة البصرية","visualDesc":"استرجع المحتوى من موضعه الثابت في الصفحة","audioHifz":"الحفظ بالصوت","audioHifzDesc":"استمع وكرّر وتابع التلاوة","fromAyah":"من الآية","toAyah":"إلى الآية","startTest":"ابدأ الاختبار","noPracticeSession":"لا توجد جلسة تدريب.","testPageReading":"صفحة الاختبار {testPage} · موضع القراءة يبقى في الصفحة {page}","loadingCue":"جارٍ تحميل التلميح…","loadingRandomPage":"جارٍ تحميل صفحة مصحف عشوائية…","loadingAnswer":"جارٍ تحميل الإجابة…","howRecall":"كيف كان استرجاعك؟","playAyah":"تشغيل الآية","hideAnswer":"إخفاء الإجابة","revealAnswer":"إظهار الإجابة","anotherTest":"اختبار آخر","promptContinue":"اقرأ الكلمات الأولى ثم أكمل الآية من الذاكرة.","promptRandom":"اقرأ الآية المموهة من الحفظ دون فتح صفحة القراءة المعتادة.","promptBefore":"اقرأ التلميح ثم استرجع الآية التي قبله مباشرة.","promptAfter":"اقرأ التلميح ثم استرجع الآية التي بعده مباشرة.","promptPage":"استخدم أول ثلاث كلمات من الصفحة كتلميح ثم اقرأ بقية الصفحة من الحفظ.","promptSurah":"اقرأ الآية المختارة عشوائياً من السورة المحددة.","promptVisual":"اقرأ الآية كاملة ثم اختر أي ثلث من الصفحة توجد فيه.","promptAudio":"استمع مرة واحدة ثم اقرأ الآية من الحفظ قبل كشفها.","practiceFromMemory":"تدرّب من الذاكرة.","cue":"التلميح","continueNoReveal":"أكمل دون كشف بقية الآية.","ayahLabel":"آية","reciteBeforeReveal":"اقرأ من الحفظ قبل إظهار الإجابة.","pressPlay":"اضغط تشغيل مرة واحدة ثم اقرأ من الذاكرة.","findAyah":"حدّد موضع هذه الآية في الصفحة","choosePageThird":"اختر الجزء العلوي أو الأوسط أو السفلي من الصفحة {page}.","useFirstWords":"استخدم أول ثلاث كلمات لاسترجاع بقية الصفحة.","blurredTarget":"المقطع المموّه هو المطلوب.","compareRevealed":"قارن تلاوتك بالصفحة الظاهرة أعلاه.","correctLocation":"الموضع صحيح","tryAnotherPosition":"جرّب موضعاً آخر","practiceStartError":"تعذر بدء اختبار التدريب.","audioStartError":"تعذر تشغيل الصوت.","mutashTitle":"تدريب المتشابهات","chooseSimilarPair":"اختر زوجاً متشابهاً لدراسته","compareSharedWording":"قارن الألفاظ المشتركة","loadingMutash":"جارٍ تحميل بيانات المتشابهات الموثقة…","similarPairs":"الأزواج المتشابهة","verifiedPairings":"{count} زوجاً موثقاً · اضغط العبارة المشتركة للتدريب","loadingSimilarPhrase":"جارٍ تحميل العبارة المتشابهة…","allPairs":"كل الأزواج","similarPhrase":"العبارة المتشابهة","sourcePassage":"المقطع الأصلي","similarPassage":"المقطع المتشابه","backToList":"العودة إلى القائمة","openSourceMushaf":"فتح الأصل في المصحف","hifzProgress":"تقدم الحفظ","yourMushafMap":"خريطة مصحفك","memorized":"محفوظ","reviewSoon":"مراجعة قريباً","notEvaluated":"غير مقيّم","ayahs":"الآيات","notes":"الملاحظات","loading":"جارٍ التحميل…","loadingPageDetails":"جارٍ تحميل تفاصيل الصفحة…","noNotes":"لا توجد ملاحظات في هذه الصفحة بعد.","pageMeta":"الجزء {juz} · {side} · {count} آية","tapNumberOpen":"{count} آية · اضغط رقماً لفتحها","analytics":"التحليلات","day":"اليوم","month":"الشهر","year":"السنة","all":"الكل","sessions":"الجلسات","strongMarks":"علامات قوي","reviewMarks":"علامات مراجعة","weakMarks":"علامات ضعيف","weakestSurahs":"أضعف السور","evaluateMore":"قيّم مزيداً من الآيات لإنشاء الترتيب.","chooseJuz":"اختر الجزء","chooseSurah":"اختر السورة","themeLight":"فاتح","themeDark":"داكن","themeSystem":"حسب النظام","reset":"إعادة ضبط","offlineAyahsAvailable":"{count} آية متاحة دون إنترنت","tapDownloadContinue":"اضغط «تنزيل جميع الآيات» للمتابعة.","failed":"فشل","offlineDownloadComplete":"اكتمل تنزيل الصوت دون إنترنت.","offlineDownloadIncomplete":"اكتمل التنزيل مع فقد بعض الملفات.","deleteAudioConfirm":"حذف جميع ملفات التلاوة المنزّلة؟","downloadedAudioDeleted":"تم حذف الصوت المنزّل.","deleteOfflineError":"تعذر حذف الصوت دون إنترنت.","selectAyahFirst":"اختر آية أولاً.","audioInternetError":"تعذر تشغيل الصوت. تحقق من الإنترنت أو التنزيل دون إنترنت.","revealedWord":"تم إظهار: {word}","ayahFullyRevealed":"تم إظهار الآية كاملة.","couldNotLocateAyah":"تعذر العثور على صفحة هذه الآية.","resetConfirm":"إعادة ضبط جميع تقييمات الحفظ والملاحظات؟","howWellKnown":"ما مدى إتقانك لـ {surah} ({ref})؟","knewWell":"أتقنتها جيداً","hesitated":"ترددت","couldntRecall":"لم أستطع استرجاعها","applyTo":"تطبيق على","thisAyahOnly":"هذه الآية فقط","addNoteOptional":"إضافة ملاحظة (اختياري)","noteExample":"مثال: تشبه آية أخرى، راجع النهاية…","evaluationSaved":"تم حفظ التقييم","similarPassageFallback":"مقطع متشابه","standard":"عادي","tajweedColors":"ألوان التجويد","single":"صفحة","scroll":"تمرير","twoPage":"صفحتان","jumpTitle":"الانتقال إلى سورة / آية","current":"الحالي","surah":"السورة","ayah":"الآية","goAyah":"الانتقال إلى الآية","mushafDisplay":"عرض المصحف","readingStyle":"نمط العرض","fontSize":"حجم الخط العربي","twoPageView":"عرض صفحتين","showPageNumbers":"إظهار أرقام الصفحات","defaultReciter":"القارئ الافتراضي","autoPlay":"تشغيل الآية التالية تلقائياً","pauseAfter":"توقف بعد كل آية","offlineAudio":"الصوت دون إنترنت","offlineVoice":"القارئ المراد تنزيله","downloadAll":"تنزيل جميع الآيات","deleteAudio":"حذف الصوت المنزّل","downloaded":"تم التنزيل","notDownloaded":"غير منزّل","downloading":"جارٍ التنزيل","resetProgress":"إعادة ضبط تقدم الحفظ","offlineData":"بيانات دون إنترنت","cachedPages":"تُحفظ بيانات الصفحات أثناء القراءة","audioSettings":"الصوت","loadingMushafPage":"جارٍ تحميل صفحة المصحف…","loadingReadingView":"جارٍ تحميل وضع القراءة…","couldNotLoadMutashData":"تعذّر تحميل بيانات المتشابهات.","couldNotLoadPracticePage":"تعذّر تحميل صفحة التدريب.","couldNotRenderScreen":"تعذّر عرض هذه الشاشة في Memorize Quran.","reload":"إعادة التحميل","couldNotLoadMushafView":"تعذّر تحميل عرض المصحف.","hafsPageLoadError":"تعذّر تحميل صورة صفحة مصحف حفص.","selectAyahAria":"اختر الآية {ref}","pageImageAlt":"صفحة {page} من مصحف حفص"},"ur":{"greeting":"السلام علیکم","page":"صفحہ","juz":"جز","rightPage":"دایاں صفحہ","leftPage":"بایاں صفحہ","displayOptions":"مصحف کی نمائش کے اختیارات","selfEvaluation":"خود جائزہ","tapAyahFirst":"پہلے ایک آیت منتخب کریں","selectedAyah":"منتخب آیت","wholePage":"پورا صفحہ","applyOneRating":"صفحہ {page} کی تمام {count} آیات پر ایک ہی درجہ لگائیں۔","strongShort":"مضبوط","reviewShort":"دہرائی","weakShort":"کمزور","addNote":"نوٹ شامل کریں","optionalNote":"اس آیت کے بارے میں اختیاری نوٹ…","save":"محفوظ کریں","chooseRating":"ایک درجہ منتخب کریں۔","pageEvaluationSaved":"صفحے کا جائزہ محفوظ ہو گیا","ayahEvaluationSaved":"آیت کا جائزہ محفوظ ہو گیا","pageBookmarked":"صفحہ نشان زد ہو گیا","bookmarkRemoved":"نشان ہٹا دیا گیا","pageN":"صفحہ {page}","ayahPageCount":"{ayahs} آیات · {pages} صفحات","similarAyahPractice":"مشابہ آیات کی مشق","currentAyahAudio":"موجودہ آیت کی آواز","ayahAudio":"آیت کی آواز","repeat":"تکرار","revisionTitle":"دہرائی","basedSelfEvaluations":"آپ کے خود جائزوں کی بنیاد پر","reviseFirst":"کمزور · پہلے دہرائیں","needsReview":"دہرائی درکار","emptyRevision":"دہرائی کی فہرست بنانے کے لیے مصحف سے آیات کا جائزہ لیں۔","openInMushaf":"مصحف میں کھولیں","practiceTitle":"مشق","practiceSubtitle":"یاد آوری، بصری یادداشت اور سماعت","coreRecall":"بنیادی یاد آوری","hifzPractice":"حفظ کی مشق","listening":"سماعت","continueAyah":"آیت مکمل کریں","continueDesc":"ابتدائی الفاظ دیکھیں، پھر یاد سے آگے پڑھیں","randomAyah":"بے ترتیب آیت","randomDesc":"کسی بے ترتیب صفحے کی چھپی آیت یاد سے پڑھیں","whatBefore":"اس سے پہلے کیا ہے؟","beforeDesc":"پچھلی آیت یاد کریں","whatAfter":"اس کے بعد کیا ہے؟","afterDesc":"اگلی آیت یاد کریں","pageTest":"صفحہ ٹیسٹ","pageTestDesc":"صفحہ چھپائیں، یاد سے پڑھیں، پھر دکھا کر درجہ دیں","surahTest":"سورہ ٹیسٹ","surahTestDesc":"ایک سورہ یا منتخب حصہ آزمائیں","mutashPractice":"متشابہات","mutashDesc":"مشابہ آیات کی مشق کریں","visualMemory":"بصری یادداشت","visualDesc":"صفحے پر مقررہ جگہ سے مواد یاد کریں","audioHifz":"آڈیو حفظ","audioHifzDesc":"سنیں، دہرائیں اور تلاوت کے ساتھ پڑھیں","fromAyah":"آیت سے","toAyah":"آیت تک","startTest":"ٹیسٹ شروع کریں","noPracticeSession":"کوئی مشق جاری نہیں۔","testPageReading":"ٹیسٹ صفحہ {testPage} · مطالعہ کی جگہ صفحہ {page} پر رہے گی","loadingCue":"اشارہ لوڈ ہو رہا ہے…","loadingRandomPage":"بے ترتیب مصحف صفحہ لوڈ ہو رہا ہے…","loadingAnswer":"جواب لوڈ ہو رہا ہے…","howRecall":"آپ کی یاد آوری کیسی تھی؟","playAyah":"آیت چلائیں","hideAnswer":"جواب چھپائیں","revealAnswer":"جواب دکھائیں","anotherTest":"ایک اور ٹیسٹ","promptContinue":"ابتدائی الفاظ پڑھیں، پھر آیت یاد سے مکمل کریں۔","promptRandom":"اپنا عام مطالعہ صفحہ کھولے بغیر دھندلی آیت یاد سے پڑھیں۔","promptBefore":"اشارہ پڑھیں، پھر اس سے فوراً پہلے والی آیت یاد کریں۔","promptAfter":"اشارہ پڑھیں، پھر اس کے فوراً بعد والی آیت یاد کریں۔","promptPage":"صفحے کے پہلے 3 الفاظ کو اشارہ بنائیں، پھر باقی صفحہ یاد سے پڑھیں۔","promptSurah":"منتخب سورہ سے بے ترتیب آیت یاد سے پڑھیں۔","promptVisual":"پوری آیت پڑھیں، پھر صفحے کا وہ تہائی حصہ منتخب کریں جہاں یہ موجود ہے۔","promptAudio":"ایک بار سنیں، پھر دکھانے سے پہلے آیت یاد سے پڑھیں۔","practiceFromMemory":"یاد سے مشق کریں۔","cue":"اشارہ","continueNoReveal":"باقی آیت دکھائے بغیر آگے پڑھیں۔","ayahLabel":"آیت","reciteBeforeReveal":"جواب دکھانے سے پہلے یاد سے پڑھیں۔","pressPlay":"ایک بار چلائیں، پھر یاد سے پڑھیں۔","findAyah":"صفحے پر یہ آیت تلاش کریں","choosePageThird":"صفحہ {page} کا اوپر، درمیان یا نیچے والا حصہ منتخب کریں۔","useFirstWords":"باقی صفحہ یاد کرنے کے لیے پہلے 3 الفاظ استعمال کریں۔","blurredTarget":"دھندلا حصہ آپ کا ہدف ہے۔","compareRevealed":"اپنی تلاوت کو اوپر دکھائے گئے صفحے سے ملائیں۔","correctLocation":"صحیح جگہ","tryAnotherPosition":"دوسری جگہ آزمائیں","practiceStartError":"مشق ٹیسٹ شروع نہیں ہو سکا۔","audioStartError":"آڈیو شروع نہیں ہو سکا۔","mutashTitle":"متشابہات کی مشق","chooseSimilarPair":"مطالعے کے لیے مشابہ جوڑا منتخب کریں","compareSharedWording":"مشترک الفاظ کا موازنہ کریں","loadingMutash":"تصدیق شدہ متشابہات ڈیٹا لوڈ ہو رہا ہے…","similarPairs":"مشابہ جوڑے","verifiedPairings":"{count} تصدیق شدہ جوڑے · مشق کے لیے مشترک عبارت دبائیں","loadingSimilarPhrase":"مشابہ عبارت لوڈ ہو رہی ہے…","allPairs":"تمام جوڑے","similarPhrase":"مشابہ عبارت","sourcePassage":"اصل عبارت","similarPassage":"مشابہ عبارت","backToList":"فہرست پر واپس","openSourceMushaf":"اصل کو مصحف میں کھولیں","hifzProgress":"حفظ کی پیش رفت","yourMushafMap":"آپ کا مصحف نقشہ","memorized":"یاد شدہ","reviewSoon":"جلد دہرائی","notEvaluated":"جائزہ نہیں لیا","ayahs":"آیات","notes":"نوٹس","loading":"لوڈ ہو رہا ہے…","loadingPageDetails":"صفحے کی تفصیل لوڈ ہو رہی ہے…","noNotes":"اس صفحے پر ابھی کوئی نوٹ نہیں۔","pageMeta":"جز {juz} · {side} · {count} آیات","tapNumberOpen":"{count} آیات · کھولنے کے لیے نمبر دبائیں","analytics":"تجزیات","day":"دن","month":"مہینہ","year":"سال","all":"سب","sessions":"سیشن","strongMarks":"مضبوط نشانات","reviewMarks":"دہرائی کے نشانات","weakMarks":"کمزور نشانات","weakestSurahs":"کمزور ترین سورتیں","evaluateMore":"درجہ بندی بنانے کے لیے مزید آیات کا جائزہ لیں۔","chooseJuz":"جز منتخب کریں","chooseSurah":"سورہ منتخب کریں","themeLight":"روشن","themeDark":"گہرا","themeSystem":"سسٹم","reset":"ری سیٹ","offlineAyahsAvailable":"{count} آیات آف لائن دستیاب ہیں","tapDownloadContinue":"جاری رکھنے کے لیے تمام آیات ڈاؤن لوڈ کریں دبائیں۔","failed":"ناکام","offlineDownloadComplete":"آف لائن آڈیو ڈاؤن لوڈ مکمل ہو گیا۔","offlineDownloadIncomplete":"ڈاؤن لوڈ مکمل ہوا، کچھ فائلیں غائب ہیں۔","deleteAudioConfirm":"تمام ڈاؤن لوڈ شدہ تلاوت آڈیو حذف کریں؟","downloadedAudioDeleted":"ڈاؤن لوڈ شدہ آڈیو حذف ہو گیا۔","deleteOfflineError":"آف لائن آڈیو حذف نہیں ہو سکا۔","selectAyahFirst":"پہلے ایک آیت منتخب کریں۔","audioInternetError":"آڈیو شروع نہیں ہو سکا۔ انٹرنیٹ یا آف لائن ڈاؤن لوڈ چیک کریں۔","revealedWord":"دکھایا گیا: {word}","ayahFullyRevealed":"پوری آیت دکھا دی گئی ہے۔","couldNotLocateAyah":"اس آیت کا صفحہ نہیں مل سکا۔","resetConfirm":"تمام حفظ درجات اور نوٹس ری سیٹ کریں؟","howWellKnown":"آپ نے {surah} ({ref}) کتنی اچھی طرح یاد کی؟","knewWell":"اچھی طرح یاد تھا","hesitated":"میں جھجکا","couldntRecall":"یاد نہیں آ سکا","applyTo":"لاگو کریں","thisAyahOnly":"صرف یہ آیت","addNoteOptional":"نوٹ شامل کریں (اختیاری)","noteExample":"مثلاً دوسری آیت سے مشابہ، آخر دہرائیں…","evaluationSaved":"جائزہ محفوظ ہو گیا","similarPassageFallback":"مشابہ عبارت","standard":"سادہ","tajweedColors":"تجوید کے رنگ","single":"صفحہ","scroll":"اسکرول","twoPage":"دو صفحات","jumpTitle":"سورہ / آیت پر جائیں","current":"موجودہ","surah":"سورہ","ayah":"آیت","goAyah":"آیت پر جائیں","mushafDisplay":"مصحف ڈسپلے","readingStyle":"مطالعہ انداز","fontSize":"عربی فونٹ کا سائز","twoPageView":"دو صفحات کا منظر","showPageNumbers":"صفحہ نمبر دکھائیں","defaultReciter":"پہلے سے منتخب قاری","autoPlay":"اگلی آیت خود چلائیں","pauseAfter":"ہر آیت کے بعد وقفہ","offlineAudio":"آف لائن آڈیو","offlineVoice":"ڈاؤن لوڈ کے لیے قاری","downloadAll":"تمام آیات ڈاؤن لوڈ کریں","deleteAudio":"ڈاؤن لوڈ شدہ آڈیو حذف کریں","downloaded":"ڈاؤن لوڈ شدہ","notDownloaded":"ڈاؤن لوڈ نہیں ہوا","downloading":"ڈاؤن لوڈ ہو رہا ہے","resetProgress":"حفظ کی پیش رفت ری سیٹ کریں","offlineData":"آف لائن ڈیٹا","cachedPages":"پڑھتے ہوئے صفحہ ڈیٹا محفوظ ہوتا ہے","audioSettings":"آڈیو","loadingMushafPage":"مصحف کا صفحہ لوڈ ہو رہا ہے…","loadingReadingView":"پڑھنے کا منظر لوڈ ہو رہا ہے…","couldNotLoadMutashData":"متشابہات کا ڈیٹا لوڈ نہیں ہو سکا۔","couldNotLoadPracticePage":"مشق کا صفحہ لوڈ نہیں ہو سکا۔","couldNotRenderScreen":"Memorize Quran یہ اسکرین دکھا نہیں سکا۔","reload":"دوبارہ لوڈ کریں","couldNotLoadMushafView":"مصحف کا منظر لوڈ نہیں ہو سکا۔","hafsPageLoadError":"حفص مصحف کے صفحے کی تصویر لوڈ نہیں ہو سکی۔","selectAyahAria":"آیت {ref} منتخب کریں","pageImageAlt":"حفص مصحف صفحہ {page}"},"id":{"greeting":"Assalamu’alaikum","page":"Halaman","juz":"Juz","rightPage":"Halaman kanan","leftPage":"Halaman kiri","displayOptions":"Opsi tampilan Mushaf","selfEvaluation":"Evaluasi Diri","tapAyahFirst":"Ketuk ayat terlebih dahulu","selectedAyah":"Ayat terpilih","wholePage":"Seluruh halaman","applyOneRating":"Terapkan satu penilaian ke semua {count} ayat pada Halaman {page}.","strongShort":"Kuat","reviewShort":"Ulangi","weakShort":"Lemah","addNote":"Tambah catatan","optionalNote":"Catatan opsional tentang ayat ini…","save":"Simpan","chooseRating":"Pilih penilaian.","pageEvaluationSaved":"Evaluasi halaman disimpan","ayahEvaluationSaved":"Evaluasi ayat disimpan","pageBookmarked":"Halaman ditandai","bookmarkRemoved":"Penanda dihapus","pageN":"Halaman {page}","ayahPageCount":"{ayahs} ayat · {pages} halaman","similarAyahPractice":"Latihan ayat serupa","currentAyahAudio":"Audio ayat saat ini","ayahAudio":"Audio Ayat","repeat":"Ulangi","revisionTitle":"Murajaah","basedSelfEvaluations":"Berdasarkan evaluasi diri Anda","reviseFirst":"Lemah · ulangi lebih dulu","needsReview":"Perlu diulang","emptyRevision":"Nilai ayat dari Mushaf untuk membuat antrean murajaah.","openInMushaf":"Buka di Mushaf","practiceTitle":"Latihan","practiceSubtitle":"Daya ingat, memori visual, dan mendengarkan","coreRecall":"Daya Ingat Inti","hifzPractice":"Latihan Hifz","listening":"Mendengarkan","continueAyah":"Lanjutkan Ayat","continueDesc":"Lihat kata awal, lalu lanjutkan dari ingatan","randomAyah":"Ayat Acak","randomDesc":"Ingat ayat tersembunyi dari halaman uji acak","whatBefore":"Apa Sebelumnya?","beforeDesc":"Ingat ayat sebelumnya","whatAfter":"Apa Sesudahnya?","afterDesc":"Ingat ayat berikutnya","pageTest":"Tes Halaman","pageTestDesc":"Sembunyikan halaman, baca dari hafalan, lalu buka dan nilai","surahTest":"Tes Surah","surahTestDesc":"Uji satu Surah atau rentang","mutashPractice":"Mutasyabihat","mutashDesc":"Latih ayat-ayat serupa","visualMemory":"Memori Visual","visualDesc":"Ingat isi dari posisi tetapnya di halaman","audioHifz":"Hifz Audio","audioHifzDesc":"Dengar, ulangi, dan ikuti bacaan","fromAyah":"Dari ayat","toAyah":"Sampai ayat","startTest":"Mulai tes","noPracticeSession":"Tidak ada sesi latihan.","testPageReading":"Halaman tes {testPage} · posisi baca tetap di Halaman {page}","loadingCue":"Memuat petunjuk…","loadingRandomPage":"Memuat halaman Mushaf acak…","loadingAnswer":"Memuat jawaban…","howRecall":"Bagaimana ingatan Anda?","playAyah":"Putar ayat","hideAnswer":"Sembunyikan jawaban","revealAnswer":"Tampilkan jawaban","anotherTest":"Tes lain","promptContinue":"Baca kata pembuka, lalu lanjutkan ayat dari ingatan.","promptRandom":"Baca ayat yang diburamkan tanpa membuka halaman baca biasa.","promptBefore":"Baca petunjuk, lalu ingat ayat tepat sebelumnya.","promptAfter":"Baca petunjuk, lalu ingat ayat tepat sesudahnya.","promptPage":"Gunakan 3 kata pertama halaman sebagai petunjuk, lalu baca sisanya dari hafalan.","promptSurah":"Baca ayat acak dari Surah yang dipilih.","promptVisual":"Baca ayat lengkap, lalu pilih sepertiga halaman tempat ayat berada.","promptAudio":"Dengar sekali, lalu baca ayat sendiri sebelum membukanya.","practiceFromMemory":"Latihan dari ingatan.","cue":"Petunjuk","continueNoReveal":"Lanjutkan tanpa membuka sisanya.","ayahLabel":"Ayat","reciteBeforeReveal":"Baca sebelum menampilkan jawaban.","pressPlay":"Tekan Putar sekali, lalu baca dari ingatan.","findAyah":"Temukan ayat ini di halaman","choosePageThird":"Pilih bagian atas, tengah, atau bawah Halaman {page}.","useFirstWords":"Gunakan 3 kata pertama untuk mengingat sisa halaman.","blurredTarget":"Bagian buram adalah target Anda.","compareRevealed":"Bandingkan bacaan Anda dengan halaman yang ditampilkan di atas.","correctLocation":"Lokasi benar","tryAnotherPosition":"Coba posisi lain","practiceStartError":"Tes latihan tidak dapat dimulai.","audioStartError":"Audio tidak dapat diputar.","mutashTitle":"Latihan Mutasyabihat","chooseSimilarPair":"Pilih pasangan serupa untuk dipelajari","compareSharedWording":"Bandingkan lafaz yang sama","loadingMutash":"Memuat data Mutasyabihat terverifikasi…","similarPairs":"Pasangan serupa","verifiedPairings":"{count} pasangan terverifikasi · ketuk frasa yang sama untuk berlatih","loadingSimilarPhrase":"Memuat frasa serupa…","allPairs":"Semua pasangan","similarPhrase":"Frasa serupa","sourcePassage":"Bagian sumber","similarPassage":"Bagian serupa","backToList":"Kembali ke daftar","openSourceMushaf":"Buka sumber di Mushaf","hifzProgress":"Progres Hifz","yourMushafMap":"Peta Mushaf Anda","memorized":"Hafal","reviewSoon":"Segera diulang","notEvaluated":"Belum dinilai","ayahs":"Ayat","notes":"Catatan","loading":"Memuat…","loadingPageDetails":"Memuat detail halaman…","noNotes":"Belum ada catatan di halaman ini.","pageMeta":"Juz {juz} · {side} · {count} ayat","tapNumberOpen":"{count} ayat · ketuk nomor untuk membukanya","analytics":"Analitik","day":"Hari","month":"Bulan","year":"Tahun","all":"Semua","sessions":"Sesi","strongMarks":"Tanda kuat","reviewMarks":"Tanda ulangi","weakMarks":"Tanda lemah","weakestSurahs":"Surah Terlemah","evaluateMore":"Nilai lebih banyak ayat untuk membuat peringkat.","chooseJuz":"Pilih Juz","chooseSurah":"Pilih Surah","themeLight":"Terang","themeDark":"Gelap","themeSystem":"Sistem","reset":"Atur ulang","offlineAyahsAvailable":"{count} ayat tersedia offline","tapDownloadContinue":"Ketuk Unduh semua ayat untuk melanjutkan.","failed":"gagal","offlineDownloadComplete":"Unduhan audio offline selesai.","offlineDownloadIncomplete":"Unduhan selesai dengan beberapa file yang belum tersedia.","deleteAudioConfirm":"Hapus semua audio bacaan yang diunduh?","downloadedAudioDeleted":"Audio yang diunduh telah dihapus.","deleteOfflineError":"Audio offline tidak dapat dihapus.","selectAyahFirst":"Pilih ayat terlebih dahulu.","audioInternetError":"Audio tidak dapat diputar. Periksa internet atau unduhan offline.","revealedWord":"Ditampilkan: {word}","ayahFullyRevealed":"Seluruh ayat sudah ditampilkan.","couldNotLocateAyah":"Halaman ayat ini tidak dapat ditemukan.","resetConfirm":"Atur ulang semua penilaian Hifz dan catatan?","howWellKnown":"Seberapa baik Anda mengingat {surah} ({ref})?","knewWell":"Saya mengingatnya dengan baik","hesitated":"Saya ragu","couldntRecall":"Saya tidak dapat mengingat","applyTo":"Terapkan ke","thisAyahOnly":"Ayat ini saja","addNoteOptional":"Tambah catatan (opsional)","noteExample":"mis. Mirip ayat lain, ulangi bagian akhir…","evaluationSaved":"Evaluasi disimpan","similarPassageFallback":"Bagian serupa","standard":"Standar","tajweedColors":"Warna Tajwid","single":"Halaman","scroll":"Gulir","twoPage":"Dua halaman","jumpTitle":"Ke Surah / Ayat","current":"Saat ini","surah":"Surah","ayah":"Ayat","goAyah":"Ke Ayat","mushafDisplay":"Tampilan Mushaf","readingStyle":"Gaya membaca","fontSize":"Ukuran huruf Arab","twoPageView":"Tampilan dua halaman","showPageNumbers":"Tampilkan nomor halaman","defaultReciter":"Qari bawaan","autoPlay":"Putar ayat berikutnya otomatis","pauseAfter":"Jeda setelah setiap ayat","offlineAudio":"Audio offline","offlineVoice":"Qari untuk diunduh","downloadAll":"Unduh semua ayat","deleteAudio":"Hapus audio unduhan","downloaded":"Sudah diunduh","notDownloaded":"Belum diunduh","downloading":"Mengunduh","resetProgress":"Atur ulang progres Hifz","offlineData":"Data offline","cachedPages":"Data halaman disimpan saat dibaca","audioSettings":"Audio","loadingMushafPage":"Memuat halaman Mushaf…","loadingReadingView":"Memuat tampilan membaca…","couldNotLoadMutashData":"Data Mutasyabihat tidak dapat dimuat.","couldNotLoadPracticePage":"Halaman latihan tidak dapat dimuat.","couldNotRenderScreen":"Memorize Quran tidak dapat menampilkan layar ini.","reload":"Muat ulang","couldNotLoadMushafView":"Tampilan Mushaf tidak dapat dimuat.","hafsPageLoadError":"Gambar halaman Mushaf Hafs tidak dapat dimuat.","selectAyahAria":"Pilih ayat {ref}","pageImageAlt":"Halaman Mushaf Hafs {page}"},"ms":{"greeting":"Assalamualaikum","page":"Halaman","juz":"Juz","rightPage":"Halaman kanan","leftPage":"Halaman kiri","displayOptions":"Pilihan paparan Mushaf","selfEvaluation":"Penilaian Kendiri","tapAyahFirst":"Tekan ayat dahulu","selectedAyah":"Ayat dipilih","wholePage":"Seluruh halaman","applyOneRating":"Gunakan satu penilaian untuk semua {count} ayat pada Halaman {page}.","strongShort":"Kuat","reviewShort":"Ulang kaji","weakShort":"Lemah","addNote":"Tambah nota","optionalNote":"Nota pilihan tentang ayat ini…","save":"Simpan","chooseRating":"Pilih penilaian.","pageEvaluationSaved":"Penilaian halaman disimpan","ayahEvaluationSaved":"Penilaian ayat disimpan","pageBookmarked":"Halaman ditanda","bookmarkRemoved":"Penanda dibuang","pageN":"Halaman {page}","ayahPageCount":"{ayahs} ayat · {pages} halaman","similarAyahPractice":"Latihan ayat serupa","currentAyahAudio":"Audio ayat semasa","ayahAudio":"Audio Ayat","repeat":"Ulang","revisionTitle":"Ulang Kaji","basedSelfEvaluations":"Berdasarkan penilaian kendiri anda","reviseFirst":"Lemah · ulang kaji dahulu","needsReview":"Perlu ulang kaji","emptyRevision":"Nilai ayat dalam Mushaf untuk membina senarai ulang kaji.","openInMushaf":"Buka dalam Mushaf","practiceTitle":"Latihan","practiceSubtitle":"Ingatan, memori visual dan mendengar","coreRecall":"Ingatan Teras","hifzPractice":"Latihan Hifz","listening":"Mendengar","continueAyah":"Sambung Ayat","continueDesc":"Lihat perkataan awal, kemudian sambung dari ingatan","randomAyah":"Ayat Rawak","randomDesc":"Ingat ayat tersembunyi dari halaman ujian rawak","whatBefore":"Apa Sebelumnya?","beforeDesc":"Ingat ayat sebelumnya","whatAfter":"Apa Selepasnya?","afterDesc":"Ingat ayat seterusnya","pageTest":"Ujian Halaman","pageTestDesc":"Sembunyikan halaman, baca dari hafalan, kemudian dedah dan nilai","surahTest":"Ujian Surah","surahTestDesc":"Uji satu Surah atau julat","mutashPractice":"Mutasyabihat","mutashDesc":"Latih ayat yang serupa","visualMemory":"Memori Visual","visualDesc":"Ingat kandungan dari kedudukan tetap pada halaman","audioHifz":"Hifz Audio","audioHifzDesc":"Dengar, ulang dan ikuti bacaan","fromAyah":"Dari ayat","toAyah":"Hingga ayat","startTest":"Mula ujian","noPracticeSession":"Tiada sesi latihan.","testPageReading":"Halaman ujian {testPage} · kemajuan bacaan kekal pada Halaman {page}","loadingCue":"Memuat petunjuk…","loadingRandomPage":"Memuat halaman Mushaf rawak…","loadingAnswer":"Memuat jawapan…","howRecall":"Bagaimana ingatan anda?","playAyah":"Mainkan ayat","hideAnswer":"Sembunyikan jawapan","revealAnswer":"Tunjukkan jawapan","anotherTest":"Ujian lain","promptContinue":"Baca perkataan awal, kemudian sambung ayat dari ingatan.","promptRandom":"Baca ayat kabur tanpa membuka halaman bacaan biasa.","promptBefore":"Baca petunjuk, kemudian ingat ayat tepat sebelumnya.","promptAfter":"Baca petunjuk, kemudian ingat ayat tepat selepasnya.","promptPage":"Gunakan 3 perkataan pertama halaman sebagai petunjuk, kemudian baca selebihnya dari hafalan.","promptSurah":"Baca ayat rawak daripada Surah yang dipilih.","promptVisual":"Baca ayat penuh, kemudian pilih satu pertiga halaman tempat ayat itu berada.","promptAudio":"Dengar sekali, kemudian baca ayat dari ingatan sebelum mendedahkannya.","practiceFromMemory":"Berlatih dari ingatan.","cue":"Petunjuk","continueNoReveal":"Sambung tanpa mendedahkan selebihnya.","ayahLabel":"Ayat","reciteBeforeReveal":"Baca sebelum menunjukkan jawapan.","pressPlay":"Tekan Main sekali, kemudian baca dari ingatan.","findAyah":"Cari ayat ini pada halaman","choosePageThird":"Pilih bahagian atas, tengah atau bawah Halaman {page}.","useFirstWords":"Gunakan 3 perkataan pertama untuk mengingat baki halaman.","blurredTarget":"Bahagian kabur ialah sasaran anda.","compareRevealed":"Bandingkan bacaan anda dengan halaman yang didedahkan di atas.","correctLocation":"Lokasi betul","tryAnotherPosition":"Cuba kedudukan lain","practiceStartError":"Ujian latihan tidak dapat dimulakan.","audioStartError":"Audio tidak dapat dimulakan.","mutashTitle":"Latihan Mutasyabihat","chooseSimilarPair":"Pilih pasangan serupa untuk dipelajari","compareSharedWording":"Bandingkan lafaz yang sama","loadingMutash":"Memuat data Mutasyabihat yang disahkan…","similarPairs":"Pasangan serupa","verifiedPairings":"{count} pasangan disahkan · tekan frasa sama untuk berlatih","loadingSimilarPhrase":"Memuat frasa serupa…","allPairs":"Semua pasangan","similarPhrase":"Frasa serupa","sourcePassage":"Petikan sumber","similarPassage":"Petikan serupa","backToList":"Kembali ke senarai","openSourceMushaf":"Buka sumber dalam Mushaf","hifzProgress":"Kemajuan Hifz","yourMushafMap":"Peta Mushaf anda","memorized":"Dihafaz","reviewSoon":"Ulang kaji segera","notEvaluated":"Belum dinilai","ayahs":"Ayat","notes":"Nota","loading":"Memuat…","loadingPageDetails":"Memuat butiran halaman…","noNotes":"Belum ada nota pada halaman ini.","pageMeta":"Juz {juz} · {side} · {count} ayat","tapNumberOpen":"{count} ayat · tekan nombor untuk membukanya","analytics":"Analitik","day":"Hari","month":"Bulan","year":"Tahun","all":"Semua","sessions":"Sesi","strongMarks":"Tanda kuat","reviewMarks":"Tanda ulang kaji","weakMarks":"Tanda lemah","weakestSurahs":"Surah Paling Lemah","evaluateMore":"Nilai lebih banyak ayat untuk membina kedudukan.","chooseJuz":"Pilih Juz","chooseSurah":"Pilih Surah","themeLight":"Cerah","themeDark":"Gelap","themeSystem":"Sistem","reset":"Set semula","offlineAyahsAvailable":"{count} ayat tersedia luar talian","tapDownloadContinue":"Tekan Muat turun semua ayat untuk meneruskan.","failed":"gagal","offlineDownloadComplete":"Muat turun audio luar talian selesai.","offlineDownloadIncomplete":"Muat turun selesai dengan beberapa fail yang tiada.","deleteAudioConfirm":"Padam semua audio bacaan yang dimuat turun?","downloadedAudioDeleted":"Audio yang dimuat turun telah dipadam.","deleteOfflineError":"Audio luar talian tidak dapat dipadam.","selectAyahFirst":"Pilih ayat dahulu.","audioInternetError":"Audio tidak dapat dimulakan. Semak internet atau muat turun luar talian.","revealedWord":"Ditunjukkan: {word}","ayahFullyRevealed":"Seluruh ayat telah ditunjukkan.","couldNotLocateAyah":"Halaman ayat ini tidak dapat ditemui.","resetConfirm":"Set semula semua penilaian Hifz dan nota?","howWellKnown":"Sejauh mana anda mengingati {surah} ({ref})?","knewWell":"Saya mengingatinya dengan baik","hesitated":"Saya teragak-agak","couldntRecall":"Saya tidak dapat mengingat","applyTo":"Gunakan pada","thisAyahOnly":"Ayat ini sahaja","addNoteOptional":"Tambah nota (pilihan)","noteExample":"cth. Serupa ayat lain, ulang kaji penghujung…","evaluationSaved":"Penilaian disimpan","similarPassageFallback":"Petikan serupa","standard":"Biasa","tajweedColors":"Warna Tajwid","single":"Halaman","scroll":"Tatal","twoPage":"Dua halaman","jumpTitle":"Pergi ke Surah / Ayat","current":"Semasa","surah":"Surah","ayah":"Ayat","goAyah":"Pergi ke Ayat","mushafDisplay":"Paparan Mushaf","readingStyle":"Gaya bacaan","fontSize":"Saiz fon Arab","twoPageView":"Paparan dua halaman","showPageNumbers":"Tunjuk nombor halaman","defaultReciter":"Qari lalai","autoPlay":"Mainkan ayat seterusnya automatik","pauseAfter":"Jeda selepas setiap ayat","offlineAudio":"Audio luar talian","offlineVoice":"Qari untuk dimuat turun","downloadAll":"Muat turun semua ayat","deleteAudio":"Padam audio dimuat turun","downloaded":"Dimuat turun","notDownloaded":"Belum dimuat turun","downloading":"Sedang memuat turun","resetProgress":"Set semula kemajuan Hifz","offlineData":"Data luar talian","cachedPages":"Data halaman disimpan semasa anda membaca","audioSettings":"Audio","loadingMushafPage":"Memuatkan halaman Mushaf…","loadingReadingView":"Memuatkan paparan bacaan…","couldNotLoadMutashData":"Data Mutasyabihat tidak dapat dimuatkan.","couldNotLoadPracticePage":"Halaman latihan tidak dapat dimuatkan.","couldNotRenderScreen":"Memorize Quran tidak dapat memaparkan skrin ini.","reload":"Muat semula","couldNotLoadMushafView":"Paparan Mushaf tidak dapat dimuatkan.","hafsPageLoadError":"Imej halaman Mushaf Hafs tidak dapat dimuatkan.","selectAyahAria":"Pilih ayat {ref}","pageImageAlt":"Halaman Mushaf Hafs {page}"},"bn":{"greeting":"আসসালামু আলাইকুম","page":"পৃষ্ঠা","juz":"জুয","rightPage":"ডান পৃষ্ঠা","leftPage":"বাম পৃষ্ঠা","displayOptions":"মুসহাফ প্রদর্শন বিকল্প","selfEvaluation":"স্ব-মূল্যায়ন","tapAyahFirst":"প্রথমে একটি আয়াত নির্বাচন করুন","selectedAyah":"নির্বাচিত আয়াত","wholePage":"পুরো পৃষ্ঠা","applyOneRating":"পৃষ্ঠা {page}-এর সব {count} আয়াতে একই মূল্যায়ন দিন।","strongShort":"শক্তিশালী","reviewShort":"পুনরাবৃত্তি","weakShort":"দুর্বল","addNote":"নোট যোগ করুন","optionalNote":"এই আয়াত সম্পর্কে ঐচ্ছিক নোট…","save":"সংরক্ষণ","chooseRating":"একটি মূল্যায়ন বেছে নিন।","pageEvaluationSaved":"পৃষ্ঠা মূল্যায়ন সংরক্ষিত হয়েছে","ayahEvaluationSaved":"আয়াত মূল্যায়ন সংরক্ষিত হয়েছে","pageBookmarked":"পৃষ্ঠা বুকমার্ক করা হয়েছে","bookmarkRemoved":"বুকমার্ক সরানো হয়েছে","pageN":"পৃষ্ঠা {page}","ayahPageCount":"{ayahs} আয়াত · {pages} পৃষ্ঠা","similarAyahPractice":"সদৃশ আয়াত অনুশীলন","currentAyahAudio":"বর্তমান আয়াতের অডিও","ayahAudio":"আয়াত অডিও","repeat":"পুনরাবৃত্তি","revisionTitle":"পুনরাবৃত্তি","basedSelfEvaluations":"আপনার স্ব-মূল্যায়নের ভিত্তিতে","reviseFirst":"দুর্বল · আগে পুনরাবৃত্তি করুন","needsReview":"পুনরাবৃত্তি দরকার","emptyRevision":"পুনরাবৃত্তির তালিকা তৈরির জন্য মুসহাফ থেকে আয়াত মূল্যায়ন করুন।","openInMushaf":"মুসহাফে খুলুন","practiceTitle":"অনুশীলন","practiceSubtitle":"স্মরণ, দৃশ্যমান স্মৃতি ও শোনা","coreRecall":"মূল স্মরণ","hifzPractice":"হিফজ অনুশীলন","listening":"শোনা","continueAyah":"আয়াত চালিয়ে যান","continueDesc":"শুরুর শব্দ দেখুন, তারপর স্মৃতি থেকে চালিয়ে যান","randomAyah":"এলোমেলো আয়াত","randomDesc":"এলোমেলো পরীক্ষার পৃষ্ঠা থেকে লুকানো আয়াত স্মরণ করুন","whatBefore":"আগে কী আছে?","beforeDesc":"আগের আয়াত স্মরণ করুন","whatAfter":"পরে কী আছে?","afterDesc":"পরের আয়াত স্মরণ করুন","pageTest":"পৃষ্ঠা পরীক্ষা","pageTestDesc":"পৃষ্ঠা লুকিয়ে মুখস্থ পড়ুন, তারপর দেখিয়ে মূল্যায়ন করুন","surahTest":"সূরা পরীক্ষা","surahTestDesc":"একটি সূরা বা পরিসর পরীক্ষা করুন","mutashPractice":"মুতাশাবিহাত","mutashDesc":"সদৃশ আয়াত অনুশীলন করুন","visualMemory":"দৃশ্যমান স্মৃতি","visualDesc":"পৃষ্ঠাে নির্দিষ্ট অবস্থান থেকে বিষয় স্মরণ করুন","audioHifz":"অডিও হিফজ","audioHifzDesc":"শুনুন, পুনরাবৃত্তি করুন এবং তিলাওয়াত অনুসরণ করুন","fromAyah":"আয়াত থেকে","toAyah":"আয়াত পর্যন্ত","startTest":"পরীক্ষা শুরু","noPracticeSession":"কোনো অনুশীলন সেশন নেই।","testPageReading":"পরীক্ষার পৃষ্ঠা {testPage} · পড়ার অগ্রগতি পৃষ্ঠা {page}-এ থাকবে","loadingCue":"ইঙ্গিত লোড হচ্ছে…","loadingRandomPage":"এলোমেলো মুসহাফ পৃষ্ঠা লোড হচ্ছে…","loadingAnswer":"উত্তর লোড হচ্ছে…","howRecall":"আপনার স্মরণ কেমন ছিল?","playAyah":"আয়াত চালান","hideAnswer":"উত্তর লুকান","revealAnswer":"উত্তর দেখান","anotherTest":"আরেকটি পরীক্ষা","promptContinue":"শুরুর শব্দ পড়ুন, তারপর স্মৃতি থেকে আয়াত চালিয়ে যান।","promptRandom":"স্বাভাবিক পড়ার পৃষ্ঠা না খুলে ঝাপসা আয়াতটি মুখস্থ পড়ুন।","promptBefore":"ইঙ্গিত পড়ুন, তারপর ঠিক আগের আয়াতটি স্মরণ করুন।","promptAfter":"ইঙ্গিত পড়ুন, তারপর ঠিক পরের আয়াতটি স্মরণ করুন।","promptPage":"পৃষ্ঠাের প্রথম 3 শব্দকে ইঙ্গিত হিসেবে ব্যবহার করে বাকি অংশ মুখস্থ পড়ুন।","promptSurah":"নির্বাচিত সূরা থেকে এলোমেলো আয়াতটি পড়ুন।","promptVisual":"পুরো আয়াত পড়ুন, তারপর পৃষ্ঠাের কোন তৃতীয়াংশে আছে তা বেছে নিন।","promptAudio":"একবার শুনুন, তারপর দেখানোর আগে স্মৃতি থেকে আয়াত পড়ুন।","practiceFromMemory":"স্মৃতি থেকে অনুশীলন করুন।","cue":"ইঙ্গিত","continueNoReveal":"বাকি অংশ না দেখিয়ে চালিয়ে যান।","ayahLabel":"আয়াত","reciteBeforeReveal":"উত্তর দেখানোর আগে পড়ুন।","pressPlay":"একবার চালান, তারপর স্মৃতি থেকে পড়ুন।","findAyah":"পৃষ্ঠাে এই আয়াতটি খুঁজুন","choosePageThird":"পৃষ্ঠা {page}-এর উপরের, মাঝের বা নিচের অংশ বেছে নিন।","useFirstWords":"বাকি পৃষ্ঠা স্মরণ করতে প্রথম 3 শব্দ ব্যবহার করুন।","blurredTarget":"ঝাপসা অংশটাই আপনার লক্ষ্য।","compareRevealed":"উপরের প্রদর্শিত পৃষ্ঠার সঙ্গে আপনার তিলাওয়াত মিলিয়ে দেখুন।","correctLocation":"সঠিক অবস্থান","tryAnotherPosition":"আরেকটি অবস্থান চেষ্টা করুন","practiceStartError":"অনুশীলন পরীক্ষা শুরু করা যায়নি।","audioStartError":"অডিও চালু করা যায়নি।","mutashTitle":"মুতাশাবিহাত অনুশীলন","chooseSimilarPair":"অধ্যয়নের জন্য একটি সদৃশ জোড়া বেছে নিন","compareSharedWording":"একই শব্দগুচ্ছ তুলনা করুন","loadingMutash":"যাচাইকৃত মুতাশাবিহাত ডেটা লোড হচ্ছে…","similarPairs":"সদৃশ জোড়া","verifiedPairings":"{count} যাচাইকৃত জোড়া · অনুশীলনের জন্য একই বাক্যাংশে চাপুন","loadingSimilarPhrase":"সদৃশ বাক্যাংশ লোড হচ্ছে…","allPairs":"সব জোড়া","similarPhrase":"সদৃশ বাক্যাংশ","sourcePassage":"মূল অংশ","similarPassage":"সদৃশ অংশ","backToList":"তালিকায় ফিরুন","openSourceMushaf":"মূল অংশ মুসহাফে খুলুন","hifzProgress":"হিফজ অগ্রগতি","yourMushafMap":"আপনার মুসহাফ মানচিত্র","memorized":"মুখস্থ","reviewSoon":"শিগগির পুনরাবৃত্তি","notEvaluated":"মূল্যায়ন হয়নি","ayahs":"আয়াত","notes":"নোট","loading":"লোড হচ্ছে…","loadingPageDetails":"পৃষ্ঠাের বিস্তারিত লোড হচ্ছে…","noNotes":"এই পৃষ্ঠায় এখনো কোনো নোট নেই।","pageMeta":"জুয {juz} · {side} · {count} আয়াত","tapNumberOpen":"{count} আয়াত · খুলতে নম্বরে চাপুন","analytics":"বিশ্লেষণ","day":"দিন","month":"মাস","year":"বছর","all":"সব","sessions":"সেশন","strongMarks":"শক্তিশালী চিহ্ন","reviewMarks":"পুনরাবৃত্তির চিহ্ন","weakMarks":"দুর্বল চিহ্ন","weakestSurahs":"সবচেয়ে দুর্বল সূরা","evaluateMore":"র‌্যাঙ্কিং তৈরি করতে আরও আয়াত মূল্যায়ন করুন।","chooseJuz":"জুয বেছে নিন","chooseSurah":"সূরা বেছে নিন","themeLight":"হালকা","themeDark":"গাঢ়","themeSystem":"সিস্টেম","reset":"রিসেট","offlineAyahsAvailable":"{count} আয়াত অফলাইনে উপলভ্য","tapDownloadContinue":"চালিয়ে যেতে সব আয়াত ডাউনলোড করুন চাপুন।","failed":"ব্যর্থ","offlineDownloadComplete":"অফলাইন অডিও ডাউনলোড সম্পন্ন হয়েছে।","offlineDownloadIncomplete":"কিছু ফাইল বাদ দিয়ে ডাউনলোড সম্পন্ন হয়েছে।","deleteAudioConfirm":"সব ডাউনলোড করা তিলাওয়াত অডিও মুছবেন?","downloadedAudioDeleted":"ডাউনলোড করা অডিও মুছে ফেলা হয়েছে।","deleteOfflineError":"অফলাইন অডিও মুছতে পারেনি।","selectAyahFirst":"প্রথমে একটি আয়াত নির্বাচন করুন।","audioInternetError":"অডিও চালু করা যায়নি। ইন্টারনেট বা অফলাইন ডাউনলোড পরীক্ষা করুন।","revealedWord":"দেখানো হয়েছে: {word}","ayahFullyRevealed":"পুরো আয়াত দেখানো হয়েছে।","couldNotLocateAyah":"এই আয়াতের পৃষ্ঠা পাওয়া যায়নি।","resetConfirm":"সব হিফজ মূল্যায়ন ও নোট রিসেট করবেন?","howWellKnown":"আপনি {surah} ({ref}) কতটা ভালো জানতেন?","knewWell":"ভালোভাবে মনে ছিল","hesitated":"আমি দ্বিধা করেছি","couldntRecall":"মনে করতে পারিনি","applyTo":"প্রযোজ্য","thisAyahOnly":"শুধু এই আয়াত","addNoteOptional":"নোট যোগ করুন (ঐচ্ছিক)","noteExample":"যেমন: অন্য আয়াতের মতো, শেষাংশ পুনরাবৃত্তি করুন…","evaluationSaved":"মূল্যায়ন সংরক্ষিত হয়েছে","similarPassageFallback":"সদৃশ অংশ","standard":"সাধারণ","tajweedColors":"তাজবিদের রং","single":"পৃষ্ঠা","scroll":"স্ক্রল","twoPage":"দুই পৃষ্ঠা","jumpTitle":"সূরা / আয়াতে যান","current":"বর্তমান","surah":"সূরা","ayah":"আয়াত","goAyah":"আয়াতে যান","mushafDisplay":"মুসহাফ প্রদর্শন","readingStyle":"পড়ার ধরন","fontSize":"আরবি ফন্টের আকার","twoPageView":"দুই পৃষ্ঠার দৃশ্য","showPageNumbers":"পৃষ্ঠা নম্বর দেখান","defaultReciter":"ডিফল্ট কারি","autoPlay":"পরের আয়াত স্বয়ংক্রিয় চালান","pauseAfter":"প্রতি আয়াতের পর বিরতি","offlineAudio":"অফলাইন অডিও","offlineVoice":"ডাউনলোডের কারি","downloadAll":"সব আয়াত ডাউনলোড করুন","deleteAudio":"ডাউনলোড অডিও মুছুন","downloaded":"ডাউনলোড হয়েছে","notDownloaded":"ডাউনলোড হয়নি","downloading":"ডাউনলোড হচ্ছে","resetProgress":"হিফজ অগ্রগতি রিসেট","offlineData":"অফলাইন ডেটা","cachedPages":"পড়ার সময় পৃষ্ঠা ডেটা সংরক্ষিত হয়","audioSettings":"অডিও","loadingMushafPage":"মুসহাফের পৃষ্ঠা লোড হচ্ছে…","loadingReadingView":"পাঠের ভিউ লোড হচ্ছে…","couldNotLoadMutashData":"মুতাশাবিহাতের তথ্য লোড করা যায়নি।","couldNotLoadPracticePage":"অনুশীলনের পৃষ্ঠা লোড করা যায়নি।","couldNotRenderScreen":"Memorize Quran এই স্ক্রিনটি দেখাতে পারেনি।","reload":"আবার লোড করুন","couldNotLoadMushafView":"মুসহাফের ভিউ লোড করা যায়নি।","hafsPageLoadError":"হাফস মুসহাফের পৃষ্ঠার ছবি লোড করা যায়নি।","selectAyahAria":"আয়াত {ref} নির্বাচন করুন","pageImageAlt":"হাফস মুসহাফ পৃষ্ঠা {page}"},"tr":{"greeting":"Selâmün aleyküm","page":"Sayfa","juz":"Cüz","rightPage":"Sağ sayfa","leftPage":"Sol sayfa","displayOptions":"Mushaf görünüm seçenekleri","selfEvaluation":"Öz Değerlendirme","tapAyahFirst":"Önce bir ayete dokunun","selectedAyah":"Seçili ayet","wholePage":"Tüm sayfa","applyOneRating":"Sayfa {page} üzerindeki {count} ayetin tümüne tek değerlendirme uygula.","strongShort":"Güçlü","reviewShort":"Tekrar","weakShort":"Zayıf","addNote":"Not ekle","optionalNote":"Bu ayet hakkında isteğe bağlı not…","save":"Kaydet","chooseRating":"Bir değerlendirme seçin.","pageEvaluationSaved":"Sayfa değerlendirmesi kaydedildi","ayahEvaluationSaved":"Ayet değerlendirmesi kaydedildi","pageBookmarked":"Sayfa yer imlerine eklendi","bookmarkRemoved":"Yer imi kaldırıldı","pageN":"Sayfa {page}","ayahPageCount":"{ayahs} ayet · {pages} sayfa","similarAyahPractice":"Benzer ayet alıştırması","currentAyahAudio":"Geçerli ayetin sesi","ayahAudio":"Ayet Sesi","repeat":"Tekrar","revisionTitle":"Tekrar","basedSelfEvaluations":"Kendi değerlendirmelerinize göre","reviseFirst":"Zayıf · önce tekrar et","needsReview":"Tekrar gerekli","emptyRevision":"Tekrar listenizi oluşturmak için Mushaf’tan ayetleri değerlendirin.","openInMushaf":"Mushaf’ta aç","practiceTitle":"Alıştırma","practiceSubtitle":"Hatırlama, görsel hafıza ve dinleme","coreRecall":"Temel Hatırlama","hifzPractice":"Hıfz Alıştırması","listening":"Dinleme","continueAyah":"Ayeti Devam Ettir","continueDesc":"Başlangıç kelimelerini gör, sonra hafızadan devam et","randomAyah":"Rastgele Ayet","randomDesc":"Rastgele test sayfasındaki gizli ayeti hatırla","whatBefore":"Öncesinde Ne Var?","beforeDesc":"Önceki ayeti hatırla","whatAfter":"Sonrasında Ne Var?","afterDesc":"Sonraki ayeti hatırla","pageTest":"Sayfa Testi","pageTestDesc":"Sayfayı gizle, ezberden oku, sonra açıp değerlendir","surahTest":"Sure Testi","surahTestDesc":"Bir Sureyi veya aralığı test et","mutashPractice":"Müteşabihât","mutashDesc":"Benzer ayetleri çalış","visualMemory":"Görsel Hafıza","visualDesc":"İçeriği sayfadaki sabit konumundan hatırla","audioHifz":"Sesli Hıfz","audioHifzDesc":"Dinle, tekrar et ve tilaveti takip et","fromAyah":"Ayetten","toAyah":"Ayete","startTest":"Testi başlat","noPracticeSession":"Alıştırma oturumu yok.","testPageReading":"Test sayfası {testPage} · okuma konumu Sayfa {page} üzerinde kalır","loadingCue":"İpucu yükleniyor…","loadingRandomPage":"Rastgele Mushaf sayfası yükleniyor…","loadingAnswer":"Cevap yükleniyor…","howRecall":"Hatırlaman nasıldı?","playAyah":"Ayeti oynat","hideAnswer":"Cevabı gizle","revealAnswer":"Cevabı göster","anotherTest":"Başka test","promptContinue":"Başlangıç kelimelerini oku, sonra ayeti hafızadan devam ettir.","promptRandom":"Normal okuma sayfanı açmadan bulanık ayeti ezberden oku.","promptBefore":"İpucunu oku, sonra hemen önceki ayeti hatırla.","promptAfter":"İpucunu oku, sonra hemen sonraki ayeti hatırla.","promptPage":"Sayfanın ilk 3 kelimesini ipucu olarak kullan, sonra kalanını ezberden oku.","promptSurah":"Seçilen Sureden rastgele ayeti oku.","promptVisual":"Ayeti tamamen oku, sonra sayfanın hangi üçte birinde olduğunu seç.","promptAudio":"Bir kez dinle, sonra göstermeden önce ayeti hafızadan oku.","practiceFromMemory":"Hafızadan çalış.","cue":"İpucu","continueNoReveal":"Kalanını göstermeden devam et.","ayahLabel":"Ayet","reciteBeforeReveal":"Cevabı göstermeden önce oku.","pressPlay":"Bir kez Oynat’a bas, sonra hafızadan oku.","findAyah":"Bu ayeti sayfada bul","choosePageThird":"Sayfa {page} için üst, orta veya alt bölümü seç.","useFirstWords":"Sayfanın kalanını hatırlamak için ilk 3 kelimeyi kullan.","blurredTarget":"Bulanık bölüm hedefindir.","compareRevealed":"Okuyuşunu yukarıdaki açılmış sayfayla karşılaştır.","correctLocation":"Doğru konum","tryAnotherPosition":"Başka bir konum dene","practiceStartError":"Alıştırma testi başlatılamadı.","audioStartError":"Ses başlatılamadı.","mutashTitle":"Müteşabihât Alıştırması","chooseSimilarPair":"Çalışmak için benzer bir çift seç","compareSharedWording":"Ortak ifadeyi karşılaştır","loadingMutash":"Doğrulanmış Müteşabihât verileri yükleniyor…","similarPairs":"Benzer çiftler","verifiedPairings":"{count} doğrulanmış eşleşme · çalışmak için ortak ifadeye dokun","loadingSimilarPhrase":"Benzer ifade yükleniyor…","allPairs":"Tüm çiftler","similarPhrase":"Benzer ifade","sourcePassage":"Kaynak bölüm","similarPassage":"Benzer bölüm","backToList":"Listeye dön","openSourceMushaf":"Kaynağı Mushaf’ta aç","hifzProgress":"Hıfz İlerlemesi","yourMushafMap":"Mushaf haritan","memorized":"Ezberlendi","reviewSoon":"Yakında tekrar","notEvaluated":"Değerlendirilmedi","ayahs":"Ayetler","notes":"Notlar","loading":"Yükleniyor…","loadingPageDetails":"Sayfa ayrıntıları yükleniyor…","noNotes":"Bu sayfada henüz not yok.","pageMeta":"Cüz {juz} · {side} · {count} ayet","tapNumberOpen":"{count} ayet · açmak için numaraya dokun","analytics":"Analiz","day":"Gün","month":"Ay","year":"Yıl","all":"Tümü","sessions":"Oturum","strongMarks":"Güçlü işaretler","reviewMarks":"Tekrar işaretleri","weakMarks":"Zayıf işaretler","weakestSurahs":"En Zayıf Sureler","evaluateMore":"Sıralama oluşturmak için daha fazla ayeti değerlendir.","chooseJuz":"Cüz Seç","chooseSurah":"Sure Seç","themeLight":"Açık","themeDark":"Koyu","themeSystem":"Sistem","reset":"Sıfırla","offlineAyahsAvailable":"{count} ayet çevrimdışı kullanılabilir","tapDownloadContinue":"Devam etmek için Tüm ayetleri indir’e dokun.","failed":"başarısız","offlineDownloadComplete":"Çevrimdışı ses indirme tamamlandı.","offlineDownloadIncomplete":"İndirme bazı eksik dosyalarla tamamlandı.","deleteAudioConfirm":"İndirilen tüm tilavet sesleri silinsin mi?","downloadedAudioDeleted":"İndirilen sesler silindi.","deleteOfflineError":"Çevrimdışı ses silinemedi.","selectAyahFirst":"Önce bir ayet seçin.","audioInternetError":"Ses başlatılamadı. İnterneti veya çevrimdışı indirmeyi kontrol edin.","revealedWord":"Gösterildi: {word}","ayahFullyRevealed":"Ayet tamamen gösterildi.","couldNotLocateAyah":"Bu ayetin sayfası bulunamadı.","resetConfirm":"Tüm Hıfz değerlendirmeleri ve notlar sıfırlansın mı?","howWellKnown":"{surah} ({ref}) ne kadar iyi biliyordun?","knewWell":"İyi biliyordum","hesitated":"Tereddüt ettim","couldntRecall":"Hatırlayamadım","applyTo":"Uygula","thisAyahOnly":"Yalnız bu ayet","addNoteOptional":"Not ekle (isteğe bağlı)","noteExample":"örn. Başka ayete benziyor, sonunu tekrar et…","evaluationSaved":"Değerlendirme kaydedildi","similarPassageFallback":"Benzer bölüm","standard":"Standart","tajweedColors":"Tecvid Renkleri","single":"Sayfa","scroll":"Kaydır","twoPage":"İki sayfa","jumpTitle":"Sure / Ayete Git","current":"Geçerli","surah":"Sure","ayah":"Ayet","goAyah":"Ayete Git","mushafDisplay":"Mushaf Görünümü","readingStyle":"Okuma stili","fontSize":"Arapça yazı boyutu","twoPageView":"İki sayfa görünümü","showPageNumbers":"Sayfa numaralarını göster","defaultReciter":"Varsayılan kâri","autoPlay":"Sonraki ayeti otomatik oynat","pauseAfter":"Her ayetten sonra durakla","offlineAudio":"Çevrimdışı ses","offlineVoice":"İndirilecek kâri","downloadAll":"Tüm ayetleri indir","deleteAudio":"İndirilen sesi sil","downloaded":"İndirildi","notDownloaded":"İndirilmedi","downloading":"İndiriliyor","resetProgress":"Hıfz ilerlemesini sıfırla","offlineData":"Çevrimdışı veri","cachedPages":"Okurken sayfa verileri önbelleğe alınır","audioSettings":"Ses","loadingMushafPage":"Mushaf sayfası yükleniyor…","loadingReadingView":"Okuma görünümü yükleniyor…","couldNotLoadMutashData":"Müteşabihât verileri yüklenemedi.","couldNotLoadPracticePage":"Alıştırma sayfası yüklenemedi.","couldNotRenderScreen":"Memorize Quran bu ekranı görüntüleyemedi.","reload":"Yeniden yükle","couldNotLoadMushafView":"Mushaf görünümü yüklenemedi.","hafsPageLoadError":"Hafs Mushaf sayfası resmi yüklenemedi.","selectAyahAria":"{ref} ayetini seç","pageImageAlt":"Hafs Mushaf sayfası {page}"},"fr":{"greeting":"As-salâm ‘alaykoum","page":"Page","juz":"Juz","rightPage":"Page de droite","leftPage":"Page de gauche","displayOptions":"Options d’affichage du Mushaf","selfEvaluation":"Auto-évaluation","tapAyahFirst":"Touchez d’abord un verset","selectedAyah":"Verset sélectionné","wholePage":"Page entière","applyOneRating":"Appliquer une seule évaluation aux {count} versets de la page {page}.","strongShort":"Solide","reviewShort":"Réviser","weakShort":"Faible","addNote":"Ajouter une note","optionalNote":"Note facultative sur ce verset…","save":"Enregistrer","chooseRating":"Choisissez une évaluation.","pageEvaluationSaved":"Évaluation de la page enregistrée","ayahEvaluationSaved":"Évaluation du verset enregistrée","pageBookmarked":"Page ajoutée aux signets","bookmarkRemoved":"Signet supprimé","pageN":"Page {page}","ayahPageCount":"{ayahs} versets · {pages} pages","similarAyahPractice":"Exercice de versets similaires","currentAyahAudio":"Audio du verset actuel","ayahAudio":"Audio du verset","repeat":"Répéter","revisionTitle":"Révision","basedSelfEvaluations":"Selon vos auto-évaluations","reviseFirst":"Faible · à réviser en premier","needsReview":"À réviser","emptyRevision":"Évaluez des versets dans le Mushaf pour créer votre file de révision.","openInMushaf":"Ouvrir dans le Mushaf","practiceTitle":"Pratique","practiceSubtitle":"Rappel, mémoire visuelle et écoute","coreRecall":"Rappel essentiel","hifzPractice":"Pratique du Hifz","listening":"Écoute","continueAyah":"Continuer le verset","continueDesc":"Voir les premiers mots, puis continuer de mémoire","randomAyah":"Verset aléatoire","randomDesc":"Rappeler un verset caché d’une page test aléatoire","whatBefore":"Qu’y a-t-il avant ?","beforeDesc":"Rappeler le verset précédent","whatAfter":"Qu’y a-t-il après ?","afterDesc":"Rappeler le verset suivant","pageTest":"Test de page","pageTestDesc":"Masquer la page, réciter, puis révéler et évaluer","surahTest":"Test de sourate","surahTestDesc":"Tester une sourate ou une plage","mutashPractice":"Mutashābihāt","mutashDesc":"Pratiquer les versets similaires","visualMemory":"Mémoire visuelle","visualDesc":"Rappeler le contenu depuis sa position fixe sur la page","audioHifz":"Hifz audio","audioHifzDesc":"Écouter, répéter et suivre la récitation","fromAyah":"Du verset","toAyah":"Au verset","startTest":"Commencer le test","noPracticeSession":"Aucune session de pratique.","testPageReading":"Page test {testPage} · la lecture reste à la page {page}","loadingCue":"Chargement de l’indice…","loadingRandomPage":"Chargement d’une page Mushaf aléatoire…","loadingAnswer":"Chargement de la réponse…","howRecall":"Comment était votre rappel ?","playAyah":"Lire le verset","hideAnswer":"Masquer la réponse","revealAnswer":"Révéler la réponse","anotherTest":"Autre test","promptContinue":"Lisez les premiers mots, puis continuez le verset de mémoire.","promptRandom":"Récitez le verset flouté sans ouvrir votre page de lecture habituelle.","promptBefore":"Lisez l’indice, puis rappelez le verset immédiatement précédent.","promptAfter":"Lisez l’indice, puis rappelez le verset immédiatement suivant.","promptPage":"Utilisez les 3 premiers mots de la page comme indice, puis récitez le reste de mémoire.","promptSurah":"Récitez le verset sélectionné au hasard dans la sourate choisie.","promptVisual":"Lisez le verset entier, puis choisissez le tiers de page où il se trouve.","promptAudio":"Écoutez une fois, puis récitez le verset avant de le révéler.","practiceFromMemory":"Pratiquez de mémoire.","cue":"Indice","continueNoReveal":"Continuez sans révéler le reste.","ayahLabel":"Verset","reciteBeforeReveal":"Récitez avant de révéler la réponse.","pressPlay":"Appuyez une fois sur Lecture, puis récitez de mémoire.","findAyah":"Trouvez ce verset sur la page","choosePageThird":"Choisissez le haut, le milieu ou le bas de la page {page}.","useFirstWords":"Utilisez les 3 premiers mots pour rappeler le reste de la page.","blurredTarget":"Le passage flouté est votre cible.","compareRevealed":"Comparez votre récitation avec la page révélée ci-dessus.","correctLocation":"Bonne position","tryAnotherPosition":"Essayez une autre position","practiceStartError":"Impossible de démarrer le test.","audioStartError":"Impossible de lancer l’audio.","mutashTitle":"Pratique des Mutashābihāt","chooseSimilarPair":"Choisissez une paire similaire à étudier","compareSharedWording":"Comparez les formulations communes","loadingMutash":"Chargement des données Mutashābihāt vérifiées…","similarPairs":"Paires similaires","verifiedPairings":"{count} paires vérifiées · touchez une phrase commune pour pratiquer","loadingSimilarPhrase":"Chargement de la phrase similaire…","allPairs":"Toutes les paires","similarPhrase":"Phrase similaire","sourcePassage":"Passage source","similarPassage":"Passage similaire","backToList":"Retour à la liste","openSourceMushaf":"Ouvrir la source dans le Mushaf","hifzProgress":"Progression du Hifz","yourMushafMap":"Votre carte du Mushaf","memorized":"Mémorisé","reviewSoon":"À réviser bientôt","notEvaluated":"Non évalué","ayahs":"Versets","notes":"Notes","loading":"Chargement…","loadingPageDetails":"Chargement des détails de la page…","noNotes":"Aucune note sur cette page pour le moment.","pageMeta":"Juz {juz} · {side} · {count} verset(s)","tapNumberOpen":"{count} versets · touchez un numéro pour l’ouvrir","analytics":"Analyses","day":"Jour","month":"Mois","year":"Année","all":"Tout","sessions":"Sessions","strongMarks":"Marques solides","reviewMarks":"Marques à réviser","weakMarks":"Marques faibles","weakestSurahs":"Sourates les plus faibles","evaluateMore":"Évaluez davantage de versets pour créer un classement.","chooseJuz":"Choisir le Juz","chooseSurah":"Choisir la sourate","themeLight":"Clair","themeDark":"Sombre","themeSystem":"Système","reset":"Réinitialiser","offlineAyahsAvailable":"{count} versets disponibles hors ligne","tapDownloadContinue":"Touchez Télécharger tous les versets pour continuer.","failed":"échec","offlineDownloadComplete":"Téléchargement audio hors ligne terminé.","offlineDownloadIncomplete":"Téléchargement terminé avec quelques fichiers manquants.","deleteAudioConfirm":"Supprimer tous les audios de récitation téléchargés ?","downloadedAudioDeleted":"Audio téléchargé supprimé.","deleteOfflineError":"Impossible de supprimer l’audio hors ligne.","selectAyahFirst":"Sélectionnez d’abord un verset.","audioInternetError":"Impossible de lancer l’audio. Vérifiez Internet ou le téléchargement hors ligne.","revealedWord":"Révélé : {word}","ayahFullyRevealed":"Le verset est entièrement révélé.","couldNotLocateAyah":"Impossible de trouver la page de ce verset.","resetConfirm":"Réinitialiser toutes les évaluations Hifz et les notes ?","howWellKnown":"À quel point connaissiez-vous {surah} ({ref}) ?","knewWell":"Je le connaissais bien","hesitated":"J’ai hésité","couldntRecall":"Je n’ai pas pu me rappeler","applyTo":"Appliquer à","thisAyahOnly":"Ce verset uniquement","addNoteOptional":"Ajouter une note (facultatif)","noteExample":"ex. Semblable à un autre verset, réviser la fin…","evaluationSaved":"Évaluation enregistrée","similarPassageFallback":"Passage similaire","standard":"Standard","tajweedColors":"Couleurs du tajwid","single":"Page","scroll":"Défilement","twoPage":"Deux pages","jumpTitle":"Aller à une sourate / un verset","current":"Actuel","surah":"Sourate","ayah":"Verset","goAyah":"Aller au verset","mushafDisplay":"Affichage du Mushaf","readingStyle":"Style de lecture","fontSize":"Taille de police arabe","twoPageView":"Vue sur deux pages","showPageNumbers":"Afficher les numéros de page","defaultReciter":"Récitateur par défaut","autoPlay":"Lire automatiquement le verset suivant","pauseAfter":"Pause après chaque verset","offlineAudio":"Audio hors ligne","offlineVoice":"Récitateur à télécharger","downloadAll":"Télécharger tous les versets","deleteAudio":"Supprimer l’audio téléchargé","downloaded":"Téléchargé","notDownloaded":"Non téléchargé","downloading":"Téléchargement","resetProgress":"Réinitialiser la progression Hifz","offlineData":"Données hors ligne","cachedPages":"Les données des pages sont mises en cache pendant la lecture","audioSettings":"Audio","loadingMushafPage":"Chargement de la page du Mushaf…","loadingReadingView":"Chargement du mode de lecture…","couldNotLoadMutashData":"Impossible de charger les données de Mutashābihāt.","couldNotLoadPracticePage":"Impossible de charger la page de pratique.","couldNotRenderScreen":"Memorize Quran n’a pas pu afficher cet écran.","reload":"Recharger","couldNotLoadMushafView":"Impossible de charger cette vue du Mushaf.","hafsPageLoadError":"Impossible de charger l’image de la page du Mushaf Hafs.","selectAyahAria":"Sélectionner le verset {ref}","pageImageAlt":"Page {page} du Mushaf Hafs"},"pt-BR":{"greeting":"Assalamu alaikum","page":"Página","juz":"Juz","rightPage":"Página direita","leftPage":"Página esquerda","displayOptions":"Opções de exibição do Mushaf","selfEvaluation":"Autoavaliação","tapAyahFirst":"Toque primeiro em uma ayah","selectedAyah":"Ayah selecionada","wholePage":"Página inteira","applyOneRating":"Aplique uma avaliação a todas as {count} ayahs da Página {page}.","strongShort":"Forte","reviewShort":"Revisar","weakShort":"Fraca","addNote":"Adicionar nota","optionalNote":"Nota opcional sobre esta ayah…","save":"Salvar","chooseRating":"Escolha uma avaliação.","pageEvaluationSaved":"Avaliação da página salva","ayahEvaluationSaved":"Avaliação da ayah salva","pageBookmarked":"Página adicionada aos favoritos","bookmarkRemoved":"Favorito removido","pageN":"Página {page}","ayahPageCount":"{ayahs} ayahs · {pages} páginas","similarAyahPractice":"Prática de ayahs semelhantes","currentAyahAudio":"Áudio da ayah atual","ayahAudio":"Áudio da Ayah","repeat":"Repetir","revisionTitle":"Revisão","basedSelfEvaluations":"Com base nas suas autoavaliações","reviseFirst":"Fraca · revise primeiro","needsReview":"Precisa de revisão","emptyRevision":"Avalie ayahs no Mushaf para criar sua fila de revisão.","openInMushaf":"Abrir no Mushaf","practiceTitle":"Prática","practiceSubtitle":"Recordação, memória visual e escuta","coreRecall":"Recordação Essencial","hifzPractice":"Prática de Hifz","listening":"Escuta","continueAyah":"Continue a Ayah","continueDesc":"Veja as palavras iniciais e continue de memória","randomAyah":"Ayah Aleatória","randomDesc":"Recorde uma ayah escondida de uma página de teste aleatória","whatBefore":"O que Vem Antes?","beforeDesc":"Recorde a ayah anterior","whatAfter":"O que Vem Depois?","afterDesc":"Recorde a próxima ayah","pageTest":"Teste de Página","pageTestDesc":"Oculte a página, recite e depois revele e avalie","surahTest":"Teste de Surah","surahTestDesc":"Teste uma Surah ou intervalo","mutashPractice":"Mutashābihāt","mutashDesc":"Pratique ayahs semelhantes","visualMemory":"Memória Visual","visualDesc":"Recorde o conteúdo a partir de sua posição fixa na página","audioHifz":"Hifz com Áudio","audioHifzDesc":"Ouça, repita e acompanhe a recitação","fromAyah":"Da ayah","toAyah":"Até a ayah","startTest":"Iniciar teste","noPracticeSession":"Nenhuma sessão de prática.","testPageReading":"Página de teste {testPage} · a leitura permanece na Página {page}","loadingCue":"Carregando pista…","loadingRandomPage":"Carregando página aleatória do Mushaf…","loadingAnswer":"Carregando resposta…","howRecall":"Como foi sua recordação?","playAyah":"Reproduzir ayah","hideAnswer":"Ocultar resposta","revealAnswer":"Revelar resposta","anotherTest":"Outro teste","promptContinue":"Leia as palavras iniciais e continue a ayah de memória.","promptRandom":"Recite a ayah desfocada sem abrir sua página normal de leitura.","promptBefore":"Leia a pista e recorde a ayah imediatamente anterior.","promptAfter":"Leia a pista e recorde a ayah imediatamente seguinte.","promptPage":"Use as 3 primeiras palavras da página como pista e recite o restante de memória.","promptSurah":"Recite a ayah selecionada aleatoriamente da Surah escolhida.","promptVisual":"Leia a ayah completa e escolha em qual terço da página ela está.","promptAudio":"Ouça uma vez e recite a ayah antes de revelá-la.","practiceFromMemory":"Pratique de memória.","cue":"Pista","continueNoReveal":"Continue sem revelar o restante.","ayahLabel":"Ayah","reciteBeforeReveal":"Recite antes de revelar a resposta.","pressPlay":"Pressione Reproduzir uma vez e recite de memória.","findAyah":"Encontre esta ayah na página","choosePageThird":"Escolha a parte superior, central ou inferior da Página {page}.","useFirstWords":"Use as 3 primeiras palavras para lembrar o restante da página.","blurredTarget":"A passagem desfocada é o seu alvo.","compareRevealed":"Compare sua recitação com a página revelada acima.","correctLocation":"Local correto","tryAnotherPosition":"Tente outra posição","practiceStartError":"Não foi possível iniciar o teste.","audioStartError":"Não foi possível iniciar o áudio.","mutashTitle":"Prática de Mutashābihāt","chooseSimilarPair":"Escolha um par semelhante para estudar","compareSharedWording":"Compare as palavras em comum","loadingMutash":"Carregando dados verificados de Mutashābihāt…","similarPairs":"Pares semelhantes","verifiedPairings":"{count} pares verificados · toque na frase em comum para praticar","loadingSimilarPhrase":"Carregando frase semelhante…","allPairs":"Todos os pares","similarPhrase":"Frase semelhante","sourcePassage":"Passagem de origem","similarPassage":"Passagem semelhante","backToList":"Voltar à lista","openSourceMushaf":"Abrir origem no Mushaf","hifzProgress":"Progresso do Hifz","yourMushafMap":"Seu mapa do Mushaf","memorized":"Memorizado","reviewSoon":"Revisar em breve","notEvaluated":"Não avaliado","ayahs":"Ayahs","notes":"Notas","loading":"Carregando…","loadingPageDetails":"Carregando detalhes da página…","noNotes":"Ainda não há notas nesta página.","pageMeta":"Juz {juz} · {side} · {count} ayah(s)","tapNumberOpen":"{count} ayahs · toque em um número para abrir","analytics":"Análises","day":"Dia","month":"Mês","year":"Ano","all":"Tudo","sessions":"Sessões","strongMarks":"Marcas fortes","reviewMarks":"Marcas de revisão","weakMarks":"Marcas fracas","weakestSurahs":"Surahs Mais Fracas","evaluateMore":"Avalie mais ayahs para criar um ranking.","chooseJuz":"Escolher Juz","chooseSurah":"Escolher Surah","themeLight":"Claro","themeDark":"Escuro","themeSystem":"Sistema","reset":"Redefinir","offlineAyahsAvailable":"{count} ayahs disponíveis offline","tapDownloadContinue":"Toque em Baixar todas as ayahs para continuar.","failed":"falhou","offlineDownloadComplete":"Download de áudio offline concluído.","offlineDownloadIncomplete":"Download concluído com alguns arquivos ausentes.","deleteAudioConfirm":"Excluir todos os áudios de recitação baixados?","downloadedAudioDeleted":"Áudio baixado excluído.","deleteOfflineError":"Não foi possível excluir o áudio offline.","selectAyahFirst":"Selecione uma ayah primeiro.","audioInternetError":"Não foi possível iniciar o áudio. Verifique a internet ou o download offline.","revealedWord":"Revelado: {word}","ayahFullyRevealed":"A ayah foi totalmente revelada.","couldNotLocateAyah":"Não foi possível localizar a página desta ayah.","resetConfirm":"Redefinir todas as avaliações de Hifz e notas?","howWellKnown":"Quão bem você sabia {surah} ({ref})?","knewWell":"Eu sabia bem","hesitated":"Eu hesitei","couldntRecall":"Não consegui lembrar","applyTo":"Aplicar a","thisAyahOnly":"Somente esta ayah","addNoteOptional":"Adicionar nota (opcional)","noteExample":"ex. Parecida com outra ayah, revise o final…","evaluationSaved":"Avaliação salva","similarPassageFallback":"Passagem semelhante","standard":"Padrão","tajweedColors":"Cores de Tajwid","single":"Página","scroll":"Rolagem","twoPage":"Duas páginas","jumpTitle":"Ir para Surah / Ayah","current":"Atual","surah":"Surah","ayah":"Ayah","goAyah":"Ir para Ayah","mushafDisplay":"Exibição do Mushaf","readingStyle":"Estilo de leitura","fontSize":"Tamanho da fonte árabe","twoPageView":"Visualização de duas páginas","showPageNumbers":"Mostrar números das páginas","defaultReciter":"Recitador padrão","autoPlay":"Reproduzir próxima ayah automaticamente","pauseAfter":"Pausar após cada ayah","offlineAudio":"Áudio offline","offlineVoice":"Recitador para baixar","downloadAll":"Baixar todas as ayahs","deleteAudio":"Excluir áudio baixado","downloaded":"Baixado","notDownloaded":"Não baixado","downloading":"Baixando","resetProgress":"Redefinir progresso do Hifz","offlineData":"Dados offline","cachedPages":"Os dados das páginas são armazenados durante a leitura","audioSettings":"Áudio","loadingMushafPage":"Carregando página do Mushaf…","loadingReadingView":"Carregando modo de leitura…","couldNotLoadMutashData":"Não foi possível carregar os dados de Mutashābihāt.","couldNotLoadPracticePage":"Não foi possível carregar a página de prática.","couldNotRenderScreen":"O Memorize Quran não conseguiu exibir esta tela.","reload":"Recarregar","couldNotLoadMushafView":"Não foi possível carregar esta visualização do Mushaf.","hafsPageLoadError":"Não foi possível carregar a imagem da página do Mushaf Hafs.","selectAyahAria":"Selecionar ayah {ref}","pageImageAlt":"Página {page} do Mushaf Hafs"}};
function ui(key){const lang=state?.settings?.uiLang||'en';return UI_TEXT[lang]?.[key]||UI_EXTRA[lang]?.[key]||UI_MORE[lang]?.[key]||UI_TEXT.en?.[key]||UI_EXTRA.en?.[key]||UI_MORE.en?.[key]||key}
function uit(key,vars={}){return String(ui(key)).replace(/\{(\w+)\}/g,(_,k)=>vars[k]??`{${k}}`)}

(UI_TEXT.en||(UI_TEXT.en={}));Object.assign(UI_TEXT.en,{playSpeed:'Play speed',tajweedInfo:'Tajweed color guide',readOnMushaf:'Read on Mushaf'});
(UI_TEXT.ar||(UI_TEXT.ar={}));Object.assign(UI_TEXT.ar,{playSpeed:'سرعة التشغيل',tajweedInfo:'دليل ألوان التجويد',readOnMushaf:'اقرأ في المصحف'});
(UI_TEXT.ur||(UI_TEXT.ur={}));Object.assign(UI_TEXT.ur,{playSpeed:'پلے بیک رفتار',tajweedInfo:'تجوید رنگوں کی رہنمائی',readOnMushaf:'مصحف میں پڑھیں'});
(UI_TEXT.id||(UI_TEXT.id={}));Object.assign(UI_TEXT.id,{playSpeed:'Kecepatan putar',tajweedInfo:'Panduan warna tajwid',readOnMushaf:'Baca di Mushaf'});
(UI_TEXT.ms||(UI_TEXT.ms={}));Object.assign(UI_TEXT.ms,{playSpeed:'Kelajuan main',tajweedInfo:'Panduan warna tajwid',readOnMushaf:'Baca di Mushaf'});
(UI_TEXT.bn||(UI_TEXT.bn={}));Object.assign(UI_TEXT.bn,{playSpeed:'প্লে স্পিড',tajweedInfo:'তাজবিদ রঙ নির্দেশিকা',readOnMushaf:'মুসহাফে পড়ুন'});
(UI_TEXT.tr||(UI_TEXT.tr={}));Object.assign(UI_TEXT.tr,{playSpeed:'Oynatma hızı',tajweedInfo:'Tecvid renk rehberi',readOnMushaf:'Mushaf üzerinde oku'});
(UI_TEXT.fr||(UI_TEXT.fr={}));Object.assign(UI_TEXT.fr,{playSpeed:'Vitesse de lecture',tajweedInfo:'Guide des couleurs de tajwid',readOnMushaf:'Lire dans le Mushaf'});
(UI_TEXT['pt-BR']||(UI_TEXT['pt-BR']={}));Object.assign(UI_TEXT['pt-BR'],{playSpeed:'Velocidade de reprodução',tajweedInfo:'Guia das cores do tajwid',readOnMushaf:'Ler no Mushaf'});
Object.assign(UI_MORE.en,{tajweedIntro:'Color hints used in the tajweed Mushaf.',tajweedGreen:'Green: nasal sound (ghunnah).',tajweedBlue:'Blue: echoing sound (qalqalah).',tajweedRed:'Red: emphatic or heavy pronunciation.',tajweedOrange:'Orange: merge or soften the sound.',tajweedBlack:'Black: read normally.',close:'Close'});
Object.assign(UI_MORE.ar,{tajweedIntro:'دلالات مختصرة للألوان في مصحف التجويد.',tajweedGreen:'الأخضر: غنّة.',tajweedBlue:'الأزرق: قلقلة.',tajweedRed:'الأحمر: تفخيم أو نطق قوي.',tajweedOrange:'البرتقالي: إدغام أو تليين في النطق.',tajweedBlack:'الأسود: قراءة عادية.',close:'إغلاق'});
Object.assign(UI_MORE.ur,{tajweedIntro:'تجویدی مصحف میں رنگوں کی مختصر وضاحت۔',tajweedGreen:'سبز: غنہ۔',tajweedBlue:'نیلا: قلقلہ۔',tajweedRed:'سرخ: پرزور یا بھاری ادائیگی۔',tajweedOrange:'نارنجی: آواز کو ملانا یا نرم پڑھنا۔',tajweedBlack:'سیاہ: عام طریقے سے پڑھیں۔',close:'بند کریں'});
Object.assign(UI_MORE.id,{tajweedIntro:'Petunjuk singkat warna pada Mushaf tajwid.',tajweedGreen:'Hijau: dengung (ghunnah).',tajweedBlue:'Biru: bunyi pantul (qalqalah).',tajweedRed:'Merah: bacaan tebal/tegas.',tajweedOrange:'Oranye: leburkan atau lunakkan bunyi.',tajweedBlack:'Hitam: baca normal.',close:'Tutup'});
Object.assign(UI_MORE.ms,{tajweedIntro:'Panduan ringkas warna dalam Mushaf tajwid.',tajweedGreen:'Hijau: dengung (ghunnah).',tajweedBlue:'Biru: bunyi lantunan (qalqalah).',tajweedRed:'Merah: bacaan tebal / kuat.',tajweedOrange:'Oren: gabung atau lembutkan bunyi.',tajweedBlack:'Hitam: baca seperti biasa.',close:'Tutup'});
Object.assign(UI_MORE.bn,{tajweedIntro:'তাজবিদ মুসহাফের রঙগুলোর সহজ ব্যাখ্যা।',tajweedGreen:'সবুজ: গুন্নাহ।',tajweedBlue:'নীল: ক্বালক্বালাহ।',tajweedRed:'লাল: ভারী বা জোর উচ্চারণ।',tajweedOrange:'কমলা: মিলিয়ে বা নরম করে পড়া।',tajweedBlack:'কালো: স্বাভাবিকভাবে পড়ুন।',close:'বন্ধ'});
Object.assign(UI_MORE.tr,{tajweedIntro:'Tecvid mushafındaki renkler için kısa açıklama.',tajweedGreen:'Yeşil: ğunne.',tajweedBlue:'Mavi: kalkale.',tajweedRed:'Kırmızı: kalın / vurgulu okuma.',tajweedOrange:'Turuncu: sesi birleştirme veya yumuşatma.',tajweedBlack:'Siyah: normal okuyun.',close:'Kapat'});
Object.assign(UI_MORE.fr,{tajweedIntro:'Explication simple des couleurs du Mushaf tajwid.',tajweedGreen:'Vert : ghunnah (son nasal).',tajweedBlue:'Bleu : qalqalah.',tajweedRed:'Rouge : prononciation appuyée.',tajweedOrange:'Orange : fusionner ou adoucir le son.',tajweedBlack:'Noir : lecture normale.',close:'Fermer'});
Object.assign(UI_MORE['pt-BR'],{tajweedIntro:'Explicação simples das cores do Mushaf com tajwid.',tajweedGreen:'Verde: nasalização (ghunnah).',tajweedBlue:'Azul: eco sonoro (qalqalah).',tajweedRed:'Vermelho: pronúncia forte / enfática.',tajweedOrange:'Laranja: juntar ou suavizar o som.',tajweedBlack:'Preto: leitura normal.',close:'Fechar'});

function localizeDigits(value){const lang=state?.settings?.uiLang||'en',maps={ar:'٠١٢٣٤٥٦٧٨٩',ur:'۰۱۲۳۴۵۶۷۸۹',bn:'০১২৩৪৫৬৭৮৯'},m=maps[lang];const txt=String(value);return m?txt.replace(/\d/g,d=>m[Number(d)]):txt}
function fmtNum(value){return localizeDigits(value)}
function fmtVerseKey(key){return localizeDigits(key)}
function isRtlUI(){return (LANGUAGES[state?.settings?.uiLang||'en']?.dir||'ltr')==='rtl'}
function backIcon(){return icon(isRtlUI()?'right':'left')}
function localizedSurahName(n){return state?.settings?.uiLang==='ar'?(SURAH_NAMES_AR[n-1]||SURAH_NAMES[n-1]):(SURAH_NAMES[n-1]||'Quran')}
function themeLabel(mode){return ui(mode==='dark'?'themeDark':mode==='system'?'themeSystem':'themeLight')}
let languageSetupDone = localStorage.getItem('qh-language-setup')==='1';

const AUDIO = {
  husary: { label:'Al-Husary — Murattal', dir:'Husary_128kbps' },
  husary_mujawwad: { label:'Al-Husary — Mujawwad', dir:'Husary_128kbps_Mujawwad' },
  minshawi: { label:'Al-Minshawi — Murattal', dir:'Minshawy_Murattal_128kbps' },
};

const JUZ_START_PAGES = [1,22,42,62,82,102,121,142,162,182,201,222,242,262,282,302,322,342,362,382,402,422,442,462,482,502,522,542,562,582];
const SURAH_NAMES=['Al-Fatihah','Al-Baqarah','Aal-E-Imran','An-Nisa','Al-Maidah','Al-Anam','Al-Araf','Al-Anfal','At-Tawbah','Yunus','Hud','Yusuf','Ar-Rad','Ibrahim','Al-Hijr','An-Nahl','Al-Isra','Al-Kahf','Maryam','Taha','Al-Anbiya','Al-Hajj','Al-Muminun','An-Nur','Al-Furqan','Ash-Shuara','An-Naml','Al-Qasas','Al-Ankabut','Ar-Rum','Luqman','As-Sajdah','Al-Ahzab','Saba','Fatir','Ya-Sin','As-Saffat','Sad','Az-Zumar','Ghafir','Fussilat','Ash-Shuraa','Az-Zukhruf','Ad-Dukhan','Al-Jathiyah','Al-Ahqaf','Muhammad','Al-Fath','Al-Hujurat','Qaf','Adh-Dhariyat','At-Tur','An-Najm','Al-Qamar','Ar-Rahman','Al-Waqiah','Al-Hadid','Al-Mujadila','Al-Hashr','Al-Mumtahanah','As-Saff','Al-Jumuah','Al-Munafiqun','At-Taghabun','At-Talaq','At-Tahrim','Al-Mulk','Al-Qalam','Al-Haqqah','Al-Maarij','Nuh','Al-Jinn','Al-Muzzammil','Al-Muddaththir','Al-Qiyamah','Al-Insan','Al-Mursalat','An-Naba','An-Naziat','Abasa','At-Takwir','Al-Infitar','Al-Mutaffifin','Al-Inshiqaq','Al-Buruj','At-Tariq','Al-Ala','Al-Ghashiyah','Al-Fajr','Al-Balad','Ash-Shams','Al-Layl','Ad-Duha','Ash-Sharh','At-Tin','Al-Alaq','Al-Qadr','Al-Bayyinah','Az-Zalzalah','Al-Adiyat','Al-Qariah','At-Takathur','Al-Asr','Al-Humazah','Al-Fil','Quraysh','Al-Maun','Al-Kawthar','Al-Kafirun','An-Nasr','Al-Masad','Al-Ikhlas','Al-Falaq','An-Nas'];
const SURAH_NAMES_AR=["الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف","الرعد","إبراهيم","الحجر","النحل","الإسراء","الكهف","مريم","طه","الأنبياء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنكبوت","الروم","لقمان","السجدة","الأحزاب","سبأ","فاطر","يس","الصافات","ص","الزمر","غافر","فصلت","الشورى","الزخرف","الدخان","الجاثية","الأحقاف","محمد","الفتح","الحجرات","ق","الذاريات","الطور","النجم","القمر","الرحمن","الواقعة","الحديد","المجادلة","الحشر","الممتحنة","الصف","الجمعة","المنافقون","التغابن","الطلاق","التحريم","الملك","القلم","الحاقة","المعارج","نوح","الجن","المزمل","المدثر","القيامة","الإنسان","المرسلات","النبأ","النازعات","عبس","التكوير","الانفطار","المطففين","الانشقاق","البروج","الطارق","الأعلى","الغاشية","الفجر","البلد","الشمس","الليل","الضحى","الشرح","التين","العلق","القدر","البينة","الزلزلة","العاديات","القارعة","التكاثر","العصر","الهمزة","الفيل","قريش","الماعون","الكوثر","الكافرون","النصر","المسد","الإخلاص","الفلق","الناس"];
function surahDisplayName(n){return state?.settings?.uiLang==='ar'?(SURAH_NAMES_AR[n-1]||SURAH_NAMES[n-1]):(SURAH_NAMES[n-1]||'Quran')}
const SURAH_COUNTS=[7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];

const pageCache = new Map();
const fontCache = new Map();
const saved = key => { try { return JSON.parse(localStorage.getItem(key) || '{}'); } catch { return {}; } };
const storedSettings=saved('qh-settings');

// Runtime copy additions for v10.2 feedback fixes.
Object.assign(UI_MORE.en,{bookmarkOptions:'Choose bookmark type',bookmarkThisAyah:'Bookmark this ayah',bookmarkThisPage:'Bookmark this page',ayahBookmarked:'Ayah bookmarked',openThisAyah:'Open this ayah',openThisPage:'Open this page',openReference:'Read in Mushaf',previous:'Previous',next:'Next',markDone:'Mark pair as done',markUndone:'Mark as not done',done:'Done',notDone:'Not done'});
Object.assign(UI_MORE.ar,{bookmarkOptions:'اختر نوع العلامة',bookmarkThisAyah:'وضع علامة على هذه الآية',bookmarkThisPage:'وضع علامة على هذه الصفحة',ayahBookmarked:'تمت إضافة الآية إلى العلامات',openThisAyah:'افتح هذه الآية',openThisPage:'افتح هذه الصفحة',openReference:'اقرأ في المصحف',previous:'السابق',next:'التالي',markDone:'وضع علامة تم',markUndone:'إلغاء علامة تم',done:'تم',notDone:'غير منجز'});

Object.assign(UI_MORE.ur,{openInMushaf:'مصحف میں پڑھیں',openReference:'مصحف میں پڑھیں'});
Object.assign(UI_MORE.id,{openInMushaf:'Baca di Mushaf',openReference:'Baca di Mushaf'});
Object.assign(UI_MORE.ms,{openInMushaf:'Baca dalam Mushaf',openReference:'Baca dalam Mushaf'});
Object.assign(UI_MORE.bn,{openInMushaf:'মুসহাফে পড়ুন',openReference:'মুসহাফে পড়ুন'});
Object.assign(UI_MORE.tr,{openInMushaf:"Mushaf'ta Oku",openReference:"Mushaf'ta Oku"});
Object.assign(UI_MORE.fr,{openInMushaf:'Lire dans le Mushaf',openReference:'Lire dans le Mushaf'});
Object.assign(UI_MORE['pt-BR'],{openInMushaf:'Ler no Mushaf',openReference:'Ler no Mushaf'});

Object.assign(UI_MORE.ur||={}, {bookmarkOptions:'بک مارک کی قسم منتخب کریں',bookmarkThisAyah:'اس آیت کو بک مارک کریں',bookmarkThisPage:'اس صفحہ کو بک مارک کریں',ayahBookmarked:'آیت بک مارک ہو گئی'});
Object.assign(UI_MORE.bn||={}, {bookmarkOptions:'বুকমার্কের ধরন বেছে নিন',bookmarkThisAyah:'এই আয়াত বুকমার্ক করুন',bookmarkThisPage:'এই পৃষ্ঠা বুকমার্ক করুন',ayahBookmarked:'আয়াত বুকমার্ক করা হয়েছে'});
Object.assign(UI_MORE.fr||={}, {bookmarkOptions:'Choisir le type de signet',bookmarkThisAyah:'Marquer ce verset',bookmarkThisPage:'Marquer cette page',ayahBookmarked:'Verset ajouté aux signets'});
Object.assign(UI_MORE['pt-BR']||={}, {bookmarkOptions:'Escolha o tipo de favorito',bookmarkThisAyah:'Favoritar esta ayah',bookmarkThisPage:'Favoritar esta página',ayahBookmarked:'Ayah adicionada aos favoritos'});
Object.assign(UI_MORE.id||={}, {bookmarkOptions:'Pilih jenis penanda',bookmarkThisAyah:'Tandai ayat ini',bookmarkThisPage:'Tandai halaman ini',ayahBookmarked:'Ayat ditandai'});
Object.assign(UI_MORE.ms||={}, {bookmarkOptions:'Pilih jenis penanda',bookmarkThisAyah:'Tandakan ayat ini',bookmarkThisPage:'Tandakan halaman ini',ayahBookmarked:'Ayat telah ditandakan'});
Object.assign(UI_MORE.tr||={}, {bookmarkOptions:'Yer imi türünü seçin',bookmarkThisAyah:'Bu ayeti yer imine ekle',bookmarkThisPage:'Bu sayfayı yer imine ekle',ayahBookmarked:'Ayet yer imlerine eklendi'});
let mutashCache=null;
const translationCache=new Map();

const state = {
  tab:'home', page:293, view:'single', source:localStorage.getItem('qh-source') || 'plain', hide:false,
  currentVerseKey:null, revealed:{}, revealedAyahs:{}, hintWordKey:null, translation:false, bookmark:false,
  repeat:1, pause:true, autoNext:false, reciter:localStorage.getItem('qh-reciter') || 'husary', audioPlaying:false, repeatRemaining:0, practiceSession:null, mutashEntry:null, mutashPair:null, mutashList:true, mutashSeen:saved('qh-mutash-seen'), mutashIndex:Number(localStorage.getItem('qh-mutash-index')||0), mutashScroll:Number(localStorage.getItem('qh-mutash-scroll')||0), bookmarks:saved('qh-bookmarks'),
  ratings:saved('qh-ratings'), pageRatings:saved('qh-page-ratings'), ratingPages:saved('qh-rating-pages'), notes:saved('qh-notes'), ratingHistory:saved('qh-rating-history'), practiceSeen:saved('qh-practice-seen'),
  progressTab:'mushaf', progressDetailTab:'ayahs', selectedJuz:15, selectedSurah:18,
  activePanel:null, evalScope:'ayah', analyticsRange:'month', mushafOptionsOpen:false, audioDownload:null, audioDownloadAbort:false, returnTo:null, playbackRate:Number(localStorage.getItem('qh-playback-rate')||1), settings:{fontScale:100,twoPage:true,pageNumbers:true,theme:'light',uiLang:'en',translationLang:'en',offlineReciter:localStorage.getItem('qh-offline-reciter')||'husary',...storedSettings}
};

function icon(name){
  const i={
    home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>',
    mushaf:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3.5 5h7.2A2.3 2.3 0 0 1 13 7.3V21a2.3 2.3 0 0 0-2.3-2.3H3.5z"/><path d="M20.5 5h-7.2A2.3 2.3 0 0 0 11 7.3V21a2.3 2.3 0 0 1 2.3-2.3h7.2z"/></svg>',
    review:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/></svg>',
    sparkle:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 3 2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5Z"/></svg>',
    progress:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19V9M10 19V5M16 19v-8M22 19V3"/></svg>',
    settings:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.4 1A7 7 0 0 0 14.4 5L14 2h-4l-.4 3a7 7 0 0 0-2.1 1.2l-2.4-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.4-1A7 7 0 0 0 9.6 19l.4 3h4l.4-3a7 7 0 0 0 2.1-1.2l2.4 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2Z"/></svg>',
    book:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h6.5A2.5 2.5 0 0 1 13 6.5V20a2.5 2.5 0 0 0-2.5-2.5H4z"/><path d="M20 4h-6.5A2.5 2.5 0 0 0 11 6.5V20a2.5 2.5 0 0 1 2.5-2.5H20z"/></svg>',
    scroll:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 7h6M9 12h6M9 17h6"/></svg>',
    left:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="m15 18-6-6 6-6"/></svg>',
    right:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="m9 18 6-6-6-6"/></svg>',
    audio:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 10v4h4l5 4V6l-5 4H5Z"/><path d="M17 9a5 5 0 0 1 0 6M19.5 6.5a8.5 8.5 0 0 1 0 11"/></svg>',
    play:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="m8 5 11 7-11 7z"/></svg>',
    pause:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h4v14H7zm6 0h4v14h-4z"/></svg>',
    eye:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.8"/></svg>',
    eyeoff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m3 3 18 18M10.6 10.7a3 3 0 0 0 2.7 2.7M9.9 5.2A11.6 11.6 0 0 1 12 5c6.5 0 10 7 10 7a17.8 17.8 0 0 1-3.1 4M6.3 6.3A18 18 0 0 0 2 12s3.5 7 10 7a11 11 0 0 0 4-.7"/></svg>',
    translate:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 7h8M9 4v3c0 5-2 8-5 10M7 12c1.2 1.5 3 3 5 4M15 20l4-10 4 10M16 17h6"/></svg>',
    bookmark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 4h10v16l-5-3-5 3z"/></svg>',
    star:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2l-5.5 2.9 1-6.2L3 9.6l6.2-.9L12 3Z"/></svg>',
    bulb:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18h6M10 21h4M12 3a7 7 0 0 0-4 12.8c.6.5 1 1.2 1 2.2h6c0-1 .4-1.7 1-2.2A7 7 0 0 0 12 3Z"/></svg>',
    target:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="m15.5 8.5 4-4"/></svg>',
    search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="6.5"/><path d="m20 20-3.5-3.5"/></svg>',
    menu:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M5 7h14M5 12h14M5 17h14"/></svg>',
    close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M18 6 6 18M6 6l12 12"/></svg>',
    reveal:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M4 12h10m-4-4 4 4-4 4M4 7h5M4 17h5"/></svg>',
    note:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
    headphones:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v6H5a2 2 0 0 1-2-2v-2a2 2 0 0 1 1-2ZM20 14h-3v6h2a2 2 0 0 0 2-2v-2a2 2 0 0 0-1-2Z"/></svg>',
  }; return i[name]||'';
}

function faceSvg(bg,mood){
  const mouth=mood==='smile'?'M10 18.2c1.7 1.8 4.3 2.6 6 2.6s4.3-.8 6-2.6':mood==='flat'?'M11 19h10':'M10 21c1.7-1.8 4.3-2.6 6-2.6s4.3.8 6 2.6';
  const brows=mood==='sad'?'<path d="M10.8 11.6l2.4-.8M21.2 11.6l-2.4-.8"/>':'';
  return `<svg class="face-svg" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="15" fill="${bg}"/><circle cx="12" cy="14" r="1.3" fill="#214758"/><circle cx="20" cy="14" r="1.3" fill="#214758"/><g stroke="#214758" stroke-width="1.7" stroke-linecap="round">${brows}<path d="${mouth}"/></g></svg>`;
}

function pagePad(n){return String(n).padStart(3,'0')}
function physicalPageSide(p){return p%2===1?'right':'left'}
function pageSide(p){const side=physicalPageSide(p);return isRtlUI()?(side==='right'?'left':'right'):side}
function reciterLabel(key){const lang=state?.settings?.uiLang||'en';const map={husary:{default:'Al-Husary — Murattal',ar:'الحصري — مرتل'},husary_mujawwad:{default:'Al-Husary — Mujawwad',ar:'الحصري — مجود'},minshawi:{default:'Al-Minshawi — Murattal',ar:'المنشاوي — مرتل'}};const row=map[key]||{};return (lang==='ar'?row.ar:null)||row.default||AUDIO[key]?.label||key}
function pageJuz(p){let n=1;for(let i=0;i<JUZ_START_PAGES.length;i++){if(p>=JUZ_START_PAGES[i])n=i+1;else break;}return n}
function verseFromWord(w){const [surah,ayah,wordIndex]=w.location.split(':').map(Number);return {surah,ayah,wordIndex,key:`${surah}:${ayah}`}}
function wordsByVerse(data){const m=new Map();for(const line of data?.lines||[]){for(const w of line.words||[]){const v=verseFromWord(w);if(!m.has(v.key))m.set(v.key,[]);m.get(v.key).push({...w,...v});}}return m}
function getVerseWords(data,key){return wordsByVerse(data).get(key)||[]}
function firstVerseKey(data){return wordsByVerse(data).keys().next().value||null}
function currentPageData(){return pageCache.get(state.page)}
function currentSurahNumber(){
  if(state.currentVerseKey){const n=Number(state.currentVerseKey.split(':')[0]);if(n>=1&&n<=114)return n;}
  const d=currentPageData(),k=d?firstVerseKey(d):null;if(k){const n=Number(k.split(':')[0]);if(n>=1&&n<=114)return n;}
  return Number(state.selectedSurah)||18;
}
function currentAyahNumber(){
  if(state.currentVerseKey){const n=Number(state.currentVerseKey.split(':')[1]);if(n>=1)return n;}
  return 1;
}
function appIconMarkup(){return `<span class="app-icon-inline" aria-label="Memorize Quran">☪</span>`}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function saveAll(){localStorage.setItem('qh-playback-rate',String(state.playbackRate||1));localStorage.setItem('qh-ratings',JSON.stringify(state.ratings));localStorage.setItem('qh-page-ratings',JSON.stringify(state.pageRatings));localStorage.setItem('qh-rating-pages',JSON.stringify(state.ratingPages));localStorage.setItem('qh-notes',JSON.stringify(state.notes));localStorage.setItem('qh-rating-history',JSON.stringify(state.ratingHistory));localStorage.setItem('qh-practice-seen',JSON.stringify(state.practiceSeen));localStorage.setItem('qh-mutash-seen',JSON.stringify(state.mutashSeen||{}));localStorage.setItem('qh-bookmarks',JSON.stringify(state.bookmarks||{pages:{},ayahs:{}}));localStorage.setItem('qh-mutash-index',String(state.mutashIndex||0));localStorage.setItem('qh-mutash-scroll',String(state.mutashScroll||0));localStorage.setItem('qh-source',state.source);localStorage.setItem('qh-reciter',state.reciter);localStorage.setItem('qh-settings',JSON.stringify(state.settings))}

function ensureBookmarks(){if(!state.bookmarks||typeof state.bookmarks!=='object')state.bookmarks={};if(!state.bookmarks.pages)state.bookmarks.pages={};if(!state.bookmarks.ayahs)state.bookmarks.ayahs={};return state.bookmarks}
function isPageBookmarked(page=state.page){return !!ensureBookmarks().pages[String(page)]}
function isAyahBookmarked(key=state.currentVerseKey){return !!(key&&ensureBookmarks().ayahs[key])}
function currentBookmarkActive(){return isPageBookmarked(state.page)||isAyahBookmarked(state.currentVerseKey)}
function savePageBookmark(page=state.page){ensureBookmarks().pages[String(page)]={page:Number(page),ts:Date.now()};saveAll();state.bookmark=true}
function saveAyahBookmark(key=state.currentVerseKey,page=state.page){if(!key)return false;ensureBookmarks().ayahs[key]={key,page:Number(page),ts:Date.now()};saveAll();state.bookmark=true;return true}
function openBookmarkChooser(){
  ensureBookmarks();
  const key=state.currentVerseKey;
  const hasAyah=!!key;
  sheetRoot.innerHTML=`<div class="sheet-back inline-sheet-back" id="sheetBack"><div class="sheet bookmark-sheet"><div class="grab"></div><div class="sheet-title bookmark-title"><h3>${ui('bookmark')}</h3></div><div class="bookmark-choice-grid">${hasAyah?`<button class="primary full" id="bookmarkAyahBtn">${ui('bookmarkThisAyah')}</button>`:''}<button class="secondary full" id="bookmarkPageBtn">${ui('bookmarkThisPage')}</button></div></div></div>`;
  $('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};
  const ayahBtn=$('#bookmarkAyahBtn');if(ayahBtn)ayahBtn.onclick=()=>{if(saveAyahBookmark(key,state.page)){closeSheet();refreshMushafDock();toast(ui('ayahBookmarked'));}};
  const pageBtn=$('#bookmarkPageBtn');if(pageBtn)pageBtn.onclick=()=>{savePageBookmark(state.page);closeSheet();refreshMushafDock();toast(ui('pageBookmarked'));};
}

function pageKeysFromData(data){return [...wordsByVerse(data).keys()]}
function pageRatingsFor(page){return Object.entries(state.ratingPages).filter(([,p])=>Number(p)===Number(page)).map(([k])=>state.ratings[k]).filter(Boolean)}
function computedPageStatus(page){
  const explicit=state.pageRatings[page]||'';
  const vals=pageRatingsFor(page);
  if(!vals.length)return explicit;
  if(vals.includes('red'))return 'red';
  if(vals.includes('yellow'))return 'yellow';
  if(vals.every(v=>v==='green'))return 'green';
  return explicit;
}
function syncPageRating(page,data=pageCache.get(Number(page))){
  page=Number(page);if(!page)return '';
  const vals=pageRatingsFor(page);
  if(!vals.length){delete state.pageRatings[page];return ''}
  let status='';
  if(vals.includes('red'))status='red';
  else if(vals.includes('yellow'))status='yellow';
  else if(data){
    const keys=pageKeysFromData(data),rated=keys.filter(k=>state.ratings[k]);
    status=(keys.length&&rated.length===keys.length&&rated.every(k=>state.ratings[k]==='green'))?'green':'';
  }else if(state.pageRatings[page]==='green')status='green';
  if(status)state.pageRatings[page]=status;else delete state.pageRatings[page];
  return status;
}
function applyRating(key,rating,page=state.page,recordHistory=true){
  if(!key||!rating)return;
  state.ratings[key]=rating;state.ratingPages[key]=Number(page);
  if(recordHistory){const now=Date.now();state.ratingHistory[`${key}|${now}`]={key,rating,ts:now,page:Number(page)};}
  syncPageRating(page);
}
function completedJuzCount(){
  let n=0;
  for(let j=1;j<=30;j++){
    const a=JUZ_START_PAGES[j-1],b=(JUZ_START_PAGES[j]||605)-1;
    let ok=true;for(let p=a;p<=b;p++){if(state.pageRatings[p]!=='green'){ok=false;break}}
    if(ok)n++;
  }
  return n;
}
function progressPercent(){
  const vals=Object.values(state.ratings);if(!vals.length)return 0;
  const score=vals.reduce((a,r)=>a+(r==='green'?1:r==='yellow'?.55:r==='red'?.15:0),0);
  const p=score/SURAH_COUNTS.reduce((a,b)=>a+b,0)*100;
  return Math.max(.1,Math.round(p*10)/10);
}
function fullStrongPageCount(){return Object.values(state.pageRatings).filter(v=>v==='green').length}
function countPages(v){let n=0;for(let p=1;p<=604;p++)if(computedPageStatus(p)===v)n++;return n}
function progressBarWidth(){const p=progressPercent();return p>0?Math.max(1.5,p):0}
let ratingMigrationRunning=false;
async function migrateRatingPages(){
  if(ratingMigrationRunning)return false;
  ratingMigrationRunning=true;let changed=false;const affected=new Set();
  try{
    let locatorByKey=null;
    try{const loc=await loadAyaLocator();if(loc){locatorByKey=new Map();for(const [page,arr] of loc)for(const item of arr)locatorByKey.set(item.key,Number(page));}}catch{}
    for(const key of Object.keys(state.ratings)){
      if(state.ratingPages[key])continue;
      const p=locatorByKey?.get(key)||await locateVersePage(key);
      if(p){state.ratingPages[key]=p;affected.add(p);changed=true;}
    }
    for(const page of affected){try{const d=await fetchPage(page);syncPageRating(page,d)}catch{syncPageRating(page)}}
    if(changed)saveAll();
    return changed;
  }finally{ratingMigrationRunning=false}
}


async function fetchPage(page){
  if(pageCache.has(page)) return pageCache.get(page);
  const r=await fetch(`${LAYOUT_BASE}/page-${pagePad(page)}.json`); if(!r.ok) throw new Error(`Page ${page} data failed`);
  const d=await r.json(); pageCache.set(page,d); return d;
}
async function ensureFont(page,source){
  const key=`${source}-${page}`; if(fontCache.has(key)) return fontCache.get(key);
  const family=`QCF-${source}-${page}`, url=source==='tajweed'?FONT_V4(page):FONT_V2(page);
  const f=new FontFace(family,`url(${url}) format('woff2')`); await f.load(); document.fonts.add(f); fontCache.set(key,family); return family;
}



async function loadAyaLocator(){
  if(ayaLocatorMap)return ayaLocatorMap;
  if(ayaLocatorPromise)return ayaLocatorPromise;
  ayaLocatorPromise=(async()=>{
    try{
      const cached=localStorage.getItem('qh-quranhub-aya-locator-v1');
      if(cached){
        const rows=JSON.parse(cached);
        ayaLocatorMap=new Map(rows.map(([p,v])=>[Number(p),v]));
        return ayaLocatorMap;
      }
    }catch{}
    const r=await fetch(QURANHUB_AYA_LOCATOR_URL,{cache:'force-cache'});
    if(!r.ok)throw new Error('QuranHub ayah locator data could not be loaded');
    const txt=await r.text(), map=new Map();
    for(const line of txt.split(/\r?\n/)){
      if(!line||line.startsWith('aya_id'))continue;
      const [idS,pageS,xS,yS]=line.split(',');
      const id=Number(idS),page=Number(pageS),x=Number(xS),y=Number(yS);
      if(!id||!page||!Number.isFinite(x)||!Number.isFinite(y))continue;
      const key=absoluteToKey(id-1); // QuranHub CSV aya_id is 1-based absolute ayah index.
      if(!key)continue;
      if(!map.has(page))map.set(page,[]);
      map.get(page).push({id,key,x,y});
    }
    for(const arr of map.values())arr.sort((a,b)=>a.id-b.id);
    ayaLocatorMap=map;
    try{localStorage.setItem('qh-quranhub-aya-locator-v1',JSON.stringify([...map.entries()]));}catch{}
    return map;
  })().catch(e=>{console.warn(e);ayaLocatorPromise=null;return null});
  return ayaLocatorPromise;
}
function estimateLocatorLineOffset(markers){
  const step=QURANHUB_LOCATOR_SOURCE.lineStep;
  let best=82,bestErr=Infinity;
  for(let off=65;off<=155;off+=.5){
    let err=0;
    for(const m of markers){const row=Math.round((m.y-off)/step),pred=off+row*step,d=m.y-pred;err+=d*d;}
    if(err<bestErr){bestErr=err;best=off;}
  }
  return best;
}
function locatorRectsForPage(markers,data){
  if(!markers?.length)return [];
  const C=QURANHUB_LOCATOR_SOURCE, off=estimateLocatorLineOffset(markers), out=[];
  const textRows=new Set((data?.lines||[]).map((line,i)=>line?.type==='text'?i:null).filter(i=>i!==null));
  const norm=m=>({ ...m, row:Math.max(0,Math.min(14,Math.round((m.y-off)/C.lineStep))) });
  const ms=markers.map(norm);
  for(let i=0;i<ms.length;i++){
    const cur=ms[i], prev=i?ms[i-1]:{row:0,x:C.textRight,key:null};
    const add=(row,left,right)=>{
      if(textRows.size && !textRows.has(row))return;
      left=Math.max(C.textLeft,Math.min(C.textRight,left));right=Math.max(C.textLeft,Math.min(C.textRight,right));
      if(right-left<9)return;
      out.push({key:cur.key,row,left,right,top:off+row*C.lineStep-5,height:C.lineHeight});
    };
    if(prev.row===cur.row){
      add(cur.row,cur.x+C.markerWidth,prev.x-3);
    }else{
      add(prev.row,C.textLeft,prev.x-3);
      for(let row=prev.row+1;row<cur.row;row++)add(row,C.textLeft,C.textRight);
      add(cur.row,cur.x+C.markerWidth,C.textRight);
    }
  }
  return out;
}
async function hydrateAyaLocatorRegions(host,page,data){
  const wrap=host.querySelector('.page-image-wrap');if(!wrap)return;
  const map=await loadAyaLocator();
  const markers=map?.get(page);if(!markers?.length)return;
  let layer=wrap.querySelector('.ayah-region-layer');
  if(!layer){layer=document.createElement('div');layer.className='ayah-region-layer';wrap.appendChild(layer);}
  const rects=locatorRectsForPage(markers,data), C=QURANHUB_LOCATOR_SOURCE;
  wrap._locatorRects=rects;
  wrap._locatorPageData=data;
  const regionBlur=state.hide;
  wrap.classList.toggle('locator-region-mode',regionBlur);
  layer.innerHTML=rects.map((r,i)=>`<button class="ayah-hit-segment ${r.key===state.currentVerseKey?'current':''} ${regionBlur&&!state.revealedAyahs[r.key]?'blurred':''}" data-locator-verse="${r.key}" aria-label="${uit('selectAyahAria',{ref:fmtVerseKey(r.key)})}" style="left:${(r.left/C.width*100).toFixed(4)}%;top:${(r.top/C.height*100).toFixed(4)}%;width:${((r.right-r.left)/C.width*100).toFixed(4)}%;height:${(r.height/C.height*100).toFixed(4)}%"></button>`).join('');
  layer.querySelectorAll('[data-locator-verse]').forEach(el=>el.onclick=e=>{e.stopPropagation();selectVerse(el.dataset.locatorVerse,page)});
  wrap.onclick=e=>{if(e.target.closest('[data-locator-verse],.image-qword'))return;e.stopPropagation();state.currentVerseKey=null;state.hintWordKey=null;render()};
  if(regionBlur){
    const img=wrap.querySelector('.page-image');
    const draw=()=>requestAnimationFrame(()=>renderLocatorRevealWindows(wrap,page));
    if(img?.complete)draw(); else img?.addEventListener('load',draw,{once:true});
  }
}
function locatorWordWeight(word){
  const txt=(word?.word||'').normalize('NFD').replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,'');
  // Arabic letters are not monospaced; a mild sqrt term prevents long words from
  // stealing too much line width while still giving them a visibly larger box.
  const n=Math.max(1,[...txt].length);
  return 0.72*n+0.9*Math.sqrt(n)+0.45;
}
function locatorWordBoxesForVerse(wrap,key){
  const C=QURANHUB_LOCATOR_SOURCE;
  const rects=(wrap._locatorRects||[]).filter(r=>r.key===key).sort((a,b)=>a.row-b.row||b.right-a.right);
  const data=wrap._locatorPageData;
  const words=data?getVerseWords(data,key):[];
  if(!rects.length||!words.length)return new Map();

  // Treat all ayah line segments as one RTL reading path. QuranHub gives the
  // exact start/end line geometry; word widths are then distributed across that
  // path using the actual word strings. This is much more stable than using the
  // invisible QCF glyph overlay, whose metrics differ from the raster page.
  const segs=rects.map(r=>({...r,len:Math.max(1,r.right-r.left)}));
  const totalPath=segs.reduce((a,r)=>a+r.len,0);
  const weights=words.map(locatorWordWeight);
  const totalWeight=weights.reduce((a,b)=>a+b,0);
  let pathCursor=0;
  const out=new Map();

  function pointAt(dist){
    let d=Math.max(0,Math.min(totalPath,dist));
    let acc=0;
    for(let i=0;i<segs.length;i++){
      const seg=segs[i];
      if(d<=acc+seg.len||i===segs.length-1){
        const local=Math.max(0,Math.min(seg.len,d-acc));
        return {seg,index:i,x:seg.right-local};
      }
      acc+=seg.len;
    }
    const seg=segs[segs.length-1];return {seg,index:segs.length-1,x:seg.left};
  }

  words.forEach((word,i)=>{
    const span=weights[i]/totalWeight*totalPath;
    const startD=pathCursor, endD=pathCursor+span;
    const mid=pointAt((startD+endD)/2);
    const seg=mid.seg;
    let a=pointAt(startD),b=pointAt(endD);
    // A word should never reveal across two visual lines. If our proportional
    // boundary lands on a line break, keep the box on the line containing its midpoint.
    let left,right;
    if(a.index===mid.index&&b.index===mid.index){left=Math.min(a.x,b.x);right=Math.max(a.x,b.x)}
    else{
      const desired=Math.max(12,span);
      right=Math.min(seg.right,mid.x+desired/2);
      left=Math.max(seg.left,mid.x-desired/2);
    }
    const pad=Math.min(7,Math.max(2,(right-left)*.10));
    left=Math.max(seg.left,left-pad);right=Math.min(seg.right,right+pad);
    out.set(word.location,{left,right,top:seg.top,height:seg.height});
    pathCursor=endD;
  });
  return out;
}
function renderLocatorRevealWindows(wrap,page){
  let reveal=wrap.querySelector('.locator-reveal-layer');
  if(!reveal){reveal=document.createElement('div');reveal.className='locator-reveal-layer';wrap.appendChild(reveal)}
  const key=state.currentVerseKey;
  if(!key||state.revealedAyahs[key]){reveal.innerHTML='';return}
  const wanted=[...(state.revealed[key]||[])];if(state.hintWordKey)wanted.push(state.hintWordKey);
  if(!wanted.length){reveal.innerHTML='';return}

  const boxes=locatorWordBoxesForVerse(wrap,key),C=QURANHUB_LOCATOR_SOURCE;
  const wr=wrap.getBoundingClientRect(),img=wrap.querySelector('.page-image');
  if(!img||!wr.width||!wr.height){reveal.innerHTML='';return}

  reveal.innerHTML=wanted.map(loc=>{
    let box=boxes.get(loc);
    // Fallback to the previous DOM geometry only if locator reconstruction could
    // not resolve this word (e.g. a rare page-layout anomaly).
    if(!box){
      const el=wrap.querySelector(`.image-qword[data-location="${CSS.escape(loc)}"]`);
      if(!el)return '';
      const r=el.getBoundingClientRect();
      box={left:(r.left-wr.left)/wr.width*C.width,right:(r.right-wr.left)/wr.width*C.width,top:(r.top-wr.top)/wr.height*C.height,height:r.height/wr.height*C.height};
    }
    const x=Math.max(0,box.left/C.width*wr.width),y=Math.max(0,box.top/C.height*wr.height);
    const w=Math.min(wr.width-x,Math.max(7,(box.right-box.left)/C.width*wr.width));
    const h=Math.min(wr.height-y,Math.max(8,box.height/C.height*wr.height));
    const hint=loc===state.hintWordKey;
    return `<span class="locator-reveal-piece ${hint?'hint':''}" style="left:${x.toFixed(2)}px;top:${y.toFixed(2)}px;width:${w.toFixed(2)}px;height:${h.toFixed(2)}px;background-image:url('${PAGE_IMAGE(page)}');background-size:${wr.width.toFixed(2)}px ${wr.height.toFixed(2)}px;background-position:-${x.toFixed(2)}px -${y.toFixed(2)}px"></span>`;
  }).join('');
}


function applyTheme(){
  const pref=state.settings.theme||'light';
  const actual=pref==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):pref;
  document.documentElement.dataset.theme=actual;
}
function isCompactDevice(){const d=document.querySelector('.device');return (d?.clientWidth||window.innerWidth)<620}
function normalizeResponsiveView(){if(isCompactDevice()&&state.view==='double')state.view='single'}
function absoluteToKey(abs){let n=Number(abs);for(let s=1;s<=SURAH_COUNTS.length;s++){const c=SURAH_COUNTS[s-1];if(n<c)return `${s}:${n+1}`;n-=c;}return null}
function keyToAbsolute(key){const [s,a]=key.split(':').map(Number);let n=a-1;for(let i=0;i<s-1;i++)n+=SURAH_COUNTS[i];return n}
async function loadMutashData(){if(mutashCache)return mutashCache;const r=await fetch(MUTASH_URL);if(!r.ok)throw new Error('Mutashabihat data failed');mutashCache=await r.json();return mutashCache}
const verseTextCache=new Map();
async function fetchVerseText(key){if(verseTextCache.has(key))return verseTextCache.get(key);try{const r=await fetch(`${QURAN_API}/verses/by_key/${key}?fields=text_uthmani&words=false`);const j=await r.json();const txt=j?.verse?.text_uthmani||'';verseTextCache.set(key,txt);return txt}catch{return ''}}
async function loadPickthall(){
  if(pickthallMap)return pickthallMap;
  const cached=localStorage.getItem('qh-pickthall-v1');
  if(cached){
    try{const arr=JSON.parse(cached);pickthallMap=new Map(arr);return pickthallMap}catch{}
  }
  const r=await fetch(PICKTHALL_URL,{cache:'force-cache'});
  if(!r.ok)throw new Error('Pickthall translation download failed');
  const txt=await r.text();
  const rows=[];
  for(const line of txt.split(/\r?\n/)){
    if(!line.trim())continue;
    const a=line.indexOf('|'),b=line.indexOf('|',a+1);
    if(a<0||b<0)continue;
    rows.push([`${line.slice(0,a)}:${line.slice(a+1,b)}`,line.slice(b+1).trim()]);
  }
  pickthallMap=new Map(rows);
  try{localStorage.setItem('qh-pickthall-v1',JSON.stringify(rows))}catch{}
  return pickthallMap;
}
async function fetchTranslation(key,lang=state.settings.translationLang||'en'){
  if(!key)return '';
  const meta=TRANSLATIONS[lang]||TRANSLATIONS.en;
  const cacheKey=`${lang}|${key}`;
  if(translationCache.has(cacheKey))return translationCache.get(cacheKey);
  const localKey=`qh-trans-${meta.key}-${key}`;
  const cached=localStorage.getItem(localKey);
  if(cached){translationCache.set(cacheKey,cached);return cached;}
  try{
    const [surah,ayah]=key.split(':').map(Number);
    const r=await fetch(`${QURANENC_API}/${meta.key}/${surah}/${ayah}`,{cache:'force-cache'});
    if(!r.ok)throw new Error(`QuranEnc ${r.status}`);
    const j=await r.json();
    const obj=j?.result||j?.data||j;
    const t=(obj?.translation||obj?.text||'').toString().trim();
    if(t){translationCache.set(cacheKey,t);try{localStorage.setItem(localKey,t)}catch{}return t;}
  }catch(e){console.warn('QuranEnc translation failed',e)}
  // English only: retain the bundled/public Pickthall network fallback so an
  // intermittent QuranEnc failure does not leave the translation panel empty.
  if(lang==='en'){
    try{const map=await loadPickthall();const t=map.get(key)||'';if(t){translationCache.set(cacheKey,t);return t;}}catch{}
  }
  return '';
}
function translationMeta(){return TRANSLATIONS[state.settings.translationLang||'en']||TRANSLATIONS.en}
function syncTranslationToUiLang(force=false){const uiLang=state?.settings?.uiLang||'en',cur=state.settings.translationLang;if(force||!cur||cur==='en'||cur===state._lastUiLang){state.settings.translationLang=TRANSLATIONS[uiLang]?uiLang:(cur||'en');}state._lastUiLang=uiLang;}
function flattenMutash(data){return Object.values(data||{}).flat()}
function entryContainsAbs(entry,abs){const src=Array.isArray(entry?.src?.ayah)?entry.src.ayah:[entry?.src?.ayah];return src.includes(abs)}
function lcsDiff(a,b){const A=a.split(/\s+/),B=b.split(/\s+/),m=A.length,n=B.length,dp=Array.from({length:m+1},()=>Array(n+1).fill(0));for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--)dp[i][j]=A[i]===B[j]?dp[i+1][j+1]+1:Math.max(dp[i+1][j],dp[i][j+1]);let i=0,j=0,keepA=new Set(),keepB=new Set();while(i<m&&j<n){if(A[i]===B[j]){keepA.add(i);keepB.add(j);i++;j++;}else if(dp[i+1][j]>=dp[i][j+1])i++;else j++;}return {a:A.map((w,k)=>({w,diff:!keepA.has(k)})),b:B.map((w,k)=>({w,diff:!keepB.has(k)}))}}
function markedArabic(parts){return parts.map(x=>`<span class="${!x.diff?'mut-similar':''}">${escapeHtml(x.w)}</span>`).join(' ')}
function commonPhraseFromDiff(parts){let best=[],cur=[];for(const x of parts){if(!x.diff){cur.push(x.w);if(cur.length>best.length)best=[...cur]}else cur=[]}if(best.length<2)best=parts.filter(x=>!x.diff).slice(0,7).map(x=>x.w);return best.slice(0,9).join(' ')}
function bottomNav(){
  const tabs=[['home',ui('home'),'home'],['mushaf',ui('mushaf'),'mushaf'],['review',ui('review'),'review'],['practice',ui('practice'),'sparkle'],['progress',ui('progress'),'progress']];
  const active=(state.tab==='mutash'||state.tab==='practiceTest')?'practice':state.tab;
  return `<div class="bottom-nav">${tabs.map(([k,l,ic])=>`<button class="nav-item ${active===k?'active':''}" data-go="${k}">${icon(ic)}<span>${l}</span></button>`).join('')}</div>`;
}
function header(){return `<div class="header">${appIconMarkup()}<div class="header-title"><h1>Memorize Quran</h1><p>${ui('continueJourney')}</p></div><button class="icon-btn settings" data-go="settings">${icon('settings')}</button></div>`}
function shell(content){return `<div class="shell shell-${state.tab}">${header()}<div class="screen screen-${state.tab}">${content}</div>${bottomNav()}</div>`}

function render(){
  try{
    normalizeResponsiveView();
    applyTheme();
    syncTranslationToUiLang(false);document.documentElement.lang=state.settings.uiLang||'en';document.documentElement.dir=LANGUAGES[state.settings.uiLang]?.dir||'ltr';
    const content=state.tab==='mushaf'?mushafScreen():shell(tabContent());
    app.innerHTML=content; bind();
    if(state.tab==='mushaf') hydrateMushaf().catch(e=>showMushafError(e));
    if(state.tab==='progress') hydrateProgress().catch(()=>{});
    if(state.tab==='mutash') hydrateMutashPage().catch(e=>{const b=$('#mutashPageBody');if(b)b.innerHTML=`<div class="empty-card">${ui('couldNotLoadMutashData')}<br><small>${escapeHtml(e.message)}</small></div>`});
    if(state.tab==='practiceTest') hydratePracticeTest().catch(e=>{const b=$('#practiceTestPage');if(b)b.innerHTML=`<div class="empty-card">${ui('couldNotLoadPracticePage')}<br><small>${escapeHtml(e.message)}</small></div>`});
    if(!languageSetupDone)setTimeout(showLanguageOnboarding,60);
  }catch(e){
    console.error(e); app.innerHTML=`<div class="fatal"><b>${ui('couldNotRenderScreen')}</b><small>${escapeHtml(e.message)}</small><button class="primary" onclick="location.reload()">${ui('reload')}</button></div>`;
  }
}
function mushafScrollTop(){return document.querySelector('.mushaf-screen')?.scrollTop||0}
function renderPreserveMushafScroll(){
  const top=mushafScrollTop();render();
  const restore=()=>{const sc=document.querySelector('.mushaf-screen');if(sc)sc.scrollTop=top};
  requestAnimationFrame(restore);setTimeout(restore,80);setTimeout(restore,220);
}

function screenScrollTop(){return document.querySelector('.screen')?.scrollTop||window.scrollY||0}
function renderPreserveScreenScroll(){
  const top=screenScrollTop();render();
  const restore=()=>{const sc=document.querySelector('.screen');if(sc)sc.scrollTop=top;else window.scrollTo(0,top)};
  requestAnimationFrame(restore);setTimeout(restore,80);setTimeout(restore,220);
}

function refreshMushafDock(){
  const dock=document.querySelector('.mushaf-control-dock');if(!dock){renderPreserveMushafScroll();return}
  dock.innerHTML=`${panelContent()}${toolbar()}`;bind();
  if(state.activePanel==='translation')hydrateTranslationPanel().catch(()=>{});
}

function tabContent(){if(state.tab==='home')return home();if(state.tab==='review')return review();if(state.tab==='practice')return practice();if(state.tab==='mutash')return mutashPage();if(state.tab==='practiceTest')return practiceTestScreen();if(state.tab==='progress')return progress();if(state.tab==='settings')return settings();return home()}

function home(){
  const due=Object.values(state.ratings).filter(x=>x!=='green').length, pages=due?Math.ceil(due/12):0;
  const newRange=`${surahDisplayName(18)} ${fmtNum(1)}–${fmtNum(5)}`;
  return `<div class="pad home-pad"><section class="home-hero"><div class="home-sky"><div><h2>${ui('greeting')}</h2><p>${ui('continueJourney')}</p></div></div><section class="card plan-card"><h3>${ui('todayPlan')}</h3>${planRow('mushaf',ui('newMem'),newRange,'mushaf','newmem')}${planRow('review',ui('revisionDue'),uit('ayahPageCount',{ayahs:fmtNum(due),pages:fmtNum(pages)}),'review')}</section></section><section class="card summary"><div class="summary-top"><span>${ui('overall')}</span><span>${fmtNum(progressPercent())}%</span></div><div class="bar"><span style="width:${progressBarWidth()}%"></span></div><div class="metrics"><div class="metric"><b>${fmtNum(completedJuzCount())}</b><small>${ui('juzCompleted')}</small></div><div class="metric"><b>${fmtNum(fullStrongPageCount())}</b><small>${ui('pagesMemorized')}</small></div><div class="metric"><b>${fmtNum(due)}</b><small>${ui('ayahsReview')}</small></div></div></section><h3 class="section-title">${ui('quick')}</h3><div class="quick-row">${quickAction('resume',ui('resume'),uit('pageN',{page:fmtNum(state.page)}),'mushaf')}${quickAction('weak',ui('weak'),ui('ayahsReview'),'review')}${quickAction('muta',ui('mutash'),ui('similarAyahPractice'),'target')}${quickAction('listen',ui('listen'),ui('currentAyahAudio'),'headphones')}</div></div>`;
}
function planRow(ic,title,sub,go,action=''){return `<div class="plan-row"><span class="badge">${icon(ic)}</span><div class="plan-copy"><b>${title}</b><small>${sub}</small></div><button class="primary" ${action?`data-plan-action="${action}"`:`data-go="${go}"`}>${ui('start')}</button></div>`}
function quick(t,s,ic,go){return `<button class="quick" data-go="${go}"><span class="qicon">${icon(ic)}</span><b>${t}</b><small>${s}</small></button>`}
function quickAction(action,t,s,ic){return `<button class="quick" data-quick="${action}"><span class="qicon">${icon(ic)}</span><b>${t}</b><small>${s}</small></button>`}

function mushafScreen(){
  const sideKey=pageSide(state.page)==='right'?'rightPage':'leftPage',surahNo=currentSurahNumber(),surahName=surahDisplayName(surahNo),back=backIcon();
  return `<div class="screen mushaf-screen source-${state.source} view-${state.view}"><div class="mushaf-top-ui"><div class="mushaf-header"><button class="icon-btn" id="topBackBtn" aria-label="${state.returnTo?.tab==='mutash'?ui('backToList'):state.returnTo?.tab==='progress'?ui('progress'):ui('home')}">${back}</button><button class="mushaf-title-button" id="surahTitleBtn" aria-label="${ui('jumpTitle')}"><span class="mushaf-title-copy"><b id="mushafSurahName">${surahName}</b><small>${ui('page')} ${fmtNum(state.page)} · ${ui('juz')} ${fmtNum(pageJuz(state.page))} · ${ui(sideKey)}</small></span><span class="title-chevron">⌄</span></button><button class="icon-btn menu-button ${state.mushafOptionsOpen?'active':''}" id="menuBtn" aria-label="${ui('displayOptions')}" aria-expanded="${state.mushafOptionsOpen?'true':'false'}">${icon('menu')}</button></div><div class="mushaf-display-options ${state.mushafOptionsOpen?'open':''}" aria-hidden="${state.mushafOptionsOpen?'false':'true'}"><div class="top-controls"><div class="seg"><button class="${state.view==='single'?'active':''}" data-view="single">${icon('mushaf')} ${ui('single')}</button><button class="two-page-btn ${state.view==='double'?'active':''}" data-view="double">${icon('book')} ${ui('twoPage')}</button><button class="${state.view==='scroll'?'active':''}" data-view="scroll">${icon('scroll')} ${ui('scroll')}</button></div></div><div class="source-switch"><button class="${state.source==='plain'?'active':''}" data-source="plain">${ui('standard')}</button><div class="tajweed-source-group ${state.source==='tajweed'?'active':''}"><button class="${state.source==='tajweed'?'active':''}" data-source="tajweed">${ui('tajweedColors')}</button><button class="tajweed-info-btn" id="tajweedInfoBtn" type="button" aria-label="${ui('tajweedInfo')}">i</button></div></div></div></div>${mushafStage()}</div><div class="mushaf-control-dock">${panelContent()}${toolbar()}</div>`;
}

function mushafStage(){
  if(state.view==='double'){
    const right=state.page%2===1?state.page:Math.max(1,state.page-1), left=Math.min(604,right+1);
    return `<div class="double-spread"><div class="spread-page"><div class="real-page" id="page-${left}"><div class="page-loading">${ui('loading')}</div></div></div><div class="spread-page"><div class="real-page" id="page-${right}"><div class="page-loading">${ui('loading')}</div></div></div></div>`;
  }
  if(state.view==='scroll') return `<div class="mobile-scroll-reader" id="scrollReader"><div class="page-loading">${ui('loadingReadingView')}</div></div>`;
  const side=pageSide(state.page);return `<div class="book-wrap single-wrap ${side}"><div class="spread-bg-shell ${side}"><button class="float-nav float-prev" id="prevPage">${icon('left')}</button><div class="real-page" id="page-${state.page}"><div class="page-loading">${ui('loadingMushafPage')}</div></div><button class="float-nav float-next" id="nextPage">${icon('right')}</button></div></div>`;
}

function gutter(side){return `<div class="gutter ${side}"><span class="gutter-shadow"></span><span class="gutter-fold"></span></div>`}

function mushafControlDock(){return `<div class="mushaf-control-dock">${toolbar()}</div>`}
function toolbar(){return `<div class="page-toolbar"><button class="page-tool ${state.activePanel==='audio'?'active':''}" id="audioBtn">${icon('audio')}<span>${ui('audio')}</span></button><button class="page-tool ${state.activePanel==='hide'?'active':''}" id="hideBtn">${icon('eyeoff')}<span>${ui('hide')}</span></button><button class="page-tool ${state.translation?'active':''}" id="translationBtn">${icon('translate')}<span>${ui('translation')}</span></button><button class="page-tool ${currentBookmarkActive()?'active':''}" id="bookmarkBtn">${icon('bookmark')}<span>${ui('bookmark')}</span></button><button class="page-tool ${state.activePanel==='eval'?'active':''}" id="evalBtn">${icon('star')}<span>${ui('evaluate')}</span></button></div>`}
function panelContent(){if(state.activePanel==='audio')return audioPanel();if(state.activePanel==='hide')return memoryPanel();if(state.activePanel==='translation')return translationPanel();if(state.activePanel==='eval')return evaluationPanel();return ''}
function audioPanel(){
  const rec=AUDIO[state.reciter];
  return `<section class="mushaf-drawer audio-drawer"><div class="drawer-head"><b>${ui('ayahAudio')}</b><small>${state.currentVerseKey?fmtVerseKey(state.currentVerseKey):ui('tapAyahFirst')}</small></div><div class="audio-main"><button class="play-btn" id="playAudio">${icon(state.audioPlaying?'pause':'play')}</button><div class="audio-meta"><b>${reciterLabel(state.reciter)}</b><div class="audio-progress"><span id="audioProgress"></span></div></div></div><div class="audio-options"><div><label>${ui('repeat')}</label><div class="repeat-row">${[1,3,5,10].map(x=>`<button data-repeat="${x}" class="${state.repeat===x?'active':''}">${fmtNum(x)}×</button>`).join('')}</div></div><select class="select compact" id="reciterSelect">${Object.entries(AUDIO).map(([k,v])=>`<option value="${k}" ${k===state.reciter?'selected':''}>${reciterLabel(k)}</option>`).join('')}</select></div><div class="drawer-toggles"><label><span>${ui('autoPlay')}</span><button class="switch ${state.autoNext?'on':''}" id="autoNextToggle"></button></label><label><span>${ui('pauseAfter')}</span><button class="switch ${state.pause?'on':''}" id="pauseToggle"></button></label></div></section>`;
}
function memoryPanel(){return `<section class="mushaf-drawer memory-drawer"><button id="hintBtn">${icon('bulb')}<span>${ui('hint')}</span></button><button id="revealBtn">${icon('reveal')}<span>${ui('reveal')}</span></button><button id="showAyahBtn">${icon('eye')}<span>${ui('showAyah')}</span></button><button class="primary" id="nextAyahBtn">${ui('nextAyah')}</button></section>`}
function translationPanel(){const m=translationMeta();return `<section class="mushaf-drawer translation-drawer" dir="${m.dir}"><div class="drawer-head"><b>${m.title} — ${m.author}</b><small>${state.currentVerseKey?fmtVerseKey(state.currentVerseKey):ui('tapAyah')}</small></div><div class="translation-text" id="translationText">${state.currentVerseKey?ui('loadingTranslation'):ui('tapAyah')}</div><div class="translation-credit">${m.source} · ${m.version}</div></section>`}
function evaluationPanel(){
  if(!state.currentVerseKey)return `<section class="mushaf-drawer eval-top-drawer"><div class="drawer-head"><b>${ui('selfEvaluation')}</b><small>${ui('tapAyahFirst')}</small></div></section>`;
  const key=state.currentVerseKey,[ss]=key.split(':').map(Number),scope=state.evalScope||'ayah',preview=versePreview(key,6),selected=scope==='page'?(computedPageStatus(state.page)||''):(state.ratings[key]||''),note=state.notes[key]||'';
  const pageCount=currentPageData()?pageKeysFromData(currentPageData()).length:0;
  return `<section class="mushaf-drawer eval-top-drawer"><div class="drawer-head"><b>${ui('selfEvaluation')}</b><small>${scope==='ayah'?`${surahDisplayName(ss)} ${fmtVerseKey(key)}`:`${ui('page')} ${fmtNum(state.page)}`}</small></div><div class="eval-scope-tabs"><button class="${scope==='ayah'?'active':''}" data-eval-scope="ayah">${ui('selectedAyah')}</button><button class="${scope==='page'?'active':''}" data-eval-scope="page">${ui('wholePage')}</button></div>${scope==='ayah'?`<div class="eval-preview-ar">${escapeHtml(preview)}…</div>`:`<div class="eval-page-copy">${uit('applyOneRating',{count:fmtNum(pageCount||''),page:fmtNum(state.page)})}</div>`}<div class="eval-compact-grid"><button class="eval-mini green ${selected==='green'?'selected':''}" data-inline-eval="green">${faceSvg('#6bdab3','smile')}<span>${ui('strongShort')}</span></button><button class="eval-mini yellow ${selected==='yellow'?'selected':''}" data-inline-eval="yellow">${faceSvg('#f4ca5c','flat')}<span>${ui('reviewShort')}</span></button><button class="eval-mini red ${selected==='red'?'selected':''}" data-inline-eval="red">${faceSvg('#f18080','sad')}<span>${ui('weakShort')}</span></button></div>${scope==='ayah'?`<details class="eval-note-details"><summary>${ui('addNote')}</summary><textarea id="inlineNoteInput" class="note-input" placeholder="${ui('optionalNote')}">${escapeHtml(note)}</textarea></details>`:''}<button class="primary eval-save" id="saveInlineEval" data-current-rating="${selected}">${ui('save')}</button></section>`;
}


async function hydrateMushaf(){
  if(state.view==='scroll'){await hydrateScrollReader();return;}
  if(state.view==='double'){
    const right=state.page%2===1?state.page:Math.max(1,state.page-1), left=Math.min(604,right+1);
    await Promise.all([hydratePage(left),hydratePage(right)]); return;
  }
  await hydratePage(state.page);
  if(state.activePanel==='translation')await hydrateTranslationPanel();
}
async function hydrateTranslationPanel(){const el=$('#translationText');if(!el||!state.currentVerseKey)return;const t=await fetchTranslation(state.currentVerseKey);el.textContent=t||ui('unavailable');}
function showMushafError(e){console.error(e);const host=document.querySelector('.real-page,.mobile-scroll-reader');if(host)host.innerHTML=`<div class="image-fallback">${ui('couldNotLoadMushafView')}<br><small>${escapeHtml(e.message)}</small></div>`}
async function hydratePage(page){
  const host=document.getElementById(`page-${page}`); if(!host)return;
  const data=await fetchPage(page);
  if(page===state.page&&(!state.currentVerseKey||!wordsByVerse(data).has(state.currentVerseKey)))state.currentVerseKey=firstVerseKey(data);
  if(page===state.page&&state.currentVerseKey){const sn=Number(state.currentVerseKey.split(':')[0]);if(sn){state.selectedSurah=sn;const titleEl=document.getElementById('mushafSurahName');if(titleEl)titleEl.textContent=surahDisplayName(sn);}}
  if(state.source==='plain'){
    const family=await ensureFont(page,'plain'); renderPlainPage(host,page,data,family); await hydrateAyaLocatorRegions(host,page,data); return;
  }
  const family=await ensureFont(page,'tajweed'); renderTajweedTemplatePage(host,page,data,family); requestAnimationFrame(()=>fitRenderedLines(host)); bindPageWords();host.onclick=e=>{if(e.target.closest('.qword'))return;state.currentVerseKey=null;state.hintWordKey=null;render()};
}
function renderPlainPage(host,page,data,family){
  const lines=data.lines||[], rowCount=Math.max(15,lines.length||15);
  const rows=lines.map((line,idx)=>{
    if(line.type==='text'){const ws=line.words||[];return `<div class="image-qline ${ws.length<6?'short-line':''}" style="font-family:'${family}'">${ws.map(w=>renderImageWord(w)).join('')}</div>`;}
    return `<div class="image-qline image-static"></div>`;
  }).join('');
  const firstPagesFix=page<=2;
  host.innerHTML=`<div class="page-image-wrap hafs-page-wrap ${firstPagesFix?'first-pages-fix':''}"><img class="page-image" src="${PAGE_IMAGE(page)}" alt="${uit('pageImageAlt',{page:fmtNum(page)})}">${firstPagesFix?'':`<div class="image-word-layer" style="--image-row-count:${rowCount}">${rows}</div>`}</div>`;
  const img=host.querySelector('.page-image'); if(img){img.onerror=()=>{if(!img.dataset.fallback){img.dataset.fallback='1';img.src=PAGE_IMAGE_FALLBACK(page)}else host.innerHTML=`<div class="image-fallback">${ui('hafsPageLoadError')}</div>`;};}
  if(!firstPagesFix){requestAnimationFrame(()=>fitImageInteraction(host));host.querySelectorAll('.image-qword').forEach(el=>el.onclick=e=>{e.stopPropagation();selectVerse(el.dataset.verse,page);});}
}

function renderLineTajweed(line,family){if(line.type==='surah-header')return `<div class="qline surah-header tajweed-surah-header">${escapeHtml(line.text)}</div>`;if(line.type==='basmala')return `<div class="qline basmala basmala-normal tajweed-basmala">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>`;const ws=(line.words||[]);return `<div class="qline tajweed-line ${ws.length<5?'short-line':''}" style="font-family:'${family}'">${ws.map(w=>renderWord(w)).join('')}</div>`}
function renderTajweedTemplatePage(host,page,data,family){
  const lines=data.lines||[], rowCount=Math.max(15,lines.length||15);
  const rows=lines.map(line=>renderLineTajweed(line,family)).join('');
  host.innerHTML=`<div class="tajweed-page-wrap css-tajweed-template page-side-${physicalPageSide(page)}"><div class="tajweed-page-bg"></div><div class="tajweed-text-layer page-side-${physicalPageSide(page)}" style="--tajweed-row-count:${rowCount}">${rows}</div></div>`;
}
function renderImageWord(w){const v=verseFromWord(w),revealed=(state.revealed[v.key]||[]).includes(w.location),hint=state.hintWordKey===w.location,current=state.currentVerseKey===v.key,hidden=state.hide&&!state.revealedAyahs[v.key]&&!revealed&&!hint;return `<span class="image-qword ${hidden?'hidden':''} ${hint?'hint':''}" data-location="${w.location}" data-verse="${v.key}" title="${escapeHtml(w.word)}"><span class="image-qglyph">${escapeHtml(w.qpcV2)}</span></span>`}
function fitImageInteraction(host){const wrap=host.querySelector('.page-image-wrap');if(!wrap)return;const base=Math.max(12,Math.min(20,wrap.clientWidth*.049));host.querySelectorAll('.image-qline').forEach(line=>{line.style.fontSize=`${base}px`;line.style.transform='';const a=line.clientWidth,b=line.scrollWidth;if(b>a&&a>0)line.style.transform=`scaleX(${Math.max(.8,a/b)})`;});}
function renderLine(line,family){if(line.type==='surah-header')return `<div class="qline surah-header">${escapeHtml(line.text)}</div>`;if(line.type==='basmala')return `<div class="qline basmala basmala-normal">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</div>`;return `<div class="qline" style="font-family:'${family}'">${(line.words||[]).map(w=>renderWord(w)).join('<span> </span>')}</div>`}
function renderWord(w){const v=verseFromWord(w),revealed=(state.revealed[v.key]||[]).includes(w.location),hint=state.hintWordKey===w.location,current=state.currentVerseKey===v.key,hidden=state.hide&&!state.revealedAyahs[v.key]&&!revealed&&!hint;return `<span class="qword ${hidden?'hidden':''} ${hint?'hint':''} ${current?'current':''}" data-verse="${v.key}" data-location="${w.location}">${escapeHtml(w.qpcV2)}</span>`}
function fitRenderedLines(host){const taj=!!host.closest('.source-tajweed');host.querySelectorAll('.qline:not(.surah-header)').forEach(line=>{line.style.transform='';const a=line.clientWidth-(taj?10:4),b=line.scrollWidth;if(a>0&&b>0){const fit=Math.min(taj?.965:1,a/b);if(fit<.999)line.style.transform=`scaleX(${Math.max(.72,fit)})`;}});}
function bindPageWords(){document.querySelectorAll('.qword').forEach(el=>el.onclick=()=>selectVerse(el.dataset.verse,state.page))}

function selectVerse(key,page){
  const shouldRestart=!audioEl.paused||state.audioPlaying;
  if(page) state.page=page;
  state.currentVerseKey=key;state.selectedSurah=Number(key.split(':')[0])||state.selectedSurah;
  state.hintWordKey=null;
  render();
  if(shouldRestart){
    setTimeout(()=>{state.repeatRemaining=state.repeat;playAudioOnce()},120);
  }
}

async function hydrateScrollReader(){
  const host=$('#scrollReader'); if(!host)return;
  const pages=[state.page,Math.min(604,state.page+1)]; const all=[];
  for(const p of pages){const d=await fetchPage(p);for(const [key,words] of wordsByVerse(d))all.push({key,words,page:p});}
  if(!state.currentVerseKey&&all.length)state.currentVerseKey=all[0].key;
  const wordHtml=(w,key)=>{const shown=(state.revealed[key]||[]).includes(w.location),hint=state.hintWordKey===w.location,current=state.currentVerseKey===key,hidden=state.hide&&!state.revealedAyahs[key]&&!shown&&!hint;return `<span class="scroll-word ${hidden?'hidden':''} ${hint?'hint':''}" data-scroll-word="${w.location}" data-scroll-verse="${key}">${escapeHtml(w.word)}</span>`};
  host.innerHTML=all.map(v=>{const r=state.ratings[v.key]||'',note=state.notes[v.key];return `<article class="scroll-ayah ${state.currentVerseKey===v.key?'selected':''}" data-scroll-card="${v.key}" data-vpage="${v.page}"><div class="scroll-ayah-top"><span class="ayah-ref">${fmtVerseKey(v.key)}</span><span class="status-dot ${r==='green'?'g':r==='yellow'?'y':r==='red'?'r':''}"></span>${note?`<span class="note-mark">${icon('note')}</span>`:''}</div><div class="scroll-arabic">${v.words.map(w=>wordHtml(w,v.key)).join(' ')}</div>${state.translation?`<div class="scroll-translation" dir="${translationMeta().dir}" id="scroll-trans-${v.key.replace(':','-')}">${ui('loadingTranslation')}</div>`:''}<div class="scroll-footer"><span>${ui('page')} ${fmtNum(v.page)}</span><button class="scroll-audio-btn" data-scroll-audio="${v.key}" data-vpage="${v.page}">${icon('audio')}</button></div></article>`}).join('');
  document.querySelectorAll('[data-scroll-card]').forEach(el=>el.onclick=e=>{if(e.target.closest('[data-scroll-audio]'))return;selectVerse(el.dataset.scrollCard,Number(el.dataset.vpage));});
  document.querySelectorAll('[data-scroll-word]').forEach(el=>el.onclick=e=>{e.stopPropagation();selectVerse(el.dataset.scrollVerse,Number(el.closest('[data-vpage]')?.dataset.vpage||state.page));});
  document.querySelectorAll('[data-scroll-audio]').forEach(el=>el.onclick=e=>{e.stopPropagation();selectVerse(el.dataset.scrollAudio,Number(el.dataset.vpage));setTimeout(()=>{state.repeatRemaining=state.repeat;playAudioOnce()},140);});
  if(state.translation){for(const v of all){const el=$(`#scroll-trans-${v.key.replace(':','-')}`);if(el){const t=await fetchTranslation(v.key);el.textContent=t||ui('unavailable');}}}
}

function currentWords(){const d=currentPageData();return d&&state.currentVerseKey?getVerseWords(d,state.currentVerseKey):[]}
function versePreview(key,n=8){const d=currentPageData(),ws=d?getVerseWords(d,key):[];return ws.slice(0,n).map(w=>w.word).join(' ')}
function showRandomHint(){const ws=currentWords();if(!ws.length)return toast(ui('selectAyahFirst'));const shown=state.revealed[state.currentVerseKey]||[],pool=ws.filter(w=>!shown.includes(w.location));const w=(pool.length?pool:ws)[Math.floor(Math.random()*(pool.length||ws.length))];state.hintWordKey=w.location;render()}
function revealNextWord(){const ws=currentWords();if(!ws.length)return toast(ui('selectAyahFirst'));const shown=state.revealed[state.currentVerseKey]||[],w=ws.find(x=>!shown.includes(x.location));if(!w)return toast(ui('ayahFullyRevealed'));state.revealed[state.currentVerseKey]=[...shown,w.location];state.hintWordKey=null;render();setTimeout(()=>toast(uit('revealedWord',{word:w.word})),70)}
function showCurrentAyah(){const ws=currentWords();if(!ws.length)return toast(ui('selectAyahFirst'));state.revealedAyahs[state.currentVerseKey]=true;state.revealed[state.currentVerseKey]=ws.map(w=>w.location);state.hintWordKey=null;render()}
function nextAyah(){
  const d=currentPageData();if(!d)return;
  const ks=[...wordsByVerse(d).keys()];
  let i=ks.indexOf(state.currentVerseKey);
  if(state.hide&&state.currentVerseKey){
    state.revealedAyahs[state.currentVerseKey]=true;
    const ws=getVerseWords(d,state.currentVerseKey);state.revealed[state.currentVerseKey]=ws.map(w=>w.location);
  }
  if(i<0&&ks.length){state.currentVerseKey=ks[0];state.hintWordKey=null;render();return}
  if(i>=0&&i<ks.length-1){state.currentVerseKey=ks[i+1];state.hintWordKey=null;render()}
  else if(state.page<604){state.page++;state.currentVerseKey=null;state.hintWordKey=null;render()}
}


const AUDIO_CACHE='quranhifz-offline-audio-v1';
let offlineAudioDbPromise=null,offlineAudioBlobUrl=null;
function openOfflineAudioDb(){if(offlineAudioDbPromise)return offlineAudioDbPromise;offlineAudioDbPromise=new Promise((resolve,reject)=>{try{const req=indexedDB.open('MemorizeQuranOfflineAudio',1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('audio')){const st=db.createObjectStore('audio',{keyPath:'url'});st.createIndex('reciter','reciter',{unique:false});}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);}catch(e){reject(e)}});return offlineAudioDbPromise}
async function offlineDbPut(url,reciter,blob){const db=await openOfflineAudioDb();return new Promise((resolve,reject)=>{const tx=db.transaction('audio','readwrite');tx.objectStore('audio').put({url,reciter,blob});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}
async function offlineDbGet(url){try{const db=await openOfflineAudioDb();return await new Promise((resolve,reject)=>{const tx=db.transaction('audio','readonly'),rq=tx.objectStore('audio').get(url);rq.onsuccess=()=>resolve(rq.result?.blob||null);rq.onerror=()=>reject(rq.error)})}catch{return null}}
async function offlineDbClear(){try{const db=await openOfflineAudioDb();await new Promise((resolve,reject)=>{const tx=db.transaction('audio','readwrite');tx.objectStore('audio').clear();tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error)})}catch{}}
async function resolvedAudioSource(url){const blob=await offlineDbGet(url);if(blob){if(offlineAudioBlobUrl)URL.revokeObjectURL(offlineAudioBlobUrl);offlineAudioBlobUrl=URL.createObjectURL(blob);return offlineAudioBlobUrl}return url}
function allAyahAudioUrls(reciter){const dir=AUDIO[reciter]?.dir||AUDIO.husary.dir,out=[];for(let s=1;s<=114;s++)for(let a=1;a<=SURAH_COUNTS[s-1];a++)out.push(`https://everyayah.com/data/${dir}/${String(s).padStart(3,'0')}${String(a).padStart(3,'0')}.mp3`);return out}
function offlineAudioMeta(){try{return JSON.parse(localStorage.getItem('qh-offline-audio-meta')||'{}')}catch{return {}}}
function saveOfflineAudioMeta(m){localStorage.setItem('qh-offline-audio-meta',JSON.stringify(m))}
async function refreshOfflineAudioStatus(){const el=$('#offlineAudioStatus'),txt=$('#offlineProgressText');if(!el)return;const rec=state.settings.offlineReciter,meta=offlineAudioMeta()[rec],total=SURAH_COUNTS.reduce((a,b)=>a+b,0);if(meta?.complete){el.textContent=`${ui('downloaded')} · ${reciterLabel(rec)}`;if(txt)txt.textContent=uit('offlineAyahsAvailable',{count:fmtNum(total)});}else if(meta?.count){el.textContent=`${fmtNum(meta.count)} / ${fmtNum(total)}`;if(txt)txt.textContent=ui('tapDownloadContinue');}else{el.textContent=ui('notDownloaded');if(txt)txt.textContent='';}}
async function downloadAllAudio(){
  if(state.audioDownload)return;
  const rec=state.settings.offlineReciter,urls=allAyahAudioUrls(rec),total=urls.length,cache=('caches' in window)?await caches.open(AUDIO_CACHE):null;state.audioDownload={rec,done:0,total};state.audioDownloadAbort=false;navigator.storage?.persist?.().catch(()=>{});
  const prog=$('#offlineProgress'),bar=$('#offlineProgressBar'),txt=$('#offlineProgressText'),btn=$('#downloadAllAudio');if(prog)prog.hidden=false;if(btn){btn.disabled=true;btn.textContent=ui('downloading')+'…'};
  let cursor=0,done=0,failed=0;const meta=offlineAudioMeta();
  const update=()=>{state.audioDownload.done=done;const pc=Math.round(done/total*100);if(bar)bar.style.width=`${pc}%`;if(txt)txt.textContent=`${fmtNum(done)} / ${fmtNum(total)} · ${fmtNum(pc)}%${failed?` · ${fmtNum(failed)} ${ui('failed')}`:''}`};
  const worker=async()=>{while(cursor<total&&!state.audioDownloadAbort){const i=cursor++,url=urls[i];try{let stored=false;try{const res=await fetch(url,{cache:'no-store'});if(res.ok){const blob=await res.blob();await offlineDbPut(url,rec,blob);stored=true;}}catch{}if(!stored&&cache){const req=new Request(url,{mode:'no-cors'});const existing=await cache.match(req);if(!existing){const res=await fetch(req);await cache.put(req,res.clone());stored=true;}}if(!stored)throw new Error('Audio storage failed');}catch(e){failed++;}done++;if(done%10===0||done===total)update();}};
  try{await Promise.all(Array.from({length:4},worker));meta[rec]={count:done-failed,total,complete:done===total&&failed===0,ts:Date.now()};saveOfflineAudioMeta(meta);toast(meta[rec].complete?ui('offlineDownloadComplete'):ui('offlineDownloadIncomplete'));}
  finally{state.audioDownload=null;if(btn){btn.disabled=false;btn.textContent=ui('downloadAll')}refreshOfflineAudioStatus();}
}
async function deleteOfflineAudio(){if(!confirm(ui('deleteAudioConfirm')))return;try{if('caches' in window)await caches.delete(AUDIO_CACHE);await offlineDbClear();localStorage.removeItem('qh-offline-audio-meta');toast(ui('downloadedAudioDeleted'));refreshOfflineAudioStatus()}catch{toast(ui('deleteOfflineError'))}}

function audioUrl(){if(!state.currentVerseKey)return null;const [s,a]=state.currentVerseKey.split(':').map(Number);return `https://everyayah.com/data/${AUDIO[state.reciter].dir}/${String(s).padStart(3,'0')}${String(a).padStart(3,'0')}.mp3`}
async function toggleAudio(){if(!state.currentVerseKey)return toast(ui('selectAyahFirst'));if(!audioEl.paused){audioEl.pause();state.audioPlaying=false;render();return}state.repeatRemaining=state.repeat;await playAudioOnce()}
async function playAudioOnce(){const u=audioUrl();if(!u)return;audioEl.src=await resolvedAudioSource(u);try{await audioEl.play();state.audioPlaying=true;render()}catch{toast(ui('audioInternetError'))}}
audioEl.addEventListener('timeupdate',()=>{const p=$('#audioProgress');if(p&&audioEl.duration)p.style.width=`${audioEl.currentTime/audioEl.duration*100}%`});
audioEl.addEventListener('ended',()=>{state.repeatRemaining=Math.max(0,state.repeatRemaining-1);if(state.repeatRemaining>0)setTimeout(playAudioOnce,state.pause?3000:200);else if(state.autoNext){state.audioPlaying=false;nextAyah();setTimeout(()=>{state.repeatRemaining=state.repeat;playAudioOnce()},state.pause?3000:300)}else{state.audioPlaying=false;const b=$('#playAudio');if(b)b.innerHTML=icon('play')}});

function openEvaluation(preselect){
  if(!state.currentVerseKey)return toast(ui('selectAyahFirst'));
  const key=state.currentVerseKey,[s,a]=key.split(':').map(Number),preview=versePreview(key,7),note=state.notes[key]||'';let selected=preselect||state.ratings[key]||'';
  sheetRoot.innerHTML=`<div class="sheet-back" id="sheetBack"><div class="sheet eval-sheet"><div class="grab"></div><div class="sheet-title"><h3>${uit('howWellKnown',{surah:surahDisplayName(s),ref:fmtVerseKey(`${s}:${a}`)})}</h3><button class="icon-btn" id="closeSheet">${icon('close')}</button></div><div class="arabic">${escapeHtml(preview)}…</div><div class="eval-grid"><button class="eval-btn green ${selected==='green'?'selected':''}" data-sheet-eval="green">${faceSvg('#6bdab3','smile')}<b>${ui('knewWell')}</b><small>${ui('strongShort')}</small></button><button class="eval-btn yellow ${selected==='yellow'?'selected':''}" data-sheet-eval="yellow">${faceSvg('#f4ca5c','flat')}<b>${ui('hesitated')}</b><small>${ui('needsReview')}</small></button><button class="eval-btn red ${selected==='red'?'selected':''}" data-sheet-eval="red">${faceSvg('#f18080','sad')}<b>${ui('couldntRecall')}</b><small>${ui('weakShort')}</small></button></div><label class="field-label">${ui('applyTo')}</label><select class="select" id="applyScope"><option value="ayah">${ui('thisAyahOnly')}</option><option value="page">${ui('wholePage')}</option></select><label class="field-label">${ui('addNoteOptional')}</label><textarea id="noteInput" class="note-input" placeholder="${ui('noteExample')}">${escapeHtml(note)}</textarea><button class="primary full" id="saveEval">${ui('save')}</button></div></div>`;
  $('#closeSheet').onclick=closeSheet;$('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};
  document.querySelectorAll('[data-sheet-eval]').forEach(b=>b.onclick=()=>{selected=b.dataset.sheetEval;document.querySelectorAll('[data-sheet-eval]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
  $('#saveEval').onclick=()=>{if(!selected)return toast(ui('chooseRating'));const scope=$('#applyScope').value;if(scope==='ayah'){applyRating(key,selected,state.page,true);}else{const d=currentPageData();if(d){for(const k of wordsByVerse(d).keys())applyRating(k,selected,state.page,true);syncPageRating(state.page,d);}}const n=$('#noteInput').value.trim();if(n)state.notes[key]=n;else delete state.notes[key];saveAll();closeSheet();render();toast(ui('evaluationSaved'))};
}
function closeSheet(){sheetRoot.innerHTML='';document.body.classList.remove('quran-nav-open')}

function review(){const order=[['red',ui('reviseFirst')],['yellow',ui('needsReview')],['green',ui('strongShort')]];return `<div class="pad"><div class="page-title"><div><h2>${ui('revisionTitle')}</h2><p>${ui('basedSelfEvaluations')}</p></div><button class="primary" data-go="mushaf">${ui('start')}</button></div>${order.map(([r,l])=>{const rows=Object.entries(state.ratings).filter(([,v])=>v===r).slice(0,12);return rows.length?`<h3 class="mini-section">${l}</h3>${rows.map(([k])=>revisionRow(k,r)).join('')}`:''}).join('')||`<section class="card empty-card">${ui('emptyRevision')}</section>`}</div>`}
function revisionRow(k,r){return `<button class="list-card" data-verse-open="${k}"><span class="status-dot ${r==='green'?'g':r==='yellow'?'y':'r'}"></span><div class="grow"><b>${fmtVerseKey(k)}</b><small>${state.notes[k]||ui('openInMushaf')}</small></div>${state.notes[k]?icon('note'):''}<span>${isRtlUI()?'‹':'›'}</span></button>`}

function practice(){
  const sections=[[ui('coreRecall'),[['continue',ui('continueAyah'),ui('continueDesc'),'review'],['random',ui('randomAyah'),ui('randomDesc'),'sparkle'],['before',ui('whatBefore'),ui('beforeDesc'),isRtlUI()?'right':'left'],['after',ui('whatAfter'),ui('afterDesc'),isRtlUI()?'left':'right']]],[ui('hifzPractice'),[['page',ui('pageTest'),ui('pageTestDesc'),'book'],['surah',ui('surahTest'),ui('surahTestDesc'),'mushaf'],['muta',ui('mutashPractice'),ui('mutashDesc'),'target'],['visual',ui('visualMemory'),ui('visualDesc'),'eye']]],[ui('listening'),[['audio',ui('audioHifz'),ui('audioHifzDesc'),'headphones']]]];
  return `<div class="pad"><div class="page-title"><div><h2>${ui('practiceTitle')}</h2><p>${ui('practiceSubtitle')}</p></div></div>${sections.map(([name,items])=>`<h3 class="practice-section-title">${name}</h3><div class="practice-list">${items.map(([k,t,s,ic])=>`<button class="practice-item" data-practice="${k}"><span class="icon-tile">${icon(ic)}</span><span class="grow"><b>${t}</b><small>${s}</small></span><span>${isRtlUI()?'‹':'›'}</span></button>`).join('')}</div>`).join('')}</div>`;
}
function practiceAction(k){
  if(k==='muta'){state.tab='mutash';state.mutashEntry=null;state.mutashList=true;state.mutashPair=null;render();return;}
  if(k==='surah'){openSurahPracticePicker();return;}
  startPracticeTest(k);
}
function openSurahPracticePicker(){
  const surah=state.selectedSurah||18,max=SURAH_COUNTS[surah-1];
  sheetRoot.innerHTML=`<div class="sheet-back" id="sheetBack"><div class="sheet surah-test-picker"><div class="grab"></div><div class="sheet-title"><h3>${ui('surahTest')}</h3><button class="icon-btn" id="closeSheet">${icon('close')}</button></div><label class="field-label">${ui('surah')}</label><select class="select" id="practiceSurahSelect">${SURAH_NAMES.map((n,i)=>`<option value="${i+1}" ${i+1===surah?'selected':''}>${fmtNum(i+1)}. ${state.settings.uiLang==='ar'?SURAH_NAMES_AR[i]:n}</option>`).join('')}</select><div class="practice-range-grid"><div><label class="field-label">${ui('fromAyah')}</label><input class="select" id="practiceStartAyah" type="number" min="1" max="${max}" value="1"></div><div><label class="field-label">${ui('toAyah')}</label><input class="select" id="practiceEndAyah" type="number" min="1" max="${max}" value="${max}"></div></div><button class="primary full" id="startSurahPractice">${ui('startTest')}</button></div></div>`;
  const sel=$('#practiceSurahSelect'),start=$('#practiceStartAyah'),end=$('#practiceEndAyah');
  sel.onchange=()=>{const m=SURAH_COUNTS[Number(sel.value)-1];start.max=m;end.max=m;start.value=1;end.value=m};
  $('#closeSheet').onclick=closeSheet;$('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};
  $('#startSurahPractice').onclick=()=>{const ss=Number(sel.value),m=SURAH_COUNTS[ss-1],a1=Math.max(1,Math.min(m,Number(start.value)||1)),a2=Math.max(a1,Math.min(m,Number(end.value)||m));state.selectedSurah=ss;closeSheet();startPracticeTest('surah',{surah:ss,start:a1,end:a2})};
}

function randomUnseenVerseKey(){
  const ratedUnseen=Object.keys(state.ratings).filter(k=>!state.practiceSeen[k]);
  if(ratedUnseen.length)return ratedUnseen[Math.floor(Math.random()*ratedUnseen.length)];
  for(let i=0;i<300;i++){const s=1+Math.floor(Math.random()*114),a=1+Math.floor(Math.random()*SURAH_COUNTS[s-1]),k=`${s}:${a}`;if(!state.practiceSeen[k])return k;}
  for(let s=1;s<=114;s++)for(let a=1;a<=SURAH_COUNTS[s-1];a++){const k=`${s}:${a}`;if(!state.practiceSeen[k])return k;}
  return '1:1';
}
function markPracticeSeen(key){if(!key)return;state.practiceSeen[key]=Date.now();saveAll()}
function allPageNumbers(){return Array.from({length:604},(_,i)=>i+1)}
function randomPick(arr){return arr[Math.floor(Math.random()*arr.length)]}
async function pickPracticePage(exclude=[]){
  const unseen=allPageNumbers().filter(p=>!state.practiceSeen[`page:${p}`]&&!exclude.includes(p));
  if(unseen.length)return randomPick(unseen);
  const fallback=allPageNumbers().filter(p=>!exclude.includes(p));
  return randomPick(fallback.length?fallback:[293]);
}
async function pickPracticeBase(excludePages=[]){
  const ratedUnseen=Object.keys(state.ratings).filter(k=>!state.practiceSeen[k]);
  const grouped=new Map();
  for(const key of ratedUnseen){
    const p=Number(state.ratingPages[key])||await locateVersePage(key)||0;
    if(!p||excludePages.includes(p))continue;
    if(!grouped.has(p))grouped.set(p,[]);
    grouped.get(p).push(key);
  }
  const pages=[...grouped.keys()];
  if(pages.length){const p=randomPick(pages);const k=randomPick(grouped.get(p));return {page:p,key:k,data:null,keys:null};}
  const page=await pickPracticePage(excludePages);const data=await fetchPage(page),keys=[...wordsByVerse(data).keys()];
  const unseenPool=keys.filter(k=>!state.practiceSeen[k]);
  const unseenKey=randomPick(unseenPool.length?unseenPool:keys)||'1:1';
  return {page,key:unseenKey,data,keys};
}

async function startPracticeTest(mode,opts={}){
  try{
    let page=null,data=null,keys=[],cueKey=null,answerKey=null;
    const recent=state.practiceSession?.recentPages||[];const excludePages=[state.practiceSession?.page,...recent,state.page].filter(Boolean).slice(-10);
    if(mode==='page'){
      page=await pickPracticePage(excludePages);
      data=await fetchPage(page);keys=[...wordsByVerse(data).keys()];state.practiceSeen[`page:${page}`]=Date.now();saveAll();
    }else if(mode==='surah'){
      const surah=opts.surah||state.selectedSurah||18,startA=opts.start||1,endA=opts.end||SURAH_COUNTS[surah-1];
      const candidates=[];for(let a=startA;a<=endA;a++){const k=`${surah}:${a}`;if(!state.practiceSeen[k])candidates.push(k)}
      const pool=candidates.length?candidates:Array.from({length:endA-startA+1},(_,i)=>`${surah}:${startA+i}`);
      let chosen=null,chosenPage=null;for(let tries=0;tries<Math.min(18,pool.length);tries++){const k=randomPick(pool);const pp=await locateVersePage(k);if(!excludePages.includes(pp)){chosen=k;chosenPage=pp;break}}
      answerKey=chosen||randomPick(pool)||`${surah}:${startA}`;cueKey=answerKey;page=chosenPage||await locateVersePage(answerKey);if(!page)page=293;data=await fetchPage(page);keys=[...wordsByVerse(data).keys()];markPracticeSeen(answerKey);
    }else{
      const picked=await pickPracticeBase(excludePages);
      page=picked.page;data=picked.data||await fetchPage(page);keys=picked.keys||[...wordsByVerse(data).keys()];
      const baseKey=picked.key||keys[0];
      cueKey=baseKey;answerKey=cueKey;
      if(mode==='before'){
        const abs=keyToAbsolute(cueKey);answerKey=absoluteToKey(Math.max(0,abs-1));const p=await locateVersePage(answerKey);if(p){page=p;data=await fetchPage(page);keys=[...wordsByVerse(data).keys()]}
      }else if(mode==='after'){
        const abs=keyToAbsolute(cueKey);answerKey=absoluteToKey(Math.min(6235,abs+1));const p=await locateVersePage(answerKey);if(p){page=p;data=await fetchPage(page);keys=[...wordsByVerse(data).keys()]}
      }else if(mode==='visual'){
        answerKey=baseKey;cueKey=baseKey;
      }
      markPracticeSeen(answerKey||cueKey);
    }
    if(!page){page=293;data=await fetchPage(page);keys=[...wordsByVerse(data).keys()];cueKey=keys[0];answerKey=mode==='page'?null:cueKey;}
    const recentPages=[...(state.practiceSession?.recentPages||[]),state.practiceSession?.page].filter(Boolean).slice(-8);state.practiceSession={mode,page,cueKey,answerKey,revealed:false,opts,pickedKey:null,recentPages};state.tab='practiceTest';render();
  }catch(e){console.warn(e);toast(ui('practiceStartError'));}
}

async function locateVersePage(key){try{const r=await fetch(`${QURAN_API}/verses/by_key/${key}?fields=page_number`),j=await r.json();return Number(j?.verse?.page_number)||null}catch{return null}}




function openMutashabihatPractice(){state.tab='mutash';state.mutashEntry=null;state.mutashList=true;state.mutashPair=null;state.mutashGroupKey=null;render()}
function canonicalMutashPairKey(pair){
  const left=(pair.srcKeys||[pair.srcKey]).slice().sort().join('+');
  const right=(pair.dstKeys||[pair.dstKey]).slice().sort().join('+');
  return [left,right].sort().join('||');
}
function cachedMutashPairs(){
  try{const raw=JSON.parse(localStorage.getItem('qh-mutash-pairs-v3')||'[]');return Array.isArray(raw)?raw:[]}catch{return []}
}
function saveMutashPairsCache(pairs){
  try{localStorage.setItem('qh-mutash-pairs-v3',JSON.stringify(pairs.map(p=>({srcKeys:p.srcKeys,dstKeys:p.dstKeys,srcKey:p.srcKey,dstKey:p.dstKey,title:p.title||'',textA:p.textA||'',textB:p.textB||''}))))}catch{}
}
async function loadPreparedMutashPairs(){
  if(Array.isArray(mutashCache)&&mutashCache.length&&mutashCache[0]?.title)return mutashCache;
  const cached=cachedMutashPairs();
  if(cached.length){mutashCache=cached;return cached;}
  const data=await loadMutashData();
  const rawPairs=mutashPairsFromData(data);
  const pairs=[];
  for(const p of rawPairs){
    const texts=await mutashPairTexts(p);
    const title=await mutashPairTitle({...p,...texts});
    pairs.push({...p,title,textA:texts.a,textB:texts.b});
  }
  pairs.sort((a,b)=>normalizePhraseKey(a.title).localeCompare(normalizePhraseKey(b.title),'ar')||a.title.localeCompare(b.title,'ar')||a.srcKey.localeCompare(b.srcKey,'ar'));
  saveMutashPairsCache(pairs);
  mutashCache=pairs;
  return pairs;
}

function phraseTokens(s=''){return normalizePhraseKey(s).split(/\s+/).filter(Boolean)}
function phraseJaccard(a='',b=''){
  const A=new Set(phraseTokens(a)),B=new Set(phraseTokens(b));
  if(!A.size||!B.size)return 0;
  const inter=[...A].filter(x=>B.has(x)).length,union=new Set([...A,...B]).size;
  return union?inter/union:0;
}
function groupedMutashPairs(pairs){
  const raw=[];
  for(const p of pairs){
    const norm=normalizePhraseKey(p.title||'')||p.title||mutashPairKey(p);
    let group=raw.find(g=>g.norm===norm||g.norm.includes(norm)||norm.includes(g.norm)||phraseJaccard(g.norm,norm)>=0.72);
    if(!group){group={norm,key:norm,title:p.title||ui('similarPassageFallback'),pairs:[]};raw.push(group);}
    if((phraseTokens(p.title||'').length>phraseTokens(group.title||'').length)&& (group.norm.includes(norm)||norm.includes(group.norm)||phraseJaccard(group.norm,norm)>=0.72)) group.title=p.title||group.title;
    group.pairs.push(p);
  }
  const groups=raw.map(g=>{
    const uniq=new Map();
    g.pairs.forEach(p=>{[...(p.srcKeys||[p.srcKey]),...(p.dstKeys||[p.dstKey])].forEach(k=>{if(k&&!uniq.has(k)) uniq.set(k,k);});});
    return {...g, refs:[...uniq.values()]};
  });
  groups.sort((a,b)=>normalizePhraseKey(a.title).localeCompare(normalizePhraseKey(b.title),'ar')||a.title.localeCompare(b.title,'ar'));
  return groups;
}
function mutashGroupDone(group){return (group?.pairs||[]).length?group.pairs.every(mutashPairDone):false}
function setMutashGroupDone(group,val){(group?.pairs||[]).forEach(p=>setMutashPairDone(p,val));}
function mutashGroupMeta(group){return (group.refs||[]).map(k=>`${surahDisplayName(Number(k.split(':')[0]))} ${fmtVerseKey(k)}`).join(' · ')}

function anchorAbsoluteList(anchor){const a=anchor?.ayah;return Array.isArray(a)?a:[a]}
function anchorKeys(anchor){return anchorAbsoluteList(anchor).map(absoluteToKey).filter(Boolean)}
function cleanArabicPhrase(s=''){return String(s).replace(/[ً-ٰٟۖ-ۭ]/g,'').replace(/[ـ]/g,'').replace(/\s+/g,' ').trim()}
function normalizePhraseKey(s=''){return cleanArabicPhrase(s).replace(/[^ء-ي\s]/g,'').trim()}
function betterPhraseFallback(a='',b=''){const aw=cleanArabicPhrase(a).split(/\s+/).filter(Boolean),bw=cleanArabicPhrase(b).split(/\s+/).filter(Boolean);const common=[];for(const w of aw){if(bw.includes(w)&&!common.includes(w))common.push(w)}return common.slice(0,6).join(' ')}
function mutashPairKey(pair){return `${pair.srcKey}|${pair.dstKey}`}
function mutashPairDone(pair){return !!state.mutashSeen[mutashPairKey(pair)]}
function setMutashPairDone(pair,val){if(val)state.mutashSeen[mutashPairKey(pair)]=true;else delete state.mutashSeen[mutashPairKey(pair)];saveAll()}
function mutashPairsFromData(data){
  const pairs=[],seen=new Set();
  for(const entry of flattenMutash(data)){
    const srcKeys=anchorKeys(entry.src);
    for(const mut of (entry.muts||[])){
      const dstKeys=anchorKeys(mut);
      if(!srcKeys.length||!dstKeys.length)continue;
      const pair={entry,mut,srcKeys,dstKeys,srcKey:srcKeys[0],dstKey:dstKeys[0]};
      const canon=canonicalMutashPairKey(pair);
      if(seen.has(canon))continue;
      seen.add(canon);
      pairs.push(pair);
    }
  }
  return pairs;
}
async function mutashPairTexts(pair){
  if(pair?.textA&&pair?.textB)return {a:pair.textA,b:pair.textB};
  const a=(await Promise.all(pair.srcKeys.map(fetchVerseText))).filter(Boolean).join('  ۞  '),b=(await Promise.all(pair.dstKeys.map(fetchVerseText))).filter(Boolean).join('  ۞  ');return {a,b};
}
async function mutashPairTitle(pair){
  const a=pair?.textA||pair?.a,b=pair?.textB||pair?.b;
  const texts=(a&&b)?{a,b}:await mutashPairTexts(pair),diff=texts.a&&texts.b?lcsDiff(texts.a,texts.b):null;let title=diff?commonPhraseFromDiff(diff.a):'';title=cleanArabicPhrase(title);if(!title||title.length<4||title.split(/\s+/).length<2)title=betterPhraseFallback(texts.a,texts.b);if(!title||title.length<2)title=`${fmtVerseKey(pair.srcKey)} ↔ ${fmtVerseKey(pair.dstKey)}`;return title;
}
function rememberMutashListPosition(){const list=document.querySelector('.mut-pair-list');state.mutashScroll=list?.scrollTop||0;saveAll()}
function restoreMutashListPosition(){const list=document.querySelector('.mut-pair-list');if(list){requestAnimationFrame(()=>{list.scrollTop=state.mutashScroll||0;const active=list.querySelector(`[data-mut-pair-index="${state.mutashIndex||0}"]`);active?.scrollIntoView({block:'nearest'});});}}
async function renderMutashPairDetail(group,groups){
  state.mutashPair=group?.pairs?.[0]||null;state.mutashList=false;state.mutashGroupKey=group?.key||null;state.mutashIndex=Math.max(0,groups.findIndex(g=>g.key===group.key));saveAll();
  const body=$('#mutashPageBody');if(!body||!group)return;
  const idx=state.mutashIndex||0,prevGroup=groups[idx-1],nextGroup=groups[idx+1],done=mutashGroupDone(group),title=group.title||ui('similarPassageFallback');
  const cards=[];
  for(const pair of group.pairs){
    const {a,b}=await mutashPairTexts(pair),diff=a&&b?lcsDiff(a,b):null;
    const sourceLabel=pair.srcKeys.map(k=>`${surahDisplayName(Number(k.split(':')[0]))} ${fmtVerseKey(k)}`).join(' + '),targetLabel=pair.dstKeys.map(k=>`${surahDisplayName(Number(k.split(':')[0]))} ${fmtVerseKey(k)}`).join(' + ');
    cards.push(`<section class="card mut-source full"><small>${ui('sourcePassage')}</small><b>${sourceLabel}</b><div class="mut-arabic">${diff?markedArabic(diff.a):escapeHtml(a)}</div><button class="mut-open-ref" data-mut-open="${pair.srcKey}">${ui('openReference')}</button></section><section class="mut-match card"><small>${ui('similarPassage')}</small><b>${targetLabel}</b><div class="mut-arabic">${diff?markedArabic(diff.b):escapeHtml(b)}</div><button class="mut-open-ref" data-mut-open="${pair.dstKey}">${ui('openReference')}</button></section>`);
  }
  body.innerHTML=`<div class="mut-detail-head"><button class="secondary mut-back-list" id="mutBackList">${backIcon()} ${ui('allPairs')}</button><div><small>${ui('similarPhrase')}</small><b class="mut-detail-name">${escapeHtml(title)}</b></div><button class="secondary mut-done-toggle ${done?'done':''}" id="mutDoneToggle" aria-label="${done?ui('done'):ui('markDone')}"><span>${done?'✓':'○'}</span></button></div>${cards.join('')}<div class="mut-actions full mut-nav-actions"><button class="secondary ${prevGroup?'':'disabled'}" id="mutPrev" ${prevGroup?'':'disabled'}>${ui('previous')}</button><button class="secondary ${nextGroup?'':'disabled'}" id="mutNext" ${nextGroup?'':'disabled'}>${ui('next')}</button></div>`;
  $('#mutBackList').onclick=()=>{state.mutashList=true;state.mutashPair=null;render()};
  $('#mutDoneToggle').onclick=()=>{const val=!mutashGroupDone(group);setMutashGroupDone(group,val);renderMutashPairDetail(group,groups)};
  const prev=$('#mutPrev');if(prev&&prevGroup)prev.onclick=()=>renderMutashPairDetail(prevGroup,groups);
  const next=$('#mutNext');if(next&&nextGroup)next.onclick=()=>renderMutashPairDetail(nextGroup,groups);
  document.querySelectorAll('[data-mut-open]').forEach(b=>b.onclick=()=>openVerseByKey(b.dataset.mutOpen,{fromMutash:true}));
}
function mutashPage(){return `<div class="pad mutash-page"><div class="page-title mutash-page-title"><button class="icon-btn" data-go="practice">${backIcon()}</button><div><h2>${ui('mutashTitle')}</h2><p>${state.mutashList?ui('chooseSimilarPair'):ui('compareSharedWording')}</p></div></div><div id="mutashPageBody"><div class="page-loading">${ui('loadingMutash')}</div></div></div>`}
async function hydrateMutashPage(){
  const body=$('#mutashPageBody');if(!body)return;
  const pairs=await loadPreparedMutashPairs(),groups=groupedMutashPairs(pairs);
  if(!state.mutashList&&(state.mutashGroupKey||state.mutashPair)){
    const chosen=groups.find(g=>g.key===state.mutashGroupKey)||groups.find(g=>g.pairs.some(p=>state.mutashPair&&mutashPairKey(p)===mutashPairKey(state.mutashPair)))||groups[state.mutashIndex||0]||groups[0];
    if(chosen)await renderMutashPairDetail(chosen,groups);return;
  }
  body.innerHTML=`<section class="mut-list-intro"><b>${ui('similarPairs')}</b><small>${uit('verifiedPairings',{count:fmtNum(groups.length)})}</small></section><div class="mut-pair-list">${groups.map((g,i)=>{const seen=mutashGroupDone(g);return `<button class="mut-pair-row ${seen?'seen':''}" data-mut-pair-index="${i}"><span class="mut-pair-check">${seen?'✓':'○'}</span><span class="mut-pair-copy"><b class="mut-pair-name">${escapeHtml(g.title||ui('similarPassageFallback'))}</b><small>${mutashGroupMeta(g)}</small></span><span class="chev">${isRtlUI()?'‹':'›'}</span></button>`}).join('')}</div>`;
  document.querySelectorAll('[data-mut-pair-index]').forEach(el=>el.onclick=()=>{rememberMutashListPosition();state.mutashIndex=Number(el.dataset.mutPairIndex)||0;state.mutashGroupKey=groups[state.mutashIndex]?.key||null;renderMutashPairDetail(groups[state.mutashIndex],groups)});
  restoreMutashListPosition();
}

function practiceTestScreen(){
  const t=state.practiceSession;if(!t)return `<div class="pad"><div class="empty-card">${ui('noPracticeSession')}</div></div>`;
  const labels={continue:ui('continueAyah'),random:ui('randomAyah'),before:ui('whatBefore'),after:ui('whatAfter'),page:ui('pageTest'),surah:ui('surahTest'),visual:ui('visualMemory'),audio:ui('audioHifz')};
  const prompt={continue:ui('promptContinue'),random:ui('promptRandom'),before:ui('promptBefore'),after:ui('promptAfter'),page:'',surah:ui('promptSurah'),visual:ui('promptVisual'),audio:ui('promptAudio')}[t.mode]||ui('practiceFromMemory');
  const subline=t.mode==='page'?`${ui('juz')} ${fmtNum(pageJuz(t.page))}`:uit('testPageReading',{testPage:fmtNum(t.page),page:fmtNum(state.page)});
  return `<div class="pad practice-test-page"><div class="page-title practice-test-title"><button class="icon-btn" id="practiceBack">${backIcon()}</button><div><h2>${labels[t.mode]||ui('practiceTitle')}</h2><p>${subline}</p></div></div><section class="card test-prompt">${prompt?`<b>${prompt}</b>`:''}<div id="practiceCue" class="test-cue">${ui('loadingCue')}</div></section><div class="practice-mushaf-card"><div id="practiceTestPage" class="practice-real-page"><div class="page-loading">${ui('loadingRandomPage')}</div></div></div>${t.revealed?`<section class="card practice-answer" id="practiceAnswer"><div class="small-muted">${ui('loadingAnswer')}</div></section>`:'<section id="practiceAnswer"></section>'}${(t.answerKey||t.mode==='page')?`<section class="card practice-self-rate"><b>${ui('howRecall')}</b><div class="practice-rate-grid"><button data-practice-rate="green" class="green">${ui('strongShort')}</button><button data-practice-rate="yellow" class="yellow">${ui('reviewShort')}</button><button data-practice-rate="red" class="red">${ui('weakShort')}</button></div></section>`:''}<div class="practice-test-actions">${t.mode==='audio'?`<button class="secondary" id="practiceAudio">${icon('audio')} ${ui('playAyah')}</button>`:''}<button class="secondary" id="revealPractice">${t.revealed?ui('hideAnswer'):ui('revealAnswer')}</button><button class="primary" id="nextPractice">${ui('anotherTest')}</button></div></div>`;
}

async function hydratePracticeTest(){
  const t=state.practiceSession;if(!t)return;const data=await fetchPage(t.page),host=$('#practiceTestPage');if(!host)return;
  host.innerHTML=`<div class="page-image-wrap practice-page-image"><img class="page-image" src="${PAGE_IMAGE(t.page)}" alt="${ui('page')} ${fmtNum(t.page)}"><div class="practice-region-layer"></div></div>`;
  if(!t.revealed){
    if(t.mode==='page')await hydratePracticePageCue(host,t.page,data);
    else if(t.mode==='visual')await hydrateVisualMemoryBands(host,t.page,data,t.answerKey);
    else if((t.mode==='before'||t.mode==='after')){const layer=host.querySelector('.practice-region-layer');if(layer)layer.innerHTML='<span class="practice-page-cover"></span>';}
    else if(t.answerKey)await hydratePracticeAyaBlur(host,t.page,data,t.answerKey);
  }else if((t.mode==='before'||t.mode==='after'||t.mode==='visual')&&t.answerKey){await hydratePracticeAnswerHighlight(host,t.page,data,t.answerKey,false);}
  const cue=$('#practiceCue');
  if(cue){
    if(t.mode==='before'||t.mode==='after'){const txt=await fetchVerseText(t.cueKey);cue.innerHTML=`<span class="arabic-cue">${escapeHtml(txt)}</span><small>${ui('cue')}: ${fmtVerseKey(t.cueKey)}</small>`}
    else if(t.mode==='continue'){const txt=await fetchVerseText(t.answerKey),opening=txt.split(/\s+/).slice(0,4).join(' ');cue.innerHTML=`<span class="arabic-cue">${escapeHtml(opening)} …</span><small>${ui('continueNoReveal')}</small>`}
    else if(t.mode==='surah'){const [ss,aa]=t.answerKey.split(':').map(Number);cue.innerHTML=`<b>${surahDisplayName(ss)} · ${ui('ayahLabel')} ${fmtNum(aa)}</b><small>${ui('reciteBeforeReveal')}</small>`}
    else if(t.mode==='audio')cue.innerHTML=`<span>${ui('pressPlay')}</span>`;
    else if(t.mode==='visual'){const txt=await fetchVerseText(t.answerKey);cue.innerHTML=`<b>${ui('findAyah')}</b><span class="arabic-cue">${escapeHtml(txt)}</span><small>${uit('choosePageThird',{page:fmtNum(t.page)})}</small>`;}
    else if(t.mode==='page'){const firstKey=[...wordsByVerse(data).keys()][0],firstWords=getVerseWords(data,firstKey).slice(0,3).map(w=>w.word).join(' '),surahName=surahDisplayName(Number(firstKey.split(':')[0]));cue.innerHTML=`<b>${ui('page')} ${fmtNum(t.page)} · ${ui('juz')} ${fmtNum(pageJuz(t.page))}</b><small>${surahName}</small><span class="arabic-cue">${escapeHtml(firstWords)} …</span>`;}
    else cue.innerHTML=`<span>${ui('blurredTarget')}</span>`;
  }
  const ans=$('#practiceAnswer');if(ans&&t.revealed){const txt=t.answerKey?await fetchVerseText(t.answerKey):'';ans.innerHTML=t.answerKey?`<b>${fmtVerseKey(t.answerKey)}</b><div class="practice-answer-ar">${escapeHtml(txt)}</div>`:`<b>${ui('page')} ${fmtNum(t.page)}</b><div class="small-muted">${ui('compareRevealed')}</div>`;}
}

async function hydratePracticeAyaBlur(host,page,data,key){const map=await loadAyaLocator(),markers=map?.get(page);if(!markers?.length)return;const rects=locatorRectsForPage(markers,data).filter(r=>r.key===key),C=QURANHUB_LOCATOR_SOURCE,layer=host.querySelector('.practice-region-layer');if(layer)layer.innerHTML=rects.map(r=>`<span class="practice-blur" style="left:${r.left/C.width*100}%;top:${r.top/C.height*100}%;width:${(r.right-r.left)/C.width*100}%;height:${r.height/C.height*100}%"></span>`).join('')}

async function preparePracticeLocator(host,page,data){
  const wrap=host.querySelector('.page-image-wrap'),layer=host.querySelector('.practice-region-layer');
  if(!wrap||!layer)return null;
  const map=await loadAyaLocator(),markers=map?.get(page);if(!markers?.length)return null;
  const rects=locatorRectsForPage(markers,data);wrap._locatorRects=rects;wrap._locatorPageData=data;
  return {wrap,layer,rects};
}
function practiceRevealPiecesHtml(wrap,page,key,count=3){
  const data=wrap?wrap._locatorPageData:null,words=data?getVerseWords(data,key).slice(0,count):[];
  const boxes=locatorWordBoxesForVerse(wrap,key);
  const wr=wrap.getBoundingClientRect();
  return words.map(w=>{
    const box=boxes.get(w.location);if(!box)return '';
    const x=Math.max(0,box.left/QURANHUB_LOCATOR_SOURCE.width*wr.width),y=Math.max(0,box.top/QURANHUB_LOCATOR_SOURCE.height*wr.height);
    const ww=Math.min(wr.width-x,Math.max(7,(box.right-box.left)/QURANHUB_LOCATOR_SOURCE.width*wr.width));
    const hh=Math.min(wr.height-y,Math.max(8,box.height/QURANHUB_LOCATOR_SOURCE.height*wr.height));
    return `<span class="practice-reveal-piece" style="left:${x.toFixed(2)}px;top:${y.toFixed(2)}px;width:${ww.toFixed(2)}px;height:${hh.toFixed(2)}px;background-image:url('${PAGE_IMAGE(page)}');background-size:${wr.width.toFixed(2)}px ${wr.height.toFixed(2)}px;background-position:-${x.toFixed(2)}px -${y.toFixed(2)}px"></span>`;
  }).join('');
}
async function hydratePracticePageCue(host,page,data){
  const prepared=await preparePracticeLocator(host,page,data);if(!prepared)return;
  const {wrap,layer}=prepared;const firstKey=[...wordsByVerse(data).keys()][0];
  layer.innerHTML=`<span class="practice-page-cover"></span>${practiceRevealPiecesHtml(wrap,page,firstKey,3)}`;
}
async function hydratePracticeAnswerHighlight(host,page,data,key,clickable=false){
  const prepared=await preparePracticeLocator(host,page,data);if(!prepared)return;
  const {layer,rects}=prepared;
  if(!clickable){
    const highs=rects.filter(r=>r.key===key).map(r=>`<span class="practice-answer-highlight" style="left:${r.left/QURANHUB_LOCATOR_SOURCE.width*100}%;top:${r.top/QURANHUB_LOCATOR_SOURCE.height*100}%;width:${(r.right-r.left)/QURANHUB_LOCATOR_SOURCE.width*100}%;height:${r.height/QURANHUB_LOCATOR_SOURCE.height*100}%"></span>`).join('');
    layer.insertAdjacentHTML('beforeend',highs);
  }
  if(clickable){
    layer.style.pointerEvents='auto';
    layer.insertAdjacentHTML('beforeend',rects.map(r=>`<button class="practice-hit" data-practice-hit="${r.key}" style="left:${r.left/QURANHUB_LOCATOR_SOURCE.width*100}%;top:${r.top/QURANHUB_LOCATOR_SOURCE.height*100}%;width:${(r.right-r.left)/QURANHUB_LOCATOR_SOURCE.width*100}%;height:${r.height/QURANHUB_LOCATOR_SOURCE.height*100}%"></button>`).join(''));
    layer.querySelectorAll('[data-practice-hit]').forEach(btn=>btn.onclick=()=>{const choice=btn.dataset.practiceHit;state.practiceSession.pickedKey=choice;if(choice===state.practiceSession.answerKey){state.practiceSession.revealed=true;toast(ui('correctLocation'));render()}else toast(ui('tryAnotherPosition'));});
  }
}
function visualMemoryBandForKey(rects,key){
  const matches=rects.filter(r=>r.key===key);if(!matches.length)return 1;
  const C=QURANHUB_LOCATOR_SOURCE,mid=matches.reduce((a,r)=>a+r.top+r.height/2,0)/matches.length,ratio=mid/C.height;
  return ratio<1/3?0:ratio<2/3?1:2;
}
function showVisualChoiceFeedback(layer,correct){
  const fb=document.createElement('div');fb.className=`visual-choice-feedback ${correct?'ok':'bad'}`;fb.innerHTML=correct?'✓':'×';layer.appendChild(fb);
  requestAnimationFrame(()=>fb.classList.add('show'));
  setTimeout(()=>{fb.classList.remove('show');setTimeout(()=>fb.remove(),180)},520);
}
async function hydrateVisualMemoryBands(host,page,data,key){
  const prepared=await preparePracticeLocator(host,page,data);if(!prepared)return;
  const {layer,rects}=prepared,target=visualMemoryBandForKey(rects,key);
  layer.style.pointerEvents='auto';
  layer.innerHTML=`<span class="practice-page-cover visual-cover"></span>${[0,1,2].map(i=>`<button class="visual-band" data-visual-band="${i}" style="top:${i*33.3333}%;height:33.3334%"><span>${i+1}</span></button>`).join('')}`;
  layer.querySelectorAll('[data-visual-band]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();const picked=Number(btn.dataset.visualBand),correct=picked===target;btn.classList.add(correct?'correct':'wrong');showVisualChoiceFeedback(layer,correct);if(correct){state.practiceSession.pickedKey=key;setTimeout(()=>{state.practiceSession.revealed=true;render()},650)}else setTimeout(()=>btn.classList.remove('wrong'),650)});
}

async function playPracticeAudio(){const t=state.practiceSession,key=t?.answerKey||t?.cueKey;if(!key)return;const [ss,aa]=key.split(':').map(Number),u=`https://everyayah.com/data/${AUDIO[state.reciter].dir}/${String(ss).padStart(3,'0')}${String(aa).padStart(3,'0')}.mp3`;audioEl.src=await resolvedAudioSource(u);try{await audioEl.play()}catch{toast(ui('audioStartError'))}}


function progress(){
  const legend=`<div class="legend top-legend"><span><i class="lg g"></i>${ui('memorized')}</span><span><i class="lg y"></i>${ui('reviewSoon')}</span><span><i class="lg r"></i>${ui('weakShort')}</span><span><i class="lg n"></i>${ui('notEvaluated')}</span></div>`;
  let body='';
  if(state.progressTab==='mushaf'){let cells='';for(let p=1;p<=604;p++){const r=computedPageStatus(p);cells+=`<button class="heat-dot ${r==='green'?'g':r==='yellow'?'y':r==='red'?'r':''} ${p===state.page?'current':''}" data-page="${p}" aria-label="${ui('page')} ${fmtNum(p)}"></button>`}body=`<section class="card heat-card">${legend}<div class="heatmap">${cells}</div></section><section class="card page-info"><div class="detail-tabs"><button class="${state.progressDetailTab==='ayahs'?'active':''}" data-detail="ayahs">${ui('ayahs')}</button><button class="${state.progressDetailTab==='notes'?'active':''}" data-detail="notes">${ui('notes')}</button></div><h3>${ui('page')} ${fmtNum(state.page)}</h3><p id="pageInfoMeta">${ui('loadingPageDetails')}</p><div id="pageInfoAyahs" class="ayah-list"><div class="small-muted">${ui('loading')}</div></div></section>`}
  if(state.progressTab==='juz'){const start=JUZ_START_PAGES[state.selectedJuz-1],end=(JUZ_START_PAGES[state.selectedJuz]||605)-1,rows=[];for(let p=start;p<=end;p++)rows.push(`<div class="juz-row"><button class="juz-page-no ${computedPageStatus(p)==='green'?'g':computedPageStatus(p)==='yellow'?'y':computedPageStatus(p)==='red'?'r':''}" data-page="${p}">${fmtNum(p)}</button><div class="juz-boxes" id="juzPage-${p}"><span class="small-muted">${ui('loading')}</span></div></div>`);body=`<section class="card heat-card">${legend}<button class="picker-btn" id="juzPicker">${ui('juz')} ${fmtNum(state.selectedJuz)}<span>⌄</span></button><div class="juz-view">${rows.join('')}</div></section>`}
  if(state.progressTab==='surah'){body=`<section class="card heat-card">${legend}<button class="picker-btn" id="surahPicker">${fmtNum(state.selectedSurah)}. ${surahDisplayName(state.selectedSurah)}<span>⌄</span></button><div class="surah-card"><div class="surah-meta">${uit('tapNumberOpen',{count:fmtNum(SURAH_COUNTS[state.selectedSurah-1])})}</div><div class="ayah-chips">${Array.from({length:SURAH_COUNTS[state.selectedSurah-1]},(_,i)=>{const k=`${state.selectedSurah}:${i+1}`,r=state.ratings[k]||'';return `<button class="ayah-chip ${r==='green'?'g':r==='yellow'?'y':r==='red'?'r':''}" data-status="${r||'none'}" data-surah-ayah="${k}">${fmtNum(i+1)}</button>`}).join('')}</div></div></section>`}
  return `<div class="pad"><div class="page-title"><div><h2>${ui('hifzProgress')}</h2><p>${ui('yourMushafMap')}</p></div></div><div class="subseg"><button class="${state.progressTab==='surah'?'active':''}" data-ptab="surah">${ui('surah')}</button><button class="${state.progressTab==='juz'?'active':''}" data-ptab="juz">${ui('juz')}</button><button class="${state.progressTab==='mushaf'?'active':''}" data-ptab="mushaf">${ui('mushaf')}</button></div>${body}${analyticsDashboard()}</div>`;
}
function analyticsDashboard(){
  const events=filteredHistory(),counts={green:0,yellow:0,red:0};events.forEach(e=>counts[e.rating]=(counts[e.rating]||0)+1);const current=Object.values(state.ratings),g=current.filter(x=>x==='green').length,y=current.filter(x=>x==='yellow').length,r=current.filter(x=>x==='red').length,total=g+y+r,strength=total?Math.round((g+y*.55+r*.15)/total*100):0,ranking=weakestSurahs();
  const ranges=['day','month','year','all'];
  return `<section class="card analytics"><div class="analytics-head"><b>${ui('analytics')}</b><div class="range-tabs">${ranges.map(x=>`<button class="${state.analyticsRange===x?'active':''}" data-range="${x}">${ui(x)}</button>`).join('')}</div></div><div class="analytics-overview"><div class="strength-donut" style="--strength:${strength}"><b>${fmtNum(strength)}%</b></div><div class="analytics-legend"><div><i class="lg g"></i>${ui('strongShort')}<strong>${fmtNum(g)}</strong></div><div><i class="lg y"></i>${ui('reviewShort')}<strong>${fmtNum(y)}</strong></div><div><i class="lg r"></i>${ui('weakShort')}<strong>${fmtNum(r)}</strong></div><div><i class="lg n"></i>${ui('sessions')}<strong>${fmtNum(events.length)}</strong></div></div></div><div class="stats-strip"><div><b>${fmtNum(counts.green)}</b><small>${ui('strongMarks')}</small></div><div><b>${fmtNum(counts.yellow)}</b><small>${ui('reviewMarks')}</small></div><div><b>${fmtNum(counts.red)}</b><small>${ui('weakMarks')}</small></div></div><div class="ranking"><h4>${ui('weakestSurahs')}</h4>${ranking.length?ranking.map((x,i)=>`<div class="rank-row"><span class="rank-no">${fmtNum(i+1)}</span><span class="rank-name">${surahDisplayName(x.surah)}</span><span class="rank-bar"><span style="width:${x.score}%"></span></span><span class="rank-pct">${fmtNum(x.score)}%</span></div>`).join(''):`<div class="small-muted">${ui('evaluateMore')}</div>`}</div></section>`;
}
function filteredHistory(){const vals=Object.values(state.ratingHistory);if(state.analyticsRange==='all')return vals;const now=Date.now(),ms=state.analyticsRange==='day'?864e5:state.analyticsRange==='month'?30*864e5:365*864e5;return vals.filter(e=>now-e.ts<=ms)}
function weakestSurahs(){const m=new Map();for(const [k,r] of Object.entries(state.ratings)){const s=Number(k.split(':')[0]);if(!m.has(s))m.set(s,[]);m.get(s).push(r)}return [...m].map(([s,rs])=>{const v=rs.reduce((a,r)=>a+(r==='green'?100:r==='yellow'?55:15),0)/rs.length;return {surah:s,name:SURAH_NAMES[s-1],score:Math.round(v)}}).sort((a,b)=>a.score-b.score).slice(0,3)}

async function hydrateProgress(){
  const migrated=await migrateRatingPages();if(migrated){render();return;}
  if(state.progressTab==='surah'||state.progressTab==='juz'){
    if(state.progressTab==='juz'){const start=JUZ_START_PAGES[state.selectedJuz-1],end=(JUZ_START_PAGES[state.selectedJuz]||605)-1;for(let p=start;p<=end;p++){try{const d=await fetchPage(p);syncPageRating(p,d);const pageBtn=document.querySelector(`.juz-page-no[data-page="${p}"]`);if(pageBtn){const pr=computedPageStatus(p);pageBtn.classList.toggle('g',pr==='green');pageBtn.classList.toggle('y',pr==='yellow');pageBtn.classList.toggle('r',pr==='red')}const box=$(`#juzPage-${p}`);if(box)box.innerHTML=[...wordsByVerse(d).keys()].map(k=>{const r=state.ratings[k]||'';return `<button class="juz-box ${r==='green'?'g':r==='yellow'?'y':r==='red'?'r':''}" data-status="${r||'none'}" data-verse-open="${k}" data-vpage="${p}">${fmtNum(k.split(':')[1])}</button>`}).join('')}catch{}}bindDynamicVerseOpen()}return;
  }
  const d=await fetchPage(state.page),groups=wordsByVerse(d),keys=[...groups.keys()],meta=$('#pageInfoMeta'),list=$('#pageInfoAyahs');if(meta)meta.textContent=uit('pageMeta',{juz:fmtNum(pageJuz(state.page)),side:ui(pageSide(state.page)==='right'?'rightPage':'leftPage'),count:fmtNum(keys.length)});if(!list)return;
  if(state.progressDetailTab==='notes')list.innerHTML=keys.filter(k=>state.notes[k]).map(k=>noteRow(k,state.notes[k])).join('')||`<div class="empty-card">${ui('noNotes')}</div>`;
  else list.innerHTML=keys.map(k=>ayahProgressRow(k,groups.get(k))).join(''); bindDynamicVerseOpen();
}
function ayahProgressRow(k,words){const r=state.ratings[k]||'',note=state.notes[k],preview=words.slice(0,8).map(w=>w.word).join(' ');return `<button class="ayah-row" data-verse-open="${k}" data-vpage="${state.page}"><span class="ayah-num-wrap"><span class="ayah-num">${fmtNum(k.split(':')[1])}</span><span class="status-dot ${r==='green'?'g':r==='yellow'?'y':r==='red'?'r':''}"></span></span><span class="arabic-preview">${escapeHtml(preview)}</span>${note?`<span class="note-indicator">${icon('note')}</span>`:`<span class="chev">${isRtlUI()?'‹':'›'}</span>`}</button>`}
function noteRow(k,n){return `<button class="note-row" data-verse-open="${k}" data-vpage="${state.page}"><div><b>${fmtVerseKey(k)}</b><small>${escapeHtml(n)}</small></div><span>${isRtlUI()?'‹':'›'}</span></button>`}

function openPicker(type){const isJ=type==='juz',items=isJ?Array.from({length:30},(_,i)=>({v:i+1,l:`${ui('juz')} ${fmtNum(i+1)}`})):SURAH_NAMES.map((n,i)=>({v:i+1,l:`${fmtNum(i+1)}. ${state.settings.uiLang==='ar'?SURAH_NAMES_AR[i]:n}`}));sheetRoot.innerHTML=`<div class="sheet-back" id="sheetBack"><div class="sheet picker-sheet"><div class="grab"></div><h3>${isJ?ui('chooseJuz'):ui('chooseSurah')}</h3><div class="picker-grid">${items.map(x=>`<button data-pick="${x.v}">${x.l}</button>`).join('')}</div></div></div>`;$('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{if(isJ){state.selectedJuz=Number(b.dataset.pick);state.page=JUZ_START_PAGES[state.selectedJuz-1]}else state.selectedSurah=Number(b.dataset.pick);closeSheet();render()})}

function settings(){
  const ul=LANGUAGES[state.settings.uiLang]||LANGUAGES.en,tl=LANGUAGES[state.settings.translationLang]||LANGUAGES.en;
  return `<div class="pad"><div class="page-title"><div><h2>${ui('settings')}</h2></div></div><section class="settings-group card"><h3>${ui('mushafDisplay')}</h3>${settingChoice(ui('readingStyle'),state.source==='plain'?ui('standard'):ui('tajweedColors'),'sourceSetting')}${settingToggle(ui('twoPageView'),state.settings.twoPage,'twoPageSetting')}</section><section class="settings-group card"><h3>${ui('audioSettings')}</h3>${settingChoice(ui('defaultReciter'),reciterLabel(state.reciter),'reciterSetting')}${settingToggle(ui('autoPlay'),state.autoNext,'autoNextSetting')}${settingToggle(ui('pauseAfter'),state.pause,'pauseSetting')}<div class="offline-audio-box"><div class="settings-row offline-title-row"><span>${ui('offlineAudio')}</span><b id="offlineAudioStatus">${ui('notDownloaded')}</b></div><label class="offline-label">${ui('offlineVoice')}</label><select class="select" id="offlineReciterSelect">${Object.entries(AUDIO).map(([k,v])=>`<option value="${k}" ${k===state.settings.offlineReciter?'selected':''}>${reciterLabel(k)}</option>`).join('')}</select><div class="offline-actions"><button class="primary" id="downloadAllAudio">${ui('downloadAll')}</button><button class="secondary danger-soft" id="deleteOfflineAudio">${ui('deleteAudio')}</button></div><div class="offline-progress" id="offlineProgress" hidden><span id="offlineProgressBar"></span></div><small class="offline-progress-text" id="offlineProgressText"></small></div></section><section class="settings-group card"><h3>${ui('app')}</h3>${settingChoice(ui('language'),ul.native,'uiLanguageSetting')}${settingChoice(ui('translationLang'),tl.native,'translationLanguageSetting')}${settingChoice(ui('theme'),themeLabel(state.settings.theme),'themeSetting')}${settingChoice(ui('offlineData'),ui('cachedPages'),'offlineSetting')}<button class="settings-row danger" id="resetProgress"><span>${ui('resetProgress')}</span><b>${ui('reset')}</b></button></section></div>`
}
function settingChoice(l,v,id){return `<button class="settings-row" id="${id}"><span>${l}</span><b>${v} ${isRtlUI()?'‹':'›'}</b></button>`}
function settingToggle(l,on,id){return `<div class="settings-row"><span>${l}</span><button class="switch ${on?'on':''}" id="${id}"></button></div>`}
function settingStepper(l,v,down,up){return `<div class="settings-row"><span>${l}</span><div class="stepper"><button id="${down}">−</button><b>${fmtNum(v)}%</b><button id="${up}">+</button></div></div>`}

function languageOptions(selected,type='ui'){
  const entries=Object.entries(LANGUAGES).filter(([k])=>type==='ui'||!!TRANSLATIONS[k]);
  return entries.map(([k,v])=>`<button class="language-option ${selected===k?'selected':''}" data-lang="${k}" dir="${v.dir}"><b>${v.native}</b><small>${v.label}</small></button>`).join('')
}
function openQuranNavigator(){
  const surah=currentSurahNumber(),ayah=Math.min(SURAH_COUNTS[surah-1],currentAyahNumber()),rtl=isRtlUI();
  document.body.classList.add('quran-nav-open');
  sheetRoot.innerHTML=`<div class="quran-nav-back" id="quranNavBack"><aside class="quran-nav-drawer ${rtl?'rtl-drawer':''}"><div class="quran-nav-head"><button class="icon-btn" id="closeQuranNav">${icon('close')}</button><h3>${ui('jumpTitle')}</h3></div><div class="quran-nav-current"><span>${ui('current')}</span><b>${fmtNum(surah)}. ${surahDisplayName(surah)} · ${fmtNum(ayah)}</b></div><div class="quran-nav-section"><label class="nav-field-label">${ui('surah')}</label><div class="surah-mobile-list" id="surahMobileList">${SURAH_NAMES.map((n,i)=>`<button data-nav-surah="${i+1}" class="${i+1===surah?'active':''}"><span>${fmtNum(i+1)}</span><b>${state.settings.uiLang==='ar'?SURAH_NAMES_AR[i]:n}</b></button>`).join('')}</div></div><div class="quran-nav-section ayah-section"><label class="nav-field-label">${ui('ayah')}</label><div class="ayah-mobile-grid" id="ayahMobileGrid"></div></div><button class="primary quran-nav-go" id="quranNavGo">${ui('goAyah')}</button></aside></div>`;
  let chosenSurah=surah,chosenAyah=ayah;
  const renderAyahs=()=>{const holder=$('#ayahMobileGrid');if(!holder)return;const max=SURAH_COUNTS[chosenSurah-1];chosenAyah=Math.min(chosenAyah,max);holder.innerHTML=Array.from({length:max},(_,i)=>`<button data-nav-ayah="${i+1}" class="${i+1===chosenAyah?'active':''}">${fmtNum(i+1)}</button>`).join('');holder.querySelectorAll('[data-nav-ayah]').forEach(b=>b.onclick=()=>{chosenAyah=Number(b.dataset.navAyah);holder.querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b))});setTimeout(()=>holder.querySelector('.active')?.scrollIntoView({block:'nearest'}),0)};
  renderAyahs();setTimeout(()=>$('#surahMobileList .active')?.scrollIntoView({block:'center'}),0);
  document.querySelectorAll('[data-nav-surah]').forEach(b=>b.onclick=()=>{chosenSurah=Number(b.dataset.navSurah);chosenAyah=1;document.querySelectorAll('[data-nav-surah]').forEach(x=>x.classList.toggle('active',x===b));renderAyahs()});
  $('#closeQuranNav').onclick=closeSheet;$('#quranNavBack').onclick=e=>{if(e.target.id==='quranNavBack')closeSheet()};
  $('#quranNavGo').onclick=()=>{closeSheet();openVerseByKey(`${chosenSurah}:${chosenAyah}`)};
}
function openLanguagePicker(type='ui'){
  const selected=type==='translation'?state.settings.translationLang:state.settings.uiLang;
  sheetRoot.innerHTML=`<div class="sheet-back language-picker-back" id="sheetBack"><div class="sheet language-sheet"><div class="grab"></div><div class="sheet-title"><h3>${type==='translation'?ui('translationLang'):ui('language')}</h3><button class="icon-btn" id="closeSheet">${icon('close')}</button></div><div class="language-grid">${languageOptions(selected,type)}</div></div></div>`;
  $('#closeSheet').onclick=closeSheet;$('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};
  document.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>{const lang=b.dataset.lang;if(type==='translation'){state.settings.translationLang=lang;}else{state.settings.uiLang=lang;state.settings.translationLang=TRANSLATIONS[lang]?lang:(state.settings.translationLang||'en');}saveAll();closeSheet();render()});
}

function openTajweedInfo(){
  const rows=[['#44b36a',ui('tajweedGreen')],['#4b78ff',ui('tajweedBlue')],['#e65a4f',ui('tajweedRed')],['#f0a63b',ui('tajweedOrange')],['#2c2c2c',ui('tajweedBlack')]];
  sheetRoot.innerHTML=`<div class="sheet-back" id="sheetBack"><div class="sheet tajweed-sheet"><div class="grab"></div><div class="sheet-title"><h3>${ui('tajweedInfo')}</h3><button class="icon-btn" id="closeSheet">${icon('close')}</button></div><p class="tajweed-info-intro">${ui('tajweedIntro')}</p><div class="tajweed-info-list">${rows.map(([c,t])=>`<div class="tajweed-info-row"><span class="tajweed-chip" style="background:${c}"></span><span>${t}</span></div>`).join('')}</div></div></div>`;
  $('#sheetBack').onclick=e=>{if(e.target.id==='sheetBack')closeSheet()};
  set('closeSheet',closeSheet);
}

function showLanguageOnboarding(){
  if(languageSetupDone||sheetRoot.innerHTML)return;
  sheetRoot.innerHTML=`<div class="sheet-back language-onboarding-back"><div class="sheet language-sheet onboarding"><div class="grab"></div><h3>Choose your language · اختر اللغة</h3><div class="language-grid">${languageOptions(state.settings.uiLang,'ui')}</div></div></div>`;
  document.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>{const lang=b.dataset.lang;state.settings.uiLang=lang;state.settings.translationLang=TRANSLATIONS[lang]?lang:'en';languageSetupDone=true;localStorage.setItem('qh-language-setup','1');saveAll();closeSheet();render()});
}

function quickActionRun(a){
  if(a==='resume'){state.tab='mushaf';render();return}
  if(a==='weak'){state.tab='review';render();return}
  if(a==='muta'){openMutashabihatPractice();return}
  if(a==='listen'){state.tab='mushaf';state.activePanel='audio';render();return}
}

function bind(){
  document.querySelectorAll('[data-go]').forEach(el=>el.onclick=()=>{state.tab=el.dataset.go;render()});
  document.querySelectorAll('[data-plan-action]').forEach(el=>el.onclick=()=>{if(el.dataset.planAction==='newmem'){state.selectedSurah=18;state.view='single';state.activePanel=null;state.translation=false;state.returnTo={tab:'home'};openVerseByKey('18:1',{toHome:true,scrollTop:true});}});
  document.querySelectorAll('[data-view]').forEach(el=>el.onclick=()=>{state.view=el.dataset.view;if(state.view==='scroll'&&state.activePanel==='translation')state.activePanel=null;else state.activePanel=null;render()});
  document.querySelectorAll('[data-source]').forEach(el=>el.onclick=()=>{state.source=el.dataset.source;saveAll();render()});
  document.querySelectorAll('[data-repeat]').forEach(el=>el.onclick=()=>{state.repeat=Number(el.dataset.repeat);state.tab==='mushaf'?refreshMushafDock():render()});
  const rateIn=$('#playbackRate');if(rateIn){rateIn.oninput=()=>{state.playbackRate=Number(rateIn.value)||1;const lab=$('#playbackRateLabel');if(lab)lab.textContent=`${Number(state.playbackRate).toFixed(2).replace(/\.00$/,'')}×`;audioEl.playbackRate=Number(state.playbackRate||1);saveAll();};}
  document.querySelectorAll('[data-ptab]').forEach(el=>el.onclick=()=>{state.progressTab=el.dataset.ptab;render()});
  document.querySelectorAll('[data-detail]').forEach(el=>el.onclick=()=>{state.progressDetailTab=el.dataset.detail;renderPreserveScreenScroll()});
  document.querySelectorAll('[data-range]').forEach(el=>el.onclick=()=>{state.analyticsRange=el.dataset.range;render()});
  document.querySelectorAll('[data-page]').forEach(el=>el.onclick=()=>{if(state.tab==='progress')state.returnTo={tab:'progress',progressTab:state.progressTab,selectedJuz:state.selectedJuz,selectedSurah:state.selectedSurah,progressDetailTab:state.progressDetailTab,page:state.page};state.page=Number(el.dataset.page);state.tab='mushaf';state.currentVerseKey=null;render()});
  document.querySelectorAll('[data-surah-ayah]').forEach(el=>el.onclick=()=>openVerseByKey(el.dataset.surahAyah,{fromProgress:state.tab==='progress'}));
  document.querySelectorAll('[data-practice]').forEach(el=>el.onclick=()=>practiceAction(el.dataset.practice));
  document.querySelectorAll('[data-quick]').forEach(el=>el.onclick=()=>quickActionRun(el.dataset.quick));
  bindDynamicVerseOpen();

  set('topBackBtn',()=>{if(state.returnTo?.tab==='mutash'){state.tab='mutash';state.mutashList=state.returnTo.mutashList??false;state.mutashPair=state.returnTo.mutashPair||null;state.mutashGroupKey=state.returnTo.mutashGroupKey||null;state.mutashIndex=state.returnTo.mutashIndex||0;state.mutashScroll=state.returnTo.mutashScroll||0;state.returnTo=null;render();}else if(state.returnTo?.tab==='progress'){state.tab='progress';state.progressTab=state.returnTo.progressTab||state.progressTab;state.selectedJuz=state.returnTo.selectedJuz||state.selectedJuz;state.selectedSurah=state.returnTo.selectedSurah||state.selectedSurah;state.progressDetailTab=state.returnTo.progressDetailTab||state.progressDetailTab;state.page=state.returnTo.page||state.page;state.returnTo=null;render();}else{state.returnTo=null;state.tab='home';render();}});set('menuBtn',()=>{state.mushafOptionsOpen=!state.mushafOptionsOpen;renderPreserveMushafScroll()});set('surahTitleBtn',openQuranNavigator);set('prevPage',()=>changePage(1));set('nextPage',()=>changePage(-1));
  set('audioBtn',()=>{state.activePanel=state.activePanel==='audio'?null:'audio';refreshMushafDock()});set('tajweedInfoBtn',openTajweedInfo);
  set('hideBtn',()=>{state.hide=!state.hide;if(state.hide){state.revealedAyahs={};state.revealed={};state.hintWordKey=null;}state.activePanel=state.hide?'hide':null;renderPreserveMushafScroll()});
  set('translationBtn',()=>{if(state.view==='scroll'){state.translation=!state.translation;state.activePanel=null;renderPreserveMushafScroll();return;}const opening=state.activePanel!=='translation';state.translation=opening;state.activePanel=opening?'translation':null;refreshMushafDock();});
  set('bookmarkBtn',openBookmarkChooser);set('evalBtn',()=>{const opening=state.activePanel!=='eval';state.activePanel=opening?'eval':null;if(opening)state.evalScope='ayah';refreshMushafDock()});
  set('hintBtn',showRandomHint);set('revealBtn',revealNextWord);set('showAyahBtn',showCurrentAyah);set('nextAyahBtn',nextAyah);
  set('playAudio',toggleAudio);set('pauseToggle',()=>{state.pause=!state.pause;saveAll();refreshMushafDock()});set('autoNextToggle',()=>{state.autoNext=!state.autoNext;refreshMushafDock()});
  const rec=$('#reciterSelect');if(rec)rec.onchange=()=>{state.reciter=rec.value;saveAll();audioEl.pause();state.audioPlaying=false;refreshMushafDock()};
  document.querySelectorAll('[data-eval-scope]').forEach(b=>b.onclick=()=>{state.evalScope=b.dataset.evalScope;refreshMushafDock()});
  let inlineRating=state.currentVerseKey?(state.ratings[state.currentVerseKey]||''):'';document.querySelectorAll('[data-inline-eval]').forEach(b=>b.onclick=()=>{inlineRating=b.dataset.inlineEval;document.querySelectorAll('[data-inline-eval]').forEach(x=>x.classList.toggle('selected',x===b))});
  set('saveInlineEval',async()=>{if(!state.currentVerseKey)return toast(ui('selectAyahFirst'));if(!inlineRating)return toast(ui('chooseRating'));const key=state.currentVerseKey;if(state.evalScope==='page'){const d=currentPageData()||await fetchPage(state.page);for(const k of pageKeysFromData(d))applyRating(k,inlineRating,state.page,true);syncPageRating(state.page,d);}else{applyRating(key,inlineRating,state.page,true);const n=$('#inlineNoteInput')?.value.trim()||'';if(n)state.notes[key]=n;else delete state.notes[key];syncPageRating(state.page,currentPageData());}saveAll();state.activePanel=null;refreshMushafDock();toast(state.evalScope==='page'?ui('pageEvaluationSaved'):ui('ayahEvaluationSaved'))});
  set('practiceBack',()=>{state.tab='practice';render()});set('revealPractice',()=>{if(state.practiceSession){state.practiceSession.revealed=!state.practiceSession.revealed;render()}});set('nextPractice',()=>{if(state.practiceSession)startPracticeTest(state.practiceSession.mode,state.practiceSession.opts||{})});set('practiceAudio',playPracticeAudio);
  document.querySelectorAll('[data-practice-rate]').forEach(b=>b.onclick=async()=>{const t=state.practiceSession;if(!t)return;const rating=b.dataset.practiceRate;try{const d=await fetchPage(t.page);if(t.mode==='page'){for(const k of pageKeysFromData(d))applyRating(k,rating,t.page,true);syncPageRating(t.page,d);}else if(t.answerKey){applyRating(t.answerKey,rating,t.page,true);syncPageRating(t.page,d);}else return;}catch{if(t.answerKey)applyRating(t.answerKey,rating,t.page,true)}saveAll();toast(t.mode==='page'?ui('pageEvaluationSaved'):ui('ayahEvaluationSaved'));document.querySelectorAll('[data-practice-rate]').forEach(x=>x.classList.toggle('selected',x===b))});
  set('juzPicker',()=>openPicker('juz'));set('surahPicker',()=>openPicker('surah'));

  set('sourceSetting',()=>{state.source=state.source==='plain'?'tajweed':'plain';saveAll();render()});set('reciterSetting',()=>{const ks=Object.keys(AUDIO),i=ks.indexOf(state.reciter);state.reciter=ks[(i+1)%ks.length];saveAll();render()});
  const offlineRec=$('#offlineReciterSelect');if(offlineRec)offlineRec.onchange=()=>{state.settings.offlineReciter=offlineRec.value;localStorage.setItem('qh-offline-reciter',offlineRec.value);saveAll();refreshOfflineAudioStatus()};set('downloadAllAudio',downloadAllAudio);set('deleteOfflineAudio',deleteOfflineAudio);if(state.tab==='settings')setTimeout(refreshOfflineAudioStatus,0);
  set('twoPageSetting',()=>{state.settings.twoPage=!state.settings.twoPage;saveAll();render()});set('pageNumberSetting',()=>{state.settings.pageNumbers=!state.settings.pageNumbers;saveAll();render()});set('autoNextSetting',()=>{state.autoNext=!state.autoNext;render()});set('pauseSetting',()=>{state.pause=!state.pause;render()});
  set('fontDown',()=>{state.settings.fontScale=Math.max(80,state.settings.fontScale-10);saveAll();render()});set('fontUp',()=>{state.settings.fontScale=Math.min(140,state.settings.fontScale+10);saveAll();render()});
  set('uiLanguageSetting',()=>openLanguagePicker('ui'));set('translationLanguageSetting',()=>openLanguagePicker('translation'));
  set('themeSetting',()=>{const modes=['light','dark','system'],i=modes.indexOf(state.settings.theme||'light');state.settings.theme=modes[(i+1)%modes.length];saveAll();render()});
  set('resetProgress',()=>{if(confirm(ui('resetConfirm'))){state.ratings={};state.pageRatings={};state.ratingPages={};state.notes={};state.ratingHistory={};state.practiceSeen={};saveAll();render()}});
}
function set(id,fn){const el=document.getElementById(id);if(el)el.onclick=fn}
function bindDynamicVerseOpen(){document.querySelectorAll('[data-verse-open]').forEach(el=>el.onclick=()=>{if(state.tab==='progress')state.returnTo={tab:'progress',progressTab:state.progressTab,selectedJuz:state.selectedJuz,selectedSurah:state.selectedSurah,progressDetailTab:state.progressDetailTab,page:state.page};if(el.dataset.vpage)state.page=Number(el.dataset.vpage);state.currentVerseKey=el.dataset.verseOpen;state.tab='mushaf';render()})}
async function openVerseByKey(key,opts={}){try{const r=await fetch(`${QURAN_API}/verses/by_key/${key}?fields=page_number`),j=await r.json(),p=j?.verse?.page_number;if(p)state.page=Number(p);state.currentVerseKey=key;state.selectedSurah=Number(key.split(':')[0])||state.selectedSurah;if(opts.fromMutash){state.returnTo={tab:'mutash',mutashList:false,mutashPair:state.mutashPair,mutashGroupKey:state.mutashGroupKey||null,mutashIndex:state.mutashIndex,mutashScroll:state.mutashScroll};}else if(opts.fromProgress){state.returnTo={tab:'progress',progressTab:state.progressTab,selectedJuz:state.selectedJuz,selectedSurah:state.selectedSurah,progressDetailTab:state.progressDetailTab,page:state.page};}else if(opts.toHome){state.returnTo={tab:'home'};}state.tab='mushaf';render();if(opts.scrollTop){const reset=()=>{const sc=document.querySelector('.mushaf-screen');if(sc)sc.scrollTop=0;window.scrollTo(0,0)};requestAnimationFrame(reset);setTimeout(reset,100);}}catch{toast(ui('couldNotLocateAyah'))}}
function changePage(d){state.page=Math.max(1,Math.min(604,state.page+d));state.currentVerseKey=null;render()}

function toast(msg){toastEl.textContent=msg;toastEl.classList.add('show');clearTimeout(toastEl._t);toastEl._t=setTimeout(()=>toastEl.classList.remove('show'),1700)}

window.addEventListener('resize',()=>{if(isCompactDevice()&&state.view==='double'){state.view='single';render()}});
render();
migrateRatingPages().then(changed=>{if(changed&&(state.tab==='home'||state.tab==='progress'))render()}).catch(()=>{});
// Service worker intentionally disabled in v10.19 to prevent stale-build blank screens.
