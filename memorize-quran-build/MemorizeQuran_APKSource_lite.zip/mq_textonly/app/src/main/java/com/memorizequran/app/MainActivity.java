package com.memorizequran.app;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
public class MainActivity extends Activity {
  private WebView webView;
  @SuppressLint({"SetJavaScriptEnabled","ObsoleteSdkInt"})
  public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(251,250,247)); getWindow().setNavigationBarColor(Color.rgb(251,250,247)); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); FrameLayout root=new FrameLayout(this); webView=new WebView(this); root.addView(webView,new FrameLayout.LayoutParams(-1,-1)); setContentView(root); WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setAllowFileAccessFromFileURLs(true); s.setAllowUniversalAccessFromFileURLs(true); s.setMediaPlaybackRequiresUserGesture(false); s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setUseWideViewPort(true); if(android.os.Build.VERSION.SDK_INT>=21)s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); webView.setWebViewClient(new WebViewClient()); webView.loadUrl("file:///android_asset/www/index.html"); }
  @Override public void onBackPressed(){ if(webView!=null){ webView.evaluateJavascript("(function(){var b=document.querySelector('#topBackBtn,.page-title .icon-btn,#practiceBack,#mutBackList');if(b){b.click();return 'handled'}return 'none'})()",v->{ if(v==null||!v.contains("handled")) super.onBackPressed(); }); } else super.onBackPressed(); }
  protected void onDestroy(){ if(webView!=null){webView.destroy();webView=null;} super.onDestroy(); }
}
